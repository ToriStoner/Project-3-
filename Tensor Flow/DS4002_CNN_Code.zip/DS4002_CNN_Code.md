```python
import pandas as pd
import numpy as np
import os
import shutil
import matplotlib.pyplot as plt
import random
from PIL import Image
import tensorflow as tf
from tensorflow.keras import layers, losses, activations, regularizers, metrics
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
```

    
    A module that was compiled using NumPy 1.x cannot be run in
    NumPy 2.0.2 as it may crash. To support both 1.x and 2.x
    versions of NumPy, modules must be compiled with NumPy 2.0.
    Some module may need to rebuild instead e.g. with 'pybind11>=2.12'.
    
    If you are a user of the module, the easiest solution will be to
    downgrade to 'numpy<2' or try to upgrade the affected module.
    We expect that some modules will need time to support NumPy 2.
    
    Traceback (most recent call last):  File "<frozen runpy>", line 198, in _run_module_as_main
      File "<frozen runpy>", line 88, in _run_code
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel_launcher.py", line 17, in <module>
        app.launch_new_instance()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/traitlets/config/application.py", line 1043, in launch_instance
        app.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelapp.py", line 725, in start
        self.io_loop.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/tornado/platform/asyncio.py", line 215, in start
        self.asyncio_loop.run_forever()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 607, in run_forever
        self._run_once()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 1922, in _run_once
        handle._run()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/events.py", line 80, in _run
        self._context.run(self._callback, *self._args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 513, in dispatch_queue
        await self.process_one()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 502, in process_one
        await dispatch(*args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 409, in dispatch_shell
        await result
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 729, in execute_request
        reply_content = await reply_content
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/ipkernel.py", line 422, in do_execute
        res = shell.run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/zmqshell.py", line 540, in run_cell
        return super().run_cell(*args, **kwargs)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3006, in run_cell
        result = self._run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3061, in _run_cell
        result = runner(coro)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/async_helpers.py", line 129, in _pseudo_sync_runner
        coro.send(None)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3266, in run_cell_async
        has_raised = await self.run_ast_nodes(code_ast.body, cell_name,
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3445, in run_ast_nodes
        if await self.run_code(code, result, async_=asy):
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3505, in run_code
        exec(code_obj, self.user_global_ns, self.user_ns)
      File "/tmp/ipykernel_74166/2542694989.py", line 1, in <module>
        import pandas as pd
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/pandas/__init__.py", line 26, in <module>
        from pandas.compat import (
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/pandas/compat/__init__.py", line 27, in <module>
        from pandas.compat.pyarrow import (
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/pandas/compat/pyarrow.py", line 8, in <module>
        import pyarrow as pa
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/pyarrow/__init__.py", line 65, in <module>
        import pyarrow.lib as _lib



    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    AttributeError: _ARRAY_API not found


    
    A module that was compiled using NumPy 1.x cannot be run in
    NumPy 2.0.2 as it may crash. To support both 1.x and 2.x
    versions of NumPy, modules must be compiled with NumPy 2.0.
    Some module may need to rebuild instead e.g. with 'pybind11>=2.12'.
    
    If you are a user of the module, the easiest solution will be to
    downgrade to 'numpy<2' or try to upgrade the affected module.
    We expect that some modules will need time to support NumPy 2.
    
    Traceback (most recent call last):  File "<frozen runpy>", line 198, in _run_module_as_main
      File "<frozen runpy>", line 88, in _run_code
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel_launcher.py", line 17, in <module>
        app.launch_new_instance()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/traitlets/config/application.py", line 1043, in launch_instance
        app.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelapp.py", line 725, in start
        self.io_loop.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/tornado/platform/asyncio.py", line 215, in start
        self.asyncio_loop.run_forever()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 607, in run_forever
        self._run_once()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 1922, in _run_once
        handle._run()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/events.py", line 80, in _run
        self._context.run(self._callback, *self._args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 513, in dispatch_queue
        await self.process_one()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 502, in process_one
        await dispatch(*args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 409, in dispatch_shell
        await result
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 729, in execute_request
        reply_content = await reply_content
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/ipkernel.py", line 422, in do_execute
        res = shell.run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/zmqshell.py", line 540, in run_cell
        return super().run_cell(*args, **kwargs)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3006, in run_cell
        result = self._run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3061, in _run_cell
        result = runner(coro)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/async_helpers.py", line 129, in _pseudo_sync_runner
        coro.send(None)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3266, in run_cell_async
        has_raised = await self.run_ast_nodes(code_ast.body, cell_name,
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3445, in run_ast_nodes
        if await self.run_code(code, result, async_=asy):
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3505, in run_code
        exec(code_obj, self.user_global_ns, self.user_ns)
      File "/tmp/ipykernel_74166/2542694989.py", line 1, in <module>
        import pandas as pd
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/pandas/__init__.py", line 49, in <module>
        from pandas.core.api import (
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/pandas/core/api.py", line 9, in <module>
        from pandas.core.dtypes.dtypes import (
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/pandas/core/dtypes/dtypes.py", line 24, in <module>
        from pandas._libs import (
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/pyarrow/__init__.py", line 65, in <module>
        import pyarrow.lib as _lib



    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    AttributeError: _ARRAY_API not found


    2024-11-20 11:16:46.405328: I tensorflow/core/util/port.cc:153] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
    2024-11-20 11:16:46.444600: I external/local_xla/xla/tsl/cuda/cudart_stub.cc:32] Could not find cuda drivers on your machine, GPU will not be used.
    2024-11-20 11:16:48.128788: I external/local_xla/xla/tsl/cuda/cudart_stub.cc:32] Could not find cuda drivers on your machine, GPU will not be used.
    2024-11-20 11:16:48.389301: E external/local_xla/xla/stream_executor/cuda/cuda_fft.cc:477] Unable to register cuFFT factory: Attempting to register factory for plugin cuFFT when one has already been registered
    WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
    E0000 00:00:1732119408.783135   74166 cuda_dnn.cc:8310] Unable to register cuDNN factory: Attempting to register factory for plugin cuDNN when one has already been registered
    E0000 00:00:1732119408.934640   74166 cuda_blas.cc:1418] Unable to register cuBLAS factory: Attempting to register factory for plugin cuBLAS when one has already been registered
    2024-11-20 11:16:49.887422: I tensorflow/core/platform/cpu_feature_guard.cc:210] This TensorFlow binary is optimized to use available CPU instructions in performance-critical operations.
    To enable the following instructions: AVX2 AVX512F AVX512_VNNI FMA, in other operations, rebuild TensorFlow with the appropriate compiler flags.
    /apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/scipy/__init__.py:132: UserWarning: A NumPy version >=1.21.6 and <1.28.0 is required for this version of SciPy (detected version 2.0.2)
      warnings.warn(f"A NumPy version >={np_minversion} and <{np_maxversion}"
    
    A module that was compiled using NumPy 1.x cannot be run in
    NumPy 2.0.2 as it may crash. To support both 1.x and 2.x
    versions of NumPy, modules must be compiled with NumPy 2.0.
    Some module may need to rebuild instead e.g. with 'pybind11>=2.12'.
    
    If you are a user of the module, the easiest solution will be to
    downgrade to 'numpy<2' or try to upgrade the affected module.
    We expect that some modules will need time to support NumPy 2.
    
    Traceback (most recent call last):  File "<frozen runpy>", line 198, in _run_module_as_main
      File "<frozen runpy>", line 88, in _run_code
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel_launcher.py", line 17, in <module>
        app.launch_new_instance()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/traitlets/config/application.py", line 1043, in launch_instance
        app.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelapp.py", line 725, in start
        self.io_loop.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/tornado/platform/asyncio.py", line 215, in start
        self.asyncio_loop.run_forever()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 607, in run_forever
        self._run_once()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 1922, in _run_once
        handle._run()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/events.py", line 80, in _run
        self._context.run(self._callback, *self._args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 513, in dispatch_queue
        await self.process_one()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 502, in process_one
        await dispatch(*args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 409, in dispatch_shell
        await result
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 729, in execute_request
        reply_content = await reply_content
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/ipkernel.py", line 422, in do_execute
        res = shell.run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/zmqshell.py", line 540, in run_cell
        return super().run_cell(*args, **kwargs)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3006, in run_cell
        result = self._run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3061, in _run_cell
        result = runner(coro)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/async_helpers.py", line 129, in _pseudo_sync_runner
        coro.send(None)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3266, in run_cell_async
        has_raised = await self.run_ast_nodes(code_ast.body, cell_name,
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3445, in run_ast_nodes
        if await self.run_code(code, result, async_=asy):
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3505, in run_code
        exec(code_obj, self.user_global_ns, self.user_ns)
      File "/tmp/ipykernel_74166/2542694989.py", line 8, in <module>
        import tensorflow as tf
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/__init__.py", line 49, in <module>
        from tensorflow._api.v2 import __internal__
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/_api/v2/__internal__/__init__.py", line 13, in <module>
        from tensorflow._api.v2.__internal__ import feature_column
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/_api/v2/__internal__/feature_column/__init__.py", line 8, in <module>
        from tensorflow.python.feature_column.feature_column_v2 import DenseColumn # line: 1777
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/feature_column/feature_column_v2.py", line 38, in <module>
        from tensorflow.python.feature_column import feature_column as fc_old
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/feature_column/feature_column.py", line 41, in <module>
        from tensorflow.python.layers import base
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/layers/base.py", line 16, in <module>
        from tensorflow.python.keras.legacy_tf_layers import base
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/__init__.py", line 25, in <module>
        from tensorflow.python.keras import models
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/models.py", line 25, in <module>
        from tensorflow.python.keras.engine import training_v1
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/engine/training_v1.py", line 46, in <module>
        from tensorflow.python.keras.engine import training_arrays_v1
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/engine/training_arrays_v1.py", line 37, in <module>
        from scipy.sparse import issparse  # pylint: disable=g-import-not-at-top
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/scipy/sparse/__init__.py", line 274, in <module>
        from ._csr import *
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/scipy/sparse/_csr.py", line 11, in <module>
        from ._sparsetools import (csr_tocsc, csr_tobsr, csr_count_blocks,



    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    AttributeError: _ARRAY_API not found


    
    A module that was compiled using NumPy 1.x cannot be run in
    NumPy 2.0.2 as it may crash. To support both 1.x and 2.x
    versions of NumPy, modules must be compiled with NumPy 2.0.
    Some module may need to rebuild instead e.g. with 'pybind11>=2.12'.
    
    If you are a user of the module, the easiest solution will be to
    downgrade to 'numpy<2' or try to upgrade the affected module.
    We expect that some modules will need time to support NumPy 2.
    
    Traceback (most recent call last):  File "<frozen runpy>", line 198, in _run_module_as_main
      File "<frozen runpy>", line 88, in _run_code
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel_launcher.py", line 17, in <module>
        app.launch_new_instance()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/traitlets/config/application.py", line 1043, in launch_instance
        app.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelapp.py", line 725, in start
        self.io_loop.start()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/tornado/platform/asyncio.py", line 215, in start
        self.asyncio_loop.run_forever()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 607, in run_forever
        self._run_once()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/base_events.py", line 1922, in _run_once
        handle._run()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/asyncio/events.py", line 80, in _run
        self._context.run(self._callback, *self._args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 513, in dispatch_queue
        await self.process_one()
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 502, in process_one
        await dispatch(*args)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 409, in dispatch_shell
        await result
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/kernelbase.py", line 729, in execute_request
        reply_content = await reply_content
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/ipkernel.py", line 422, in do_execute
        res = shell.run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/ipykernel/zmqshell.py", line 540, in run_cell
        return super().run_cell(*args, **kwargs)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3006, in run_cell
        result = self._run_cell(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3061, in _run_cell
        result = runner(coro)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/async_helpers.py", line 129, in _pseudo_sync_runner
        coro.send(None)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3266, in run_cell_async
        has_raised = await self.run_ast_nodes(code_ast.body, cell_name,
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3445, in run_ast_nodes
        if await self.run_code(code, result, async_=asy):
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3505, in run_code
        exec(code_obj, self.user_global_ns, self.user_ns)
      File "/tmp/ipykernel_74166/2542694989.py", line 8, in <module>
        import tensorflow as tf
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/__init__.py", line 49, in <module>
        from tensorflow._api.v2 import __internal__
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/_api/v2/__internal__/__init__.py", line 13, in <module>
        from tensorflow._api.v2.__internal__ import feature_column
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/_api/v2/__internal__/feature_column/__init__.py", line 8, in <module>
        from tensorflow.python.feature_column.feature_column_v2 import DenseColumn # line: 1777
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/feature_column/feature_column_v2.py", line 38, in <module>
        from tensorflow.python.feature_column import feature_column as fc_old
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/feature_column/feature_column.py", line 41, in <module>
        from tensorflow.python.layers import base
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/layers/base.py", line 16, in <module>
        from tensorflow.python.keras.legacy_tf_layers import base
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/__init__.py", line 25, in <module>
        from tensorflow.python.keras import models
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/models.py", line 25, in <module>
        from tensorflow.python.keras.engine import training_v1
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/tensorflow/python/keras/engine/training_v1.py", line 71, in <module>
        from scipy.sparse import issparse  # pylint: disable=g-import-not-at-top
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/scipy/sparse/__init__.py", line 274, in <module>
        from ._csr import *
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/scipy/sparse/_csr.py", line 11, in <module>
        from ._sparsetools import (csr_tocsc, csr_tobsr, csr_count_blocks,



    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    AttributeError: _ARRAY_API not found



```python
# going to create classes in the folders that have the image data
train_class_folders = [os.path.join("CNN_Train", chr(letter)) for letter in range(65, 91)]  # A-Z
test_class_folders =  [os.path.join("CNN_Test", chr(letter)) for letter in range(65, 91)]  # A-Z
def move_images(folder_path, class_folders):
    files = os.listdir(folder_path) # getting all the image names in the directory and storing those under the variable named "files"
    
    for filename in files: # iterating through the image names
        if filename.endswith('.jpg'):  # Going to process only .jpg files (there was a singular csv file in the directory so want to ignore that)
            first_letter = filename[0].upper()  # Geting the first letter of the image name so we can properply classify it into its corresponding class
            
            if 'A' <= first_letter <= 'Z':  # Ensure it's between A and Z #
                class_index = ord(first_letter) - ord('A')  # Convert A-Z to index 0-25
                class_folder = class_folders[class_index]
                
                # # Ensure that the class folder exists; if not, create it
                # if not os.path.exists(class_folder):
                #     os.makedirs(class_folder)
                #     print(f"Created directory: {class_folder}") not necessary ....
                
                old_file_path = os.path.join(folder_path, filename)
                new_file_path = os.path.join(class_folder, filename)
                
                shutil.move(old_file_path, new_file_path)
                print(f"Moved '{filename}' to '{class_folder}'.")

# Move images to the appropriate class folders
move_images("CNN_Train", train_class_folders)
move_images("CNN_Test", test_class_folders)

```

    Created directory: CNN_Train/N
    Moved 'N13_jpg.rf.b51614c6e42508cb8623880c906f0fb5.jpg' to 'CNN_Train/N'.
    Created directory: CNN_Train/K
    Moved 'K14_jpg.rf.b032c719d888e4795800a1a9ec27d7d1.jpg' to 'CNN_Train/K'.
    Created directory: CNN_Train/V
    Moved 'V6_jpg.rf.6de159f5c0a51aecaa23d4b8015761a3.jpg' to 'CNN_Train/V'.
    Created directory: CNN_Train/H
    Moved 'H22_jpg.rf.caf6284be939baaa27a8fba14e56023a.jpg' to 'CNN_Train/H'.
    Created directory: CNN_Train/Z
    Moved 'Z20_jpg.rf.c115813a2f60d4f239546c931101270c.jpg' to 'CNN_Train/Z'.
    Created directory: CNN_Train/F
    Moved 'F22_jpg.rf.203feff812b6af7fb2f3c76ec919416d.jpg' to 'CNN_Train/F'.
    Created directory: CNN_Train/U
    Moved 'U4_jpg.rf.db34e86828f1538262e443a02b5f3c29.jpg' to 'CNN_Train/U'.
    Created directory: CNN_Train/J
    Moved 'J11_jpg.rf.a9e6ab97a4377c361739865881eac00f.jpg' to 'CNN_Train/J'.
    Created directory: CNN_Train/S
    Moved 'S9_jpg.rf.695f76e3640404b5022746170b2daf3f.jpg' to 'CNN_Train/S'.
    Moved 'S23_jpg.rf.ccfd91c75fbec52c6ca4c6359dfff9f0.jpg' to 'CNN_Train/S'.
    Moved 'H6_jpg.rf.59081b8942dff53572b60ef79b8b19ae.jpg' to 'CNN_Train/H'.
    Created directory: CNN_Train/W
    Moved 'W10_jpg.rf.031532ad7d9f4f1dd1636c2497ba7b40.jpg' to 'CNN_Train/W'.
    Created directory: CNN_Train/P
    Moved 'P16_jpg.rf.c8f1dd0daff479de207233c3e5bb9875.jpg' to 'CNN_Train/P'.
    Moved 'U12_jpg.rf.64d4fb00dfa817e4e74e9d6082514d75.jpg' to 'CNN_Train/U'.
    Moved 'K22_jpg.rf.de2eea95fc720573b025a9070556a116.jpg' to 'CNN_Train/K'.
    Moved 'W20_jpg.rf.5d59cba5b627ae61936bb6e0446b1f2f.jpg' to 'CNN_Train/W'.
    Created directory: CNN_Train/L
    Moved 'L16_jpg.rf.16f4d2af0f09a824d69c17d5a4a00325.jpg' to 'CNN_Train/L'.
    Created directory: CNN_Train/M
    Moved 'M15_jpg.rf.b397980be97cc024f133dbd2d8a4fcdb.jpg' to 'CNN_Train/M'.
    Moved 'Z23_jpg.rf.aff14a2d63ad5cf50d9bc3a4bad6a1f9.jpg' to 'CNN_Train/Z'.
    Moved 'S29_jpg.rf.597153b714fdd14a6464995904b69968.jpg' to 'CNN_Train/S'.
    Moved 'V22_jpg.rf.6c12c374bf2a331b4e3b7bca2d709468.jpg' to 'CNN_Train/V'.
    Moved 'L23_jpg.rf.d3a1759ef28882e2b290b8d4a0eb0e65.jpg' to 'CNN_Train/L'.
    Created directory: CNN_Train/G
    Moved 'G17_jpg.rf.f381273d4c4315212c697855534e36d6.jpg' to 'CNN_Train/G'.
    Created directory: CNN_Train/X
    Moved 'X13_jpg.rf.89181cc2106d7483c6e714651a6809d1.jpg' to 'CNN_Train/X'.
    Moved 'J3_jpg.rf.f7a187e59859b6e80d6fe61095c59c08.jpg' to 'CNN_Train/J'.
    Created directory: CNN_Train/I
    Moved 'I6_jpg.rf.e777252b29b845d02452566d242b3e6b.jpg' to 'CNN_Train/I'.
    Moved 'H20_jpg.rf.2a387c4b793702418b600c8e3b4370c4.jpg' to 'CNN_Train/H'.
    Created directory: CNN_Train/O
    Moved 'O18_jpg.rf.b5dc12a4a13440790fb41be1da604700.jpg' to 'CNN_Train/O'.
    Moved 'G29_jpg.rf.12ae1e591ad1423f2b184e3ec3c6c7b3.jpg' to 'CNN_Train/G'.
    Moved 'V20_jpg.rf.0a17a5441685a6b0624935542526846b.jpg' to 'CNN_Train/V'.
    Moved 'H8_jpg.rf.bb9fc6bc51f759dea012dc6a71262236.jpg' to 'CNN_Train/H'.
    Created directory: CNN_Train/Q
    Moved 'Q14_jpg.rf.a814e740944ca15a90dcd2ba14c4e69a.jpg' to 'CNN_Train/Q'.
    Moved 'G22_jpg.rf.82ebba8bb04b90450c79a115a12f83a8.jpg' to 'CNN_Train/G'.
    Created directory: CNN_Train/A
    Moved 'A11_jpg.rf.4126b388a474440c970d85a3b2a7bf09.jpg' to 'CNN_Train/A'.
    Moved 'L6_jpg.rf.05806c4c18c8f9b2906f34ac24c81b42.jpg' to 'CNN_Train/L'.
    Moved 'S26_jpg.rf.8d8e30490eba9d6dc9b5f52689d4727c.jpg' to 'CNN_Train/S'.
    Moved 'O2_jpg.rf.744b3c690627bc4f831a4534ffd7b728.jpg' to 'CNN_Train/O'.
    Moved 'S3_jpg.rf.a5bc8e77504a08380e0dfc418932263a.jpg' to 'CNN_Train/S'.
    Moved 'F21_jpg.rf.3ab7682cd06b3dd8352daf732006b86c.jpg' to 'CNN_Train/F'.
    Moved 'F26_jpg.rf.cb8796564c215d2a13326f696c9526e4.jpg' to 'CNN_Train/F'.
    Created directory: CNN_Train/B
    Moved 'B16_jpg.rf.c5a3ebe84afd822abef025716af0399c.jpg' to 'CNN_Train/B'.
    Created directory: CNN_Train/D
    Moved 'D25_jpg.rf.ae3ef2e7257fde632de81a3a21678b0c.jpg' to 'CNN_Train/D'.
    Created directory: CNN_Train/Y
    Moved 'Y24_jpg.rf.62482bc4f89f6364a6dbf6bf80677932.jpg' to 'CNN_Train/Y'.
    Moved 'I29_jpg.rf.d6fddff871678ed1cdaf47faf3f877c3.jpg' to 'CNN_Train/I'.
    Moved 'S13_jpg.rf.b294d4baa969f317fe41b00591f4abb9.jpg' to 'CNN_Train/S'.
    Created directory: CNN_Train/T
    Moved 'T19_jpg.rf.050433a13afd1405f4c96062585d84d3.jpg' to 'CNN_Train/T'.
    Created directory: CNN_Train/E
    Moved 'E0_jpg.rf.2754d7217376d1e9cf151758879180f8.jpg' to 'CNN_Train/E'.
    Moved 'H20_jpg.rf.ae4f866b051c949fbfcc4e5969baadf5.jpg' to 'CNN_Train/H'.
    Created directory: CNN_Train/C
    Moved 'C0_jpg.rf.6e38ba21cab2531e3d6f2e455a44a8a9.jpg' to 'CNN_Train/C'.
    Moved 'H11_jpg.rf.b857162b6a635503ddd6eb46e0039551.jpg' to 'CNN_Train/H'.
    Moved 'S12_jpg.rf.d36f446eb042186bfb7414d3132bc586.jpg' to 'CNN_Train/S'.
    Moved 'A24_jpg.rf.0c548e55630ab5b3682e8267ad1daba2.jpg' to 'CNN_Train/A'.
    Moved 'E23_jpg.rf.62accdca7faaf361302a63b6e7fbae35.jpg' to 'CNN_Train/E'.
    Moved 'G8_jpg.rf.1c5dfe424c343ada7600387526c29ca1.jpg' to 'CNN_Train/G'.
    Moved 'P19_jpg.rf.823884f9bbb962d01cdfc022ac58451b.jpg' to 'CNN_Train/P'.
    Moved 'B17_jpg.rf.a2125c5f9b4c51b033327a6b0b2ee389.jpg' to 'CNN_Train/B'.
    Moved 'F22_jpg.rf.bd4c140b2928c870f5947764472fe0c0.jpg' to 'CNN_Train/F'.
    Moved 'H16_jpg.rf.d580dc9274dacec3bcc50b6d06005f98.jpg' to 'CNN_Train/H'.
    Moved 'C3_jpg.rf.d91cace8c665c24c4423104768a9bdb1.jpg' to 'CNN_Train/C'.
    Moved 'P0_jpg.rf.53eb3ac143396f521ceb9b0a4578eb5e.jpg' to 'CNN_Train/P'.
    Moved 'Y4_jpg.rf.ed950651c4b1a48d56e53cba5649c8a9.jpg' to 'CNN_Train/Y'.
    Moved 'K19_jpg.rf.a124825809a5094a34702c322ff0c53f.jpg' to 'CNN_Train/K'.
    Moved 'D16_jpg.rf.06a330daa452111410a8420e21ae1657.jpg' to 'CNN_Train/D'.
    Moved 'Z6_jpg.rf.1bb2adfb8cfa7d70187286406fcd9852.jpg' to 'CNN_Train/Z'.
    Moved 'G10_jpg.rf.2ddc37c5b69f1b2fed57e5bb4d24a76d.jpg' to 'CNN_Train/G'.
    Moved 'Q18_jpg.rf.2bc471b2f0b6bb8e693f918ed7e5de72.jpg' to 'CNN_Train/Q'.
    Created directory: CNN_Train/R
    Moved 'R2_jpg.rf.8a5886aae0af7c4586b4c9ceed4962c3.jpg' to 'CNN_Train/R'.
    Moved 'D13_jpg.rf.d1c61c19e778e7a3da9c35b46ae8fd40.jpg' to 'CNN_Train/D'.
    Moved 'B4_jpg.rf.855448db45c9e5e96114cacd36450c20.jpg' to 'CNN_Train/B'.
    Moved 'S14_jpg.rf.2b2f15ec8208d5b596764271ebc6fac6.jpg' to 'CNN_Train/S'.
    Moved 'F24_jpg.rf.d20a210eb1931d350fee49615fed039e.jpg' to 'CNN_Train/F'.
    Moved 'M17_jpg.rf.dd1098b547010921bbc54c37dd4d5035.jpg' to 'CNN_Train/M'.
    Moved 'K18_jpg.rf.f930225eb54c4a878d3aa1592e253aa4.jpg' to 'CNN_Train/K'.
    Moved 'E13_jpg.rf.56f0e141a9f408a54768dd8a920be58c.jpg' to 'CNN_Train/E'.
    Moved 'D25_jpg.rf.5699ee5a529664db698910eb4427c895.jpg' to 'CNN_Train/D'.
    Moved 'S11_jpg.rf.c774a0072364a36a6dacad88c57304fa.jpg' to 'CNN_Train/S'.
    Moved 'E21_jpg.rf.5291cbba4a6ded4b802a96850d92b745.jpg' to 'CNN_Train/E'.
    Moved 'J10_jpg.rf.aeaae1e17cb69eb3d5d390e5fd8acc89.jpg' to 'CNN_Train/J'.
    Moved 'P5_jpg.rf.88876e50acdd0cd7011c92c6044530a4.jpg' to 'CNN_Train/P'.
    Moved 'I6_jpg.rf.8ecd1ecaea163c26732dda70b8ebab61.jpg' to 'CNN_Train/I'.
    Moved 'J13_jpg.rf.b919071bb39a291fe0a16f857396f03c.jpg' to 'CNN_Train/J'.
    Moved 'D26_jpg.rf.9e113b47eda9f5586d51f646e2c71814.jpg' to 'CNN_Train/D'.
    Moved 'T23_jpg.rf.8fdee569ef3a5783d6af151bbaf6a568.jpg' to 'CNN_Train/T'.
    Moved 'G14_jpg.rf.31b6b422b2e73367f2d4faf5f25ea235.jpg' to 'CNN_Train/G'.
    Moved 'M19_jpg.rf.b6071dc5f662dde1884f3d9258f988f8.jpg' to 'CNN_Train/M'.
    Moved 'V6_jpg.rf.0d70a9822003b3d1c9c7eae309a99f70.jpg' to 'CNN_Train/V'.
    Moved 'S9_jpg.rf.1081df1f92818e03c4c10d34860c4c24.jpg' to 'CNN_Train/S'.
    Moved 'M17_jpg.rf.ada0001735e2863080c683069fc65a36.jpg' to 'CNN_Train/M'.
    Moved 'G13_jpg.rf.2a5523617be9cbc99ee347a78b160cb4.jpg' to 'CNN_Train/G'.
    Moved 'L1_jpg.rf.a5cdc6ba48732365fc1b752f923e580d.jpg' to 'CNN_Train/L'.
    Moved 'D26_jpg.rf.f5d3c82d0ace4b6e255e2df3b924fe76.jpg' to 'CNN_Train/D'.
    Moved 'R16_jpg.rf.c6fa1889e0e3d5a3848b446a86e91a86.jpg' to 'CNN_Train/R'.
    Moved 'Q17_jpg.rf.9dc6c576f5549b61709365de0289c31a.jpg' to 'CNN_Train/Q'.
    Moved 'N0_jpg.rf.3fbb2b164f02bc50f8bef8873315dfe5.jpg' to 'CNN_Train/N'.
    Moved 'Z25_jpg.rf.0f660f6c46cfdf0ac387b7925612b5fb.jpg' to 'CNN_Train/Z'.
    Moved 'R16_jpg.rf.5008e64ca64722b238f88ffb294a87c5.jpg' to 'CNN_Train/R'.
    Moved 'A13_jpg.rf.cd081f003a915ff50ed9e2b3860e1eb8.jpg' to 'CNN_Train/A'.
    Moved 'F12_jpg.rf.458f15ee20731a757487fa87ed9db9f1.jpg' to 'CNN_Train/F'.
    Moved 'J33_jpg.rf.a445854ac4ec4ed9187c4033c936d722.jpg' to 'CNN_Train/J'.
    Moved 'R7_jpg.rf.c89342699cdb59cd6fcc4d6d515ef898.jpg' to 'CNN_Train/R'.
    Moved 'S20_jpg.rf.a282e308a7090bfe1034f786e7bddee8.jpg' to 'CNN_Train/S'.
    Moved 'X23_jpg.rf.7f394bde10fc2888f91a578bceed373c.jpg' to 'CNN_Train/X'.
    Moved 'I12_jpg.rf.c10b0eb2986826e49eab5a762f0d55db.jpg' to 'CNN_Train/I'.
    Moved 'R7_jpg.rf.34371b1e19708906fc3eea222974199d.jpg' to 'CNN_Train/R'.
    Moved 'A0_jpg.rf.292a080422ba984985192f413101af41.jpg' to 'CNN_Train/A'.
    Moved 'Z3_jpg.rf.807b0edf384fc6c34bc4715db2cb9a36.jpg' to 'CNN_Train/Z'.
    Moved 'N14_jpg.rf.ad8c5bb14931850e4f6275728c6649d8.jpg' to 'CNN_Train/N'.
    Moved 'E2_jpg.rf.f5c34160c50765040632845876f03dc9.jpg' to 'CNN_Train/E'.
    Moved 'K11_jpg.rf.40bba249f19943166c129fd48c7352ae.jpg' to 'CNN_Train/K'.
    Moved 'U1_jpg.rf.9843b133fc545def208f872a6b4c5254.jpg' to 'CNN_Train/U'.
    Moved 'I2_jpg.rf.373a087d55da938d9af4b1e7f9e496d3.jpg' to 'CNN_Train/I'.
    Moved 'J31_jpg.rf.b85dcb4878217e725a54f0417c46fda4.jpg' to 'CNN_Train/J'.
    Moved 'T22_jpg.rf.9100c7e5054671b1996d996e33dafa8a.jpg' to 'CNN_Train/T'.
    Moved 'W20_jpg.rf.eb55ea4c692a7b5e833a8d53d5562c69.jpg' to 'CNN_Train/W'.
    Moved 'H26_jpg.rf.62b14021e7c28a6cf9664fc7ba7c8dbd.jpg' to 'CNN_Train/H'.
    Moved 'A27_jpg.rf.0c350b038342fd2b593f7cc88589e4bf.jpg' to 'CNN_Train/A'.
    Moved 'M18_jpg.rf.94b6b179dc7fdb52cd82dfa90c2ec8c7.jpg' to 'CNN_Train/M'.
    Moved 'L17_jpg.rf.7f3965679f64cad13fd80b0adf625955.jpg' to 'CNN_Train/L'.
    Moved 'M18_jpg.rf.129826d37d00c7e46376752d8649edaa.jpg' to 'CNN_Train/M'.
    Moved 'X16_jpg.rf.efc9858a53b05705d7dfde4cae5b88e2.jpg' to 'CNN_Train/X'.
    Moved 'U13_jpg.rf.701e44546d15ae35e211e91443875bc8.jpg' to 'CNN_Train/U'.
    Moved 'R19_jpg.rf.13a69f772b8c4a24d8734a95b40366cc.jpg' to 'CNN_Train/R'.
    Moved 'G26_jpg.rf.887b7eedb4f32e7f622619094dc8a0b2.jpg' to 'CNN_Train/G'.
    Moved 'H28_jpg.rf.955ccfbebad415e8874635c4de28f1cc.jpg' to 'CNN_Train/H'.
    Moved 'G0_jpg.rf.b5c7bbeec2ccccbbd0b6e96851d8bffe.jpg' to 'CNN_Train/G'.
    Moved 'W10_jpg.rf.9f7fc2e1124520f27ce85b9a2d021259.jpg' to 'CNN_Train/W'.
    Moved 'I21_jpg.rf.35280a1897b5390adfd5559e7100668e.jpg' to 'CNN_Train/I'.
    Moved 'Z12_jpg.rf.e7d4e949fa2f1c32714202e7ce72247c.jpg' to 'CNN_Train/Z'.
    Moved 'U20_jpg.rf.c3a9ddf27b1f4895556aaf888f785784.jpg' to 'CNN_Train/U'.
    Moved 'F6_jpg.rf.65f35de3f176a0365d29b252790ee400.jpg' to 'CNN_Train/F'.
    Moved 'S17_jpg.rf.60db942013d6803a9b77f75534537789.jpg' to 'CNN_Train/S'.
    Moved 'Z28_jpg.rf.f3845fc7a529d60d5878d98a8a46781d.jpg' to 'CNN_Train/Z'.
    Moved 'E3_jpg.rf.2d1c20e9ad51d82bc146b2638c62d694.jpg' to 'CNN_Train/E'.
    Moved 'A1_jpg.rf.3df907205b348d5975bf8db94ec8c092.jpg' to 'CNN_Train/A'.
    Moved 'D16_jpg.rf.28428f3a63f878279c5cfd6cb030ce37.jpg' to 'CNN_Train/D'.
    Moved 'S19_jpg.rf.f13dfc282ee341b185a0c7ad26888cbb.jpg' to 'CNN_Train/S'.
    Moved 'L24_jpg.rf.de942fed1590df6c1470817a21246deb.jpg' to 'CNN_Train/L'.
    Moved 'F1_jpg.rf.f758f32cb0632d711577bbf7dd0797f3.jpg' to 'CNN_Train/F'.
    Moved 'D24_jpg.rf.6febc371f35b6c99a7426f51e9e7f95f.jpg' to 'CNN_Train/D'.
    Moved 'E1_jpg.rf.bb58cbde3ccebc11ebdc7702013c6501.jpg' to 'CNN_Train/E'.
    Moved 'A0_jpg.rf.beea8a405220871911fb117e36526deb.jpg' to 'CNN_Train/A'.
    Moved 'X7_jpg.rf.a20e2172a3876ca86d90bdd5e3f08533.jpg' to 'CNN_Train/X'.
    Moved 'Z21_jpg.rf.95c18c5e627bef4b90a5755dd3c6e0b9.jpg' to 'CNN_Train/Z'.
    Moved 'D25_jpg.rf.daa2386d3e6c71b7a45d096b8948fba9.jpg' to 'CNN_Train/D'.
    Moved 'O7_jpg.rf.0eaee8009ec2d93d7381f32044ff1194.jpg' to 'CNN_Train/O'.
    Moved 'C7_jpg.rf.a5fd0ae832514603b91bffc155131179.jpg' to 'CNN_Train/C'.
    Moved 'D21_jpg.rf.8d3f3f78b3eaf92552b25bbda9f953f2.jpg' to 'CNN_Train/D'.
    Moved 'K14_jpg.rf.92a41509ab493797be58b95fa0427300.jpg' to 'CNN_Train/K'.
    Moved 'V9_jpg.rf.20b7f97dac844ea8738f9f488ec4e25a.jpg' to 'CNN_Train/V'.
    Moved 'I3_jpg.rf.4d858687a500b71952d8c05916e6c664.jpg' to 'CNN_Train/I'.
    Moved 'O19_jpg.rf.737f00e3fbeb99c9b89b4d7ade2481e6.jpg' to 'CNN_Train/O'.
    Moved 'Q0_jpg.rf.20d6987cbda94530e2817f1e11ee6f74.jpg' to 'CNN_Train/Q'.
    Moved 'P3_jpg.rf.3afc126bea6d81c266ff1b44e4140c0d.jpg' to 'CNN_Train/P'.
    Moved 'H12_jpg.rf.c6e4d175bd242e793456f9a8dfad8bba.jpg' to 'CNN_Train/H'.
    Moved 'K11_jpg.rf.3f4cc1dc342987f0cc293ae1f3cae8cd.jpg' to 'CNN_Train/K'.
    Moved 'G17_jpg.rf.f6962a9c3f1184f4ae27105a2faa805f.jpg' to 'CNN_Train/G'.
    Moved 'U8_jpg.rf.94750074ee39958f86fe161f66c9782e.jpg' to 'CNN_Train/U'.
    Moved 'M1_jpg.rf.bcdac9f6a7e836fd4b94160062941c5e.jpg' to 'CNN_Train/M'.
    Moved 'Q1_jpg.rf.3fe3fa0e6a56f3183eb66124117a35fe.jpg' to 'CNN_Train/Q'.
    Moved 'P14_jpg.rf.1dc01fbdf79f9ddbdf94146a8313a452.jpg' to 'CNN_Train/P'.
    Moved 'O16_jpg.rf.feb5c92d910c1c918c234c26dfd7a102.jpg' to 'CNN_Train/O'.
    Moved 'H12_jpg.rf.5239390ece4088ec70751c96cc04c7af.jpg' to 'CNN_Train/H'.
    Moved 'T9_jpg.rf.c607f88c2d171ab2e0b720e3aedf1fb1.jpg' to 'CNN_Train/T'.
    Moved 'W5_jpg.rf.8ac4994036346ca75709ae9b32fe1346.jpg' to 'CNN_Train/W'.
    Moved 'C16_jpg.rf.8f1a72f117c660c87d1dd4129d41a4b7.jpg' to 'CNN_Train/C'.
    Moved 'S29_jpg.rf.b661aab69dbd76c5252db309fcd420c3.jpg' to 'CNN_Train/S'.
    Moved 'B11_jpg.rf.8e133c2f504842695f2a074e464141a9.jpg' to 'CNN_Train/B'.
    Moved 'P12_jpg.rf.54fa3c2b8bb09e2943b416ab3beec718.jpg' to 'CNN_Train/P'.
    Moved 'Q6_jpg.rf.639c5cc2db5dee9b172d97b97879bced.jpg' to 'CNN_Train/Q'.
    Moved 'E14_jpg.rf.fb5d06769bdb07178e6e3df3a3b63d88.jpg' to 'CNN_Train/E'.
    Moved 'L21_jpg.rf.8ab635023c1c27721280a23be88151ed.jpg' to 'CNN_Train/L'.
    Moved 'J31_jpg.rf.c86ea0e7ec45d8528e11306c8a70aa5d.jpg' to 'CNN_Train/J'.
    Moved 'W18_jpg.rf.53d0cf305fd4724556b411dd76363814.jpg' to 'CNN_Train/W'.
    Moved 'R7_jpg.rf.79a0d01d7dec5037a239d1539a24d77e.jpg' to 'CNN_Train/R'.
    Moved 'Z7_jpg.rf.7cb4950bf562f45d9101d6991f9adf2a.jpg' to 'CNN_Train/Z'.
    Moved 'E6_jpg.rf.e2d1308b9968734f373ea55c15f17ba4.jpg' to 'CNN_Train/E'.
    Moved 'V18_jpg.rf.0a1f6c6de13a46327284a44ca57dd0e7.jpg' to 'CNN_Train/V'.
    Moved 'Q19_jpg.rf.b85a401d4a1deb785663283cf053f985.jpg' to 'CNN_Train/Q'.
    Moved 'Z8_jpg.rf.2d9d5a30a4d9248bc91940c7c0fca4ef.jpg' to 'CNN_Train/Z'.
    Moved 'I1_jpg.rf.ea33db5925da9b8c524fa15ab6311037.jpg' to 'CNN_Train/I'.
    Moved 'S10_jpg.rf.718df1410683539001eb344f2726ae41.jpg' to 'CNN_Train/S'.
    Moved 'W15_jpg.rf.20b4e1c09feff66baa17250e1d3bdc82.jpg' to 'CNN_Train/W'.
    Moved 'Q24_jpg.rf.e6c835daf931b91866d0b232a95abde2.jpg' to 'CNN_Train/Q'.
    Moved 'I18_jpg.rf.4d1c8f0e37cae1a7436fa975e7fdaf0c.jpg' to 'CNN_Train/I'.
    Moved 'N25_jpg.rf.bc9762401ff30806b764265cdf4cc5c3.jpg' to 'CNN_Train/N'.
    Moved 'G25_jpg.rf.e5a3c518c05033164c4b083441e6f929.jpg' to 'CNN_Train/G'.
    Moved 'F10_jpg.rf.7b3d024294d6ec1648a41eef7cf4b16f.jpg' to 'CNN_Train/F'.
    Moved 'S15_jpg.rf.10ffedc6bc40428d27640dae05f419ab.jpg' to 'CNN_Train/S'.
    Moved 'O21_jpg.rf.9f43bdfad676f0d97c1bbf7cac946f16.jpg' to 'CNN_Train/O'.
    Moved 'Y3_jpg.rf.ee6b439eec8f20ddd48407fe96386d10.jpg' to 'CNN_Train/Y'.
    Moved 'H23_jpg.rf.941cbff394281a33330d71c5219664c5.jpg' to 'CNN_Train/H'.
    Moved 'I4_jpg.rf.062ccd81c673900bff7ea0de9a398daa.jpg' to 'CNN_Train/I'.
    Moved 'E11_jpg.rf.cfb557e119c9bd2122afc43e476fd520.jpg' to 'CNN_Train/E'.
    Moved 'L23_jpg.rf.0418069709eebdee55bc946fa4080bc1.jpg' to 'CNN_Train/L'.
    Moved 'G28_jpg.rf.835836116a319b633e705f59454c8fb0.jpg' to 'CNN_Train/G'.
    Moved 'K22_jpg.rf.fd450e9793f7eee767b95462a1c5a1c6.jpg' to 'CNN_Train/K'.
    Moved 'H11_jpg.rf.2ad995e8992c5bb20f26b49b384c9dfc.jpg' to 'CNN_Train/H'.
    Moved 'D10_jpg.rf.d246872b276062f3209d89e89ebb32b7.jpg' to 'CNN_Train/D'.
    Moved 'C7_jpg.rf.9990a91baa98e68238716439a5128017.jpg' to 'CNN_Train/C'.
    Moved 'P6_jpg.rf.c7fab758b5d67e87c1141a9f8b6cf109.jpg' to 'CNN_Train/P'.
    Moved 'Q4_jpg.rf.16f4e350c0cbfa1238a5a74dfa212e7b.jpg' to 'CNN_Train/Q'.
    Moved 'Z8_jpg.rf.2568ebce12fca75ea01fdba52145402f.jpg' to 'CNN_Train/Z'.
    Moved 'W1_jpg.rf.c70229091f5f20b44d3081d960f4f0b8.jpg' to 'CNN_Train/W'.
    Moved 'J31_jpg.rf.5d1f6a93e11cc7a83e1008aecdb8530a.jpg' to 'CNN_Train/J'.
    Moved 'O6_jpg.rf.549cefc0888919b0e25fc3c940e24660.jpg' to 'CNN_Train/O'.
    Moved 'R10_jpg.rf.3104d68ab7dbb2fc602a330051b54f5c.jpg' to 'CNN_Train/R'.
    Moved 'U0_jpg.rf.a351d1815bff0e5e27a706d8fcf6f708.jpg' to 'CNN_Train/U'.
    Moved 'J34_jpg.rf.0263901188a9de96c9bca11274a772ab.jpg' to 'CNN_Train/J'.
    Moved 'N4_jpg.rf.672fee7e550531a34318d29d779d82b3.jpg' to 'CNN_Train/N'.
    Moved 'X11_jpg.rf.b70080abecd5dd21890ea4bd42f84434.jpg' to 'CNN_Train/X'.
    Moved 'N14_jpg.rf.d66ec48459ea666c501a97d360d8b769.jpg' to 'CNN_Train/N'.
    Moved 'H2_jpg.rf.5500497089d9120021b30101f04af9b8.jpg' to 'CNN_Train/H'.
    Moved 'M11_jpg.rf.af0e689c003d02775b2028011bf46500.jpg' to 'CNN_Train/M'.
    Moved 'K2_jpg.rf.17dba52b3990a4256016a9eb98cc6566.jpg' to 'CNN_Train/K'.
    Moved 'X4_jpg.rf.4e213026519c3044af45fe48a6be40b3.jpg' to 'CNN_Train/X'.
    Moved 'R9_jpg.rf.2910775cee2e06ac1c54f826e5f75add.jpg' to 'CNN_Train/R'.
    Moved 'C2_jpg.rf.94bb6cb403336400fa4bb229a29a5001.jpg' to 'CNN_Train/C'.
    Moved 'A26_jpg.rf.df50493a9970cad3fcc2f942da008969.jpg' to 'CNN_Train/A'.
    Moved 'Y14_jpg.rf.54a7803bf94584c0168844c3f358cc41.jpg' to 'CNN_Train/Y'.
    Moved 'C5_jpg.rf.99f22f57fc49f96914ae0b15bf18e590.jpg' to 'CNN_Train/C'.
    Moved 'E15_jpg.rf.6cea2b32a4805735fe5fed0e95ef23e8.jpg' to 'CNN_Train/E'.
    Moved 'F2_jpg.rf.d32078d29c977657aedfd6795a524a81.jpg' to 'CNN_Train/F'.
    Moved 'C5_jpg.rf.e16c2a097b885c325d790d56c39c3ce9.jpg' to 'CNN_Train/C'.
    Moved 'S26_jpg.rf.a5eecb26e2c6b281d86754c20e25c5a9.jpg' to 'CNN_Train/S'.
    Moved 'A12_jpg.rf.cf08b7c130475ef3bb26c390fb8e420d.jpg' to 'CNN_Train/A'.
    Moved 'C24_jpg.rf.b8cbb833603ebbf09d3e80929b57be9d.jpg' to 'CNN_Train/C'.
    Moved 'H9_jpg.rf.8ff9debc87f4e7a471620ebb53781ff7.jpg' to 'CNN_Train/H'.
    Moved 'D14_jpg.rf.83c48289205bac79f5ded79dae8c89c1.jpg' to 'CNN_Train/D'.
    Moved 'N2_jpg.rf.d17742108eb47932d82859f6c6a4ff70.jpg' to 'CNN_Train/N'.
    Moved 'Z19_jpg.rf.f7f85dbd2e22f4e7415454a80e2cd51e.jpg' to 'CNN_Train/Z'.
    Moved 'P11_jpg.rf.51d452c429f95a0b3980af6d04b96a24.jpg' to 'CNN_Train/P'.
    Moved 'Z17_jpg.rf.c0eb891370348e27317a438ffadad81e.jpg' to 'CNN_Train/Z'.
    Moved 'L2_jpg.rf.c9a43ec25132c92ecb347b8e24c376dd.jpg' to 'CNN_Train/L'.
    Moved 'C6_jpg.rf.4a61ae566ed0f8a43b664e763cbce85d.jpg' to 'CNN_Train/C'.
    Moved 'A28_jpg.rf.89b547e86e0129b28e5ec9a0f0dc2ed2.jpg' to 'CNN_Train/A'.
    Moved 'W2_jpg.rf.6ee90ff8ce548d835f5b001b3af0ab42.jpg' to 'CNN_Train/W'.
    Moved 'H17_jpg.rf.62871b0da000b5a6d1556a77944934ec.jpg' to 'CNN_Train/H'.
    Moved 'C13_jpg.rf.8eef777130f21976679e4b061bf30662.jpg' to 'CNN_Train/C'.
    Moved 'D8_jpg.rf.54f406f5e4d67f3edcb85e711f72450d.jpg' to 'CNN_Train/D'.
    Moved 'Z10_jpg.rf.9943135cca98d2e9887c67a937cd7fb4.jpg' to 'CNN_Train/Z'.
    Moved 'J34_jpg.rf.72b4fa826c3a86e054efb29ff17b98fc.jpg' to 'CNN_Train/J'.
    Moved 'T0_jpg.rf.5423681b3980accb3283c6ce648f141f.jpg' to 'CNN_Train/T'.
    Moved 'W9_jpg.rf.d1ee0477e52c34c22c16d1144a9ac94f.jpg' to 'CNN_Train/W'.
    Moved 'Q17_jpg.rf.6cbc5952b65a284bfce8caaee4794e56.jpg' to 'CNN_Train/Q'.
    Moved 'Y4_jpg.rf.26c328b536ab67549fff202d6c8b57ac.jpg' to 'CNN_Train/Y'.
    Moved 'A6_jpg.rf.705f49da7ca17d45761036a033a8330d.jpg' to 'CNN_Train/A'.
    Moved 'I14_jpg.rf.f2e145f91ec5bc1921ce058078c73aea.jpg' to 'CNN_Train/I'.
    Moved 'X25_jpg.rf.806e8ab40c1468fafd8d8d989e2c3d80.jpg' to 'CNN_Train/X'.
    Moved 'N25_jpg.rf.4b16bfc968c7c1a77e53212a84a5a259.jpg' to 'CNN_Train/N'.
    Moved 'U4_jpg.rf.53f7810a427914bca323faa6e1309328.jpg' to 'CNN_Train/U'.
    Moved 'H2_jpg.rf.e08f1a1a0ee918fb196b0ace89c47aee.jpg' to 'CNN_Train/H'.
    Moved 'F21_jpg.rf.8a1bef00c6c060bb6d20a2049e524916.jpg' to 'CNN_Train/F'.
    Moved 'S24_jpg.rf.f8b1a050d76003e6e8479fd3447787c6.jpg' to 'CNN_Train/S'.
    Moved 'G19_jpg.rf.2eb8c3a2a40db346a865d9176d5e85d9.jpg' to 'CNN_Train/G'.
    Moved 'O7_jpg.rf.d178e278299696e1e5822759066b8272.jpg' to 'CNN_Train/O'.
    Moved 'D9_jpg.rf.3250856285c1a522ba86b3135b5dd6bc.jpg' to 'CNN_Train/D'.
    Moved 'O10_jpg.rf.738f34160331284332b6641740b596f3.jpg' to 'CNN_Train/O'.
    Moved 'J20_jpg.rf.38479eca7c67ff9cd7930c7b103f6701.jpg' to 'CNN_Train/J'.
    Moved 'Z28_jpg.rf.56abff244017624ad386bb7036b39927.jpg' to 'CNN_Train/Z'.
    Moved 'Y2_jpg.rf.c953e242457ab91cf6a7d2502051aa7c.jpg' to 'CNN_Train/Y'.
    Moved 'C7_jpg.rf.153d4f0a86e41d21494e749ec943ff30.jpg' to 'CNN_Train/C'.
    Moved 'Q19_jpg.rf.06cebf7b976387ce82ab489130cec519.jpg' to 'CNN_Train/Q'.
    Moved 'M21_jpg.rf.875ea05a3363bd6af7c438b5b172b7d1.jpg' to 'CNN_Train/M'.
    Moved 'K21_jpg.rf.dbd67c303fb29881ac659f9e9353c4b7.jpg' to 'CNN_Train/K'.
    Moved 'F23_jpg.rf.683b7749581139984a7ed72f69c26c72.jpg' to 'CNN_Train/F'.
    Moved 'C21_jpg.rf.acf50ed5e3a1dd34d903ba5769a62319.jpg' to 'CNN_Train/C'.
    Moved 'S1_jpg.rf.f054ea86602eb9790a0b131f502e1ba0.jpg' to 'CNN_Train/S'.
    Moved 'P13_jpg.rf.21e34a0348f90689c6c49746ff91336c.jpg' to 'CNN_Train/P'.
    Moved 'Z19_jpg.rf.1ef6efbd8ee8867d44b3cb300cfded3f.jpg' to 'CNN_Train/Z'.
    Moved 'L9_jpg.rf.18fb3c7dce9d787bca991b1a76776261.jpg' to 'CNN_Train/L'.
    Moved 'G29_jpg.rf.0d1ebc2b56c839d26c50c9cfa27f95af.jpg' to 'CNN_Train/G'.
    Moved 'M15_jpg.rf.c4e348d86e294476726358d17432a750.jpg' to 'CNN_Train/M'.
    Moved 'V15_jpg.rf.72f8ed121d02ecb661d91b151ef890e0.jpg' to 'CNN_Train/V'.
    Moved 'L8_jpg.rf.78a38f69775f7d484a3458d8c5672374.jpg' to 'CNN_Train/L'.
    Moved 'U10_jpg.rf.686a9ed2a15beba1eb56f6cdaf8d309b.jpg' to 'CNN_Train/U'.
    Moved 'J17_jpg.rf.33b53f00f2a409ae181820e821ec0c99.jpg' to 'CNN_Train/J'.
    Moved 'S3_jpg.rf.519338be5baea0d10b44063693384d32.jpg' to 'CNN_Train/S'.
    Moved 'W8_jpg.rf.eba26439311bef07331e1638551dff7c.jpg' to 'CNN_Train/W'.
    Moved 'N24_jpg.rf.0e240f7a8c43532a802e97e76fa1ad8b.jpg' to 'CNN_Train/N'.
    Moved 'H4_jpg.rf.5d2d0418f75c97688edbefb414df3efe.jpg' to 'CNN_Train/H'.
    Moved 'Y12_jpg.rf.9c7bc875dd16f637f5b0c509775baa7b.jpg' to 'CNN_Train/Y'.
    Moved 'O26_jpg.rf.c479cbbfa52e8717c9a1c96fbe5357b4.jpg' to 'CNN_Train/O'.
    Moved 'I3_jpg.rf.cddc9518039dae2728a1c293af20055b.jpg' to 'CNN_Train/I'.
    Moved 'A11_jpg.rf.ff2610c21c7f6d0a793cb58efc3bd96e.jpg' to 'CNN_Train/A'.
    Moved 'V15_jpg.rf.29a167f2f0b250c923bf4d3748b1691d.jpg' to 'CNN_Train/V'.
    Moved 'Q13_jpg.rf.4adb3d65e8f45c6d1fd51ea6ae071271.jpg' to 'CNN_Train/Q'.
    Moved 'C13_jpg.rf.0d4790015527485bc617b20b127a9044.jpg' to 'CNN_Train/C'.
    Moved 'Y14_jpg.rf.e81b709ae7138dfc2d91a1b48def18b1.jpg' to 'CNN_Train/Y'.
    Moved 'G10_jpg.rf.09d37c9b35d2d18288601e9af1b0c6aa.jpg' to 'CNN_Train/G'.
    Moved 'A15_jpg.rf.864da902c564388b8d55ea151f88cb2f.jpg' to 'CNN_Train/A'.
    Moved 'G8_jpg.rf.8f8d46c6c308f54ab98f9464806f86f7.jpg' to 'CNN_Train/G'.
    Moved 'S9_jpg.rf.2f8f58716b3ec8ff40d81f06bccc9b41.jpg' to 'CNN_Train/S'.
    Moved 'F16_jpg.rf.ea3e041644a7b76f830589aba2b1fbde.jpg' to 'CNN_Train/F'.
    Moved 'G29_jpg.rf.88efa90e9360c7d3c45453fbd6ce0d4b.jpg' to 'CNN_Train/G'.
    Moved 'N26_jpg.rf.e1eb13936e283c03a3fabceb5366c84b.jpg' to 'CNN_Train/N'.
    Moved 'M23_jpg.rf.a18313130a192cb95e5bc7edfedebfd7.jpg' to 'CNN_Train/M'.
    Moved 'S25_jpg.rf.02bfc4e839ba3b795c16dc1a21f958dc.jpg' to 'CNN_Train/S'.
    Moved 'L4_jpg.rf.26fe4ec6ee5b2a7f18a40972f3ca0cf2.jpg' to 'CNN_Train/L'.
    Moved 'I20_jpg.rf.1f767dcc423ec7719b9e0e90f7ad3e42.jpg' to 'CNN_Train/I'.
    Moved 'S28_jpg.rf.015ec81f1c531610f515d4135ae7a335.jpg' to 'CNN_Train/S'.
    Moved 'S25_jpg.rf.09d0d2f747a7b9141a846f0c83dc4883.jpg' to 'CNN_Train/S'.
    Moved 'X10_jpg.rf.e529ef4fe20efb544d9c6af051f8e099.jpg' to 'CNN_Train/X'.
    Moved 'Y1_jpg.rf.3291c526239fe499e71074ac7b608064.jpg' to 'CNN_Train/Y'.
    Moved 'O9_jpg.rf.c61fbc9b1ec68349f5f7da3f96451e82.jpg' to 'CNN_Train/O'.
    Moved 'G25_jpg.rf.cb869f53cf2ce3aa198d100df9219ddd.jpg' to 'CNN_Train/G'.
    Moved 'A18_jpg.rf.0f95cca1e829561f56abd4409ca20370.jpg' to 'CNN_Train/A'.
    Moved 'E3_jpg.rf.b7eb371c8ae5a02ac732cb5c3f471525.jpg' to 'CNN_Train/E'.
    Moved 'F28_jpg.rf.01de9888a0d78bebc1fbb6b841fdef6e.jpg' to 'CNN_Train/F'.
    Moved 'D27_jpg.rf.b458c2d4f8fb31a741c84c5f331cdf70.jpg' to 'CNN_Train/D'.
    Moved 'X0_jpg.rf.4f091a725fa4add0baa525d84e695743.jpg' to 'CNN_Train/X'.
    Moved 'L12_jpg.rf.569ab0b8db5ad7708d32ac12ba7c7405.jpg' to 'CNN_Train/L'.
    Moved 'T6_jpg.rf.057836f5c842cf3781bf2bf3183ea5fc.jpg' to 'CNN_Train/T'.
    Moved 'Y6_jpg.rf.85511be5d3fa7e4217fe984101e31189.jpg' to 'CNN_Train/Y'.
    Moved 'O18_jpg.rf.64adb5ed40e2fdfbe95507b0e04cc8fb.jpg' to 'CNN_Train/O'.
    Moved 'F9_jpg.rf.bb7bbcfaa4bd49d32055ec51fddb20b7.jpg' to 'CNN_Train/F'.
    Moved 'X3_jpg.rf.8aada5f5216964acbe1a7059df6fd570.jpg' to 'CNN_Train/X'.
    Moved 'X21_jpg.rf.f7dcb8c4df1b628a748a0552457fdaf5.jpg' to 'CNN_Train/X'.
    Moved 'P6_jpg.rf.22a89cc3ab41c1980a5b9a92398d799b.jpg' to 'CNN_Train/P'.
    Moved 'M11_jpg.rf.b8db8602a4b524db3282fe13adea2e75.jpg' to 'CNN_Train/M'.
    Moved 'V17_jpg.rf.18801d8e6ad486e7e038a1565ebf1736.jpg' to 'CNN_Train/V'.
    Moved 'E19_jpg.rf.8fbfc3b0366982613362c159365d1184.jpg' to 'CNN_Train/E'.
    Moved 'Q5_jpg.rf.6950fad6e3271e171f18c623a76351da.jpg' to 'CNN_Train/Q'.
    Moved 'W17_jpg.rf.4653c954edbe027131c19e85f29305a8.jpg' to 'CNN_Train/W'.
    Moved 'G27_jpg.rf.c828cf1e5c3b95904019ba86b00721f2.jpg' to 'CNN_Train/G'.
    Moved 'J1_jpg.rf.b0139cd665378717a7b15ade98c6e1e3.jpg' to 'CNN_Train/J'.
    Moved 'Y6_jpg.rf.e8d090388111cfc7121dde38abaf0393.jpg' to 'CNN_Train/Y'.
    Moved 'T10_jpg.rf.03c9848b08c3ed3a90ab61ab89989920.jpg' to 'CNN_Train/T'.
    Moved 'Z24_jpg.rf.0defec3939772e6e585c757e2d83cbcb.jpg' to 'CNN_Train/Z'.
    Moved 'S28_jpg.rf.81e8e1266bdac0df72d3dbf208d44e56.jpg' to 'CNN_Train/S'.
    Moved 'N17_jpg.rf.2ae0cad9995923d2a5e732cd45b88a7a.jpg' to 'CNN_Train/N'.
    Moved 'D24_jpg.rf.83b837eb94ded68cc499bbcebb48cd93.jpg' to 'CNN_Train/D'.
    Moved 'S8_jpg.rf.a6fc375e5671f87b32ca0d691750a310.jpg' to 'CNN_Train/S'.
    Moved 'B16_jpg.rf.abc30cf469e74a3ca3ebe2242a9380ae.jpg' to 'CNN_Train/B'.
    Moved 'W18_jpg.rf.88a2d1c4c0d79d673e3e910a9f11bdb8.jpg' to 'CNN_Train/W'.
    Moved 'L12_jpg.rf.34dafed010cca8b7e44c68bfb3565eee.jpg' to 'CNN_Train/L'.
    Moved 'M2_jpg.rf.532390288aeaf32238115b13d1526d31.jpg' to 'CNN_Train/M'.
    Moved 'B7_jpg.rf.6d8e67f52ae87d4c5bc21cb36134202a.jpg' to 'CNN_Train/B'.
    Moved 'L16_jpg.rf.f4cfa21819dba119681069bd578a9ee1.jpg' to 'CNN_Train/L'.
    Moved 'E5_jpg.rf.8b50892e6dda6c506cccd3c28a9bc345.jpg' to 'CNN_Train/E'.
    Moved 'O10_jpg.rf.40a31895060cd143e4af6bb0958b632d.jpg' to 'CNN_Train/O'.
    Moved 'T9_jpg.rf.4a416bb3133ec9135d7cfd16d2ff5c04.jpg' to 'CNN_Train/T'.
    Moved 'X21_jpg.rf.6d5aa7c163e8126919e743c328757527.jpg' to 'CNN_Train/X'.
    Moved 'S7_jpg.rf.a423893b49860b7891ec1c8cc97936ca.jpg' to 'CNN_Train/S'.
    Moved 'V1_jpg.rf.ff213cfdd31a9b708ea3dc13fbb66bf0.jpg' to 'CNN_Train/V'.
    Moved 'T0_jpg.rf.fb829f844b8e5ccfaf9a14d4710c67ee.jpg' to 'CNN_Train/T'.
    Moved 'F12_jpg.rf.e5920ef120c3440576122c11b141be0f.jpg' to 'CNN_Train/F'.
    Moved 'B16_jpg.rf.4ad8c01d9397ef029a65dd0413e61dd7.jpg' to 'CNN_Train/B'.
    Moved 'J22_jpg.rf.0a2a945c3728602d25182355cfad1cd6.jpg' to 'CNN_Train/J'.
    Moved 'W17_jpg.rf.7269833fa03d4962655240ad24e39cff.jpg' to 'CNN_Train/W'.
    Moved 'X8_jpg.rf.e3c0763e1f03984aed3dfa0b378ee43b.jpg' to 'CNN_Train/X'.
    Moved 'D22_jpg.rf.2713c3dcf25bc42a47fc94f8b348c215.jpg' to 'CNN_Train/D'.
    Moved 'C10_jpg.rf.20f3f451bdf05f7e5f606e69e90ca19e.jpg' to 'CNN_Train/C'.
    Moved 'N11_jpg.rf.cbf31312b398614771001104ee946bae.jpg' to 'CNN_Train/N'.
    Moved 'H7_jpg.rf.43f9bd777535c133be749dd7a2a02f94.jpg' to 'CNN_Train/H'.
    Moved 'D19_jpg.rf.af3390525da00a182d7714b628b21890.jpg' to 'CNN_Train/D'.
    Moved 'I4_jpg.rf.ad9df1e05c3fa1a8d864a6168795b84d.jpg' to 'CNN_Train/I'.
    Moved 'A19_jpg.rf.7e2d39113f47c5516c279bcc8d4ff305.jpg' to 'CNN_Train/A'.
    Moved 'D14_jpg.rf.cd874c8d44a1be91c3a1751d7d79fbe1.jpg' to 'CNN_Train/D'.
    Moved 'A2_jpg.rf.e4d1f7a2679ab0140ad27a794db563c9.jpg' to 'CNN_Train/A'.
    Moved 'T15_jpg.rf.d5370e2e397eaf7645e52b7f03ea2f16.jpg' to 'CNN_Train/T'.
    Moved 'P4_jpg.rf.5740f4225d8ac5e92cb8a3143c7a064b.jpg' to 'CNN_Train/P'.
    Moved 'K18_jpg.rf.1031d048282a1171d305bcccdae086cc.jpg' to 'CNN_Train/K'.
    Moved 'I27_jpg.rf.ec2db890358f17869292a25ab56301b1.jpg' to 'CNN_Train/I'.
    Moved 'Y24_jpg.rf.f709576840a8869762c9229ab9da422a.jpg' to 'CNN_Train/Y'.
    Moved 'L21_jpg.rf.7871d15d95932860cb2bec9bb5062889.jpg' to 'CNN_Train/L'.
    Moved 'U23_jpg.rf.58bb2072e58c0111cf8a50ad02811446.jpg' to 'CNN_Train/U'.
    Moved 'R19_jpg.rf.d974cf4fad92cbbb0d00a55c84f88f3d.jpg' to 'CNN_Train/R'.
    Moved 'F26_jpg.rf.fe466776eeab5aece3ac0076fb3d0540.jpg' to 'CNN_Train/F'.
    Moved 'E23_jpg.rf.b8e85cba1d6178061f8564c7800c9f3e.jpg' to 'CNN_Train/E'.
    Moved 'Z15_jpg.rf.a12770795bcce108029932e638b65a8f.jpg' to 'CNN_Train/Z'.
    Moved 'Z13_jpg.rf.e33586c5b5871cf4e96eca9d08786aed.jpg' to 'CNN_Train/Z'.
    Moved 'B18_jpg.rf.3bcb3d00d3926a2486cbc51c5c42c0c1.jpg' to 'CNN_Train/B'.
    Moved 'Z19_jpg.rf.576d00ed48270b45b9a9739b5d067d6e.jpg' to 'CNN_Train/Z'.
    Moved 'P14_jpg.rf.ab7961dc546796b871d4d1d4249712b6.jpg' to 'CNN_Train/P'.
    Moved 'D3_jpg.rf.1d937c0e64141083b4b634f3b9a7eea9.jpg' to 'CNN_Train/D'.
    Moved 'Q1_jpg.rf.549679ae70c7c702815a3e63fac77cee.jpg' to 'CNN_Train/Q'.
    Moved 'B11_jpg.rf.cccec888adf53cd42f03493fc3806852.jpg' to 'CNN_Train/B'.
    Moved 'S15_jpg.rf.2df0e77b22859f563d942c137c3425b8.jpg' to 'CNN_Train/S'.
    Moved 'J30_jpg.rf.00d20e595026b31773ded47509545471.jpg' to 'CNN_Train/J'.
    Moved 'U1_jpg.rf.4493fcffd1fbc47abc773a4872208b08.jpg' to 'CNN_Train/U'.
    Moved 'D3_jpg.rf.80f42802671cc6eb10df55ebf1e6c5fd.jpg' to 'CNN_Train/D'.
    Moved 'Y16_jpg.rf.f88141a53950c838940912dcb3f65de0.jpg' to 'CNN_Train/Y'.
    Moved 'U7_jpg.rf.0037faea78f8a89329a93006132921b3.jpg' to 'CNN_Train/U'.
    Moved 'Y22_jpg.rf.c246835235cca560199ae2ca06a79847.jpg' to 'CNN_Train/Y'.
    Moved 'D6_jpg.rf.77a2c550063bcf698e4ad12498fdd339.jpg' to 'CNN_Train/D'.
    Moved 'I10_jpg.rf.85fea4ba832e90b3a943395089d8d558.jpg' to 'CNN_Train/I'.
    Moved 'X17_jpg.rf.2cd75bf770afb6d9f0866ab3de70b333.jpg' to 'CNN_Train/X'.
    Moved 'F18_jpg.rf.d41f24b48de964abf281fa96483b0ac7.jpg' to 'CNN_Train/F'.
    Moved 'K19_jpg.rf.9ac499864f6bc7acee8d944adf36bb5b.jpg' to 'CNN_Train/K'.
    Moved 'F18_jpg.rf.33f3170d173a45d53020b5ec05f14177.jpg' to 'CNN_Train/F'.
    Moved 'I5_jpg.rf.77b81a33d4ef3602a2a701c89c871213.jpg' to 'CNN_Train/I'.
    Moved 'A25_jpg.rf.433d7879c39d43659d5ec56d0d55bb8f.jpg' to 'CNN_Train/A'.
    Moved 'Y2_jpg.rf.5fcab7c7743730aacebb649af41e8355.jpg' to 'CNN_Train/Y'.
    Moved 'Y9_jpg.rf.fe9c63458e0f5a64a7116a6a6b76405f.jpg' to 'CNN_Train/Y'.
    Moved 'F20_jpg.rf.7daa4728bbca605707e66e384e94efd6.jpg' to 'CNN_Train/F'.
    Moved 'Z20_jpg.rf.93f86ccdef0af86d8cf8cca85677656c.jpg' to 'CNN_Train/Z'.
    Moved 'H2_jpg.rf.38670f1a9c2ae2036f3c80321491573c.jpg' to 'CNN_Train/H'.
    Moved 'E2_jpg.rf.a43f19cc5803acef271706896a228162.jpg' to 'CNN_Train/E'.
    Moved 'I8_jpg.rf.6b7ed6a1aa535d84b7d5762ba3b4e813.jpg' to 'CNN_Train/I'.
    Moved 'S10_jpg.rf.c8dbcf718fe09bc3f9f91e1b595c10e1.jpg' to 'CNN_Train/S'.
    Moved 'Y6_jpg.rf.0b311cacca85c70b2e58d387a50b8788.jpg' to 'CNN_Train/Y'.
    Moved 'G12_jpg.rf.f77b63ee01095f0efd64a567048192ff.jpg' to 'CNN_Train/G'.
    Moved 'S26_jpg.rf.06beeb7d442a1a2fd82c42b68ce5f277.jpg' to 'CNN_Train/S'.
    Moved 'C18_jpg.rf.d5fc15e61a0181749c2f962c466f0714.jpg' to 'CNN_Train/C'.
    Moved 'H10_jpg.rf.e6f6ebec686326ec4ac840d649348975.jpg' to 'CNN_Train/H'.
    Moved 'J15_jpg.rf.d99334d431315f29da4cd24d4d649a21.jpg' to 'CNN_Train/J'.
    Moved 'Z7_jpg.rf.dc0f0cacd616f6d1009a7accd4ab0e2a.jpg' to 'CNN_Train/Z'.
    Moved 'N3_jpg.rf.9e0da901b299403c15147ae8c50d994e.jpg' to 'CNN_Train/N'.
    Moved 'U13_jpg.rf.22fadc75bccc7d4a8aae826d6d8a83dd.jpg' to 'CNN_Train/U'.
    Moved 'K4_jpg.rf.605ce13ae422d6f639de55692691009e.jpg' to 'CNN_Train/K'.
    Moved 'O6_jpg.rf.2706b558e6b555a698dcc7c175f7b53c.jpg' to 'CNN_Train/O'.
    Moved 'E13_jpg.rf.8c785e9344df3875623480965766142c.jpg' to 'CNN_Train/E'.
    Moved 'G1_jpg.rf.e22ffcdafc93d0f59f76e161f0398e8d.jpg' to 'CNN_Train/G'.
    Moved 'D11_jpg.rf.ef33772fdd1429b6d6f08aa5edabc04b.jpg' to 'CNN_Train/D'.
    Moved 'G2_jpg.rf.2bb4d04364c5e9af4fb6469ed97140e4.jpg' to 'CNN_Train/G'.
    Moved 'S7_jpg.rf.4fa907a7e1cb3135c192c8fa2dc3fda4.jpg' to 'CNN_Train/S'.
    Moved 'N7_jpg.rf.2b30106404da5acfd47032fdd390fdd0.jpg' to 'CNN_Train/N'.
    Moved 'X22_jpg.rf.05732e3e92b7d7abbba7c3eb54b022b8.jpg' to 'CNN_Train/X'.
    Moved 'T15_jpg.rf.615b07342ad9ad4ef4ab50e33f15ea86.jpg' to 'CNN_Train/T'.
    Moved 'V5_jpg.rf.8ea4e30d9a7bc6e92bc4c23147c0e4a4.jpg' to 'CNN_Train/V'.
    Moved 'V22_jpg.rf.901660086a0b7f81b683b913de8b2dbd.jpg' to 'CNN_Train/V'.
    Moved 'E22_jpg.rf.0d35c68e32b19d9a549399ba02f34469.jpg' to 'CNN_Train/E'.
    Moved 'J3_jpg.rf.a7e1e95ebc5aaf0ee5647e3cb2fb763c.jpg' to 'CNN_Train/J'.
    Moved 'S18_jpg.rf.26fae01896d770e3e5f3ec2eeeefb035.jpg' to 'CNN_Train/S'.
    Moved 'S20_jpg.rf.4c1445e9bcf4cc8670baf77a45acd14c.jpg' to 'CNN_Train/S'.
    Moved 'H23_jpg.rf.b8daa0441a0178d9496e6dcc003567c3.jpg' to 'CNN_Train/H'.
    Moved 'F15_jpg.rf.8ecd61d00c50966b18a478fe963c2356.jpg' to 'CNN_Train/F'.
    Moved 'G19_jpg.rf.25d4889a31164b3494f515798ea33f3e.jpg' to 'CNN_Train/G'.
    Moved 'X1_jpg.rf.3cccdc1794022c52d9d647df08942bcd.jpg' to 'CNN_Train/X'.
    Moved 'O5_jpg.rf.26378e1bbd33324ca6798e57eb7451a8.jpg' to 'CNN_Train/O'.
    Moved 'T23_jpg.rf.0f0cfab388c8caa6d1d60d56a19e4191.jpg' to 'CNN_Train/T'.
    Moved 'U20_jpg.rf.fb96046df59e2414e674582dc9c63583.jpg' to 'CNN_Train/U'.
    Moved 'A5_jpg.rf.8e80b6017d4cbe8756c372f28279e426.jpg' to 'CNN_Train/A'.
    Moved 'X3_jpg.rf.766ff8ea121f20b204ae9ff95550e791.jpg' to 'CNN_Train/X'.
    Moved 'X19_jpg.rf.39638b27f1b0cea46dfac471cadab50d.jpg' to 'CNN_Train/X'.
    Moved 'I29_jpg.rf.accebf92a36a2e237d47a354b6d5f18f.jpg' to 'CNN_Train/I'.
    Moved 'L7_jpg.rf.a4a99e404bc702e0354e4d0ef842a200.jpg' to 'CNN_Train/L'.
    Moved 'V20_jpg.rf.291705cde3583fa1336ed5505936c663.jpg' to 'CNN_Train/V'.
    Moved 'P4_jpg.rf.a3e9118aaea9823a0337b2b7b1be60ec.jpg' to 'CNN_Train/P'.
    Moved 'A4_jpg.rf.d03522dc177baa9498936c8f8d1ddca7.jpg' to 'CNN_Train/A'.
    Moved 'K11_jpg.rf.c77c63edd7459392f075467f98be8695.jpg' to 'CNN_Train/K'.
    Moved 'M27_jpg.rf.010d328cdc61a634aec1540863be23b9.jpg' to 'CNN_Train/M'.
    Moved 'V23_jpg.rf.903082420cc8f45124bfc52a417f67e2.jpg' to 'CNN_Train/V'.
    Moved 'E10_jpg.rf.3f2308817ab827f37fd416df0490b9c4.jpg' to 'CNN_Train/E'.
    Moved 'O24_jpg.rf.d91bd53448757ff1c2108f7510579223.jpg' to 'CNN_Train/O'.
    Moved 'R19_jpg.rf.5443f646062d2fdc9247fe2248995c89.jpg' to 'CNN_Train/R'.
    Moved 'N10_jpg.rf.3e94be30757dd080203abd8a966f5a89.jpg' to 'CNN_Train/N'.
    Moved 'Z5_jpg.rf.77815fbd61ec215d563a02911a47b9de.jpg' to 'CNN_Train/Z'.
    Moved 'J23_jpg.rf.5da77a10060d8ddb02727f9319b2d694.jpg' to 'CNN_Train/J'.
    Moved 'J2_jpg.rf.80abd0e0c48f73f8d31f18dbc61d41e5.jpg' to 'CNN_Train/J'.
    Moved 'A23_jpg.rf.199528cc21bad70f9424a2cfb92d3207.jpg' to 'CNN_Train/A'.
    Moved 'O19_jpg.rf.806a40141fb6a96bc9cc5ac4cf9d415b.jpg' to 'CNN_Train/O'.
    Moved 'U17_jpg.rf.9a958acd53e0030eefb8b627bd673fc4.jpg' to 'CNN_Train/U'.
    Moved 'I25_jpg.rf.c3b17ea0db97f65668c727a2191207df.jpg' to 'CNN_Train/I'.
    Moved 'E24_jpg.rf.e0373ac336a3057e59db86a7be244989.jpg' to 'CNN_Train/E'.
    Moved 'X8_jpg.rf.3d850cd69fadca04c34ea0d6e21bd0d1.jpg' to 'CNN_Train/X'.
    Moved 'G24_jpg.rf.2d7da0e518e9ec97adc32cb5324d3b5a.jpg' to 'CNN_Train/G'.
    Moved 'J36_jpg.rf.152d4c97591be177e8e079318443353f.jpg' to 'CNN_Train/J'.
    Moved 'A13_jpg.rf.4533aea9a6c32fecadcd1d1963e7dc78.jpg' to 'CNN_Train/A'.
    Moved 'L3_jpg.rf.ab68bd8183058f6a31848cb3d9e37b18.jpg' to 'CNN_Train/L'.
    Moved 'D13_jpg.rf.1a3dc1b3ba32f5a799de3f43ad095547.jpg' to 'CNN_Train/D'.
    Moved 'Y11_jpg.rf.ecccbf473066c8bc1ed46fc39fbdf828.jpg' to 'CNN_Train/Y'.
    Moved 'T14_jpg.rf.626d0233389df286553f913391e92a50.jpg' to 'CNN_Train/T'.
    Moved 'B13_jpg.rf.f57c9466c18d5e575acaafe326096478.jpg' to 'CNN_Train/B'.
    Moved 'E13_jpg.rf.8d68f0f191144ef3272f596f3b3ce637.jpg' to 'CNN_Train/E'.
    Moved 'D10_jpg.rf.8971201a8118bb6a6a70b219a2c0c1e3.jpg' to 'CNN_Train/D'.
    Moved 'X23_jpg.rf.8ff8efaa92cde6bb470f744dbad45f76.jpg' to 'CNN_Train/X'.
    Moved 'T20_jpg.rf.1a83ce62951b44181696195e1421ae9b.jpg' to 'CNN_Train/T'.
    Moved 'W9_jpg.rf.3354f7513a82092c7fc119d398ce205a.jpg' to 'CNN_Train/W'.
    Moved 'N12_jpg.rf.e0d9a443d10e6bc1dde50d47ff3949e0.jpg' to 'CNN_Train/N'.
    Moved 'A8_jpg.rf.b1f2cc51e5c09b11c614fecf4d2995f4.jpg' to 'CNN_Train/A'.
    Moved 'M13_jpg.rf.1fa25f00496dd516c39840a417137f60.jpg' to 'CNN_Train/M'.
    Moved 'N19_jpg.rf.919961328272d4434d7e604e11c25005.jpg' to 'CNN_Train/N'.
    Moved 'D13_jpg.rf.43b646db63d3edb337759e6108d70788.jpg' to 'CNN_Train/D'.
    Moved 'A21_jpg.rf.fd2750bdaf5dd91c308481964c85e985.jpg' to 'CNN_Train/A'.
    Moved 'R24_jpg.rf.34c0881c64093c0bee55f3cb196432aa.jpg' to 'CNN_Train/R'.
    Moved 'V24_jpg.rf.b0534d7dd8c3f70eeb7b03c59ea8d3c2.jpg' to 'CNN_Train/V'.
    Moved 'U23_jpg.rf.bda5444c4f270dedc6326b314abff183.jpg' to 'CNN_Train/U'.
    Moved 'O26_jpg.rf.5a108e7af0ac36cf632ffbf17c91164e.jpg' to 'CNN_Train/O'.
    Moved 'W12_jpg.rf.1e4f0a372c9e8fd0fc6de021539af12e.jpg' to 'CNN_Train/W'.
    Moved 'T20_jpg.rf.ba549b1fbd78f223da24c58d0e70ad28.jpg' to 'CNN_Train/T'.
    Moved 'B8_jpg.rf.b47d3b0de9b108a7f19a0084babe8636.jpg' to 'CNN_Train/B'.
    Moved 'H8_jpg.rf.c8ad771f06ce72cda8e302ece4f28fcf.jpg' to 'CNN_Train/H'.
    Moved 'R2_jpg.rf.a142629a8c0012120be00ed6e32e5e06.jpg' to 'CNN_Train/R'.
    Moved 'Z1_jpg.rf.b74a9ea1348a5ed008b4ca33c88d4f93.jpg' to 'CNN_Train/Z'.
    Moved 'D16_jpg.rf.7011c9a2b844ecbebf09f7321d46588d.jpg' to 'CNN_Train/D'.
    Moved 'L10_jpg.rf.be496128298735337ffeb94a3a1f33f3.jpg' to 'CNN_Train/L'.
    Moved 'C11_jpg.rf.34fb9796ca851b3ee71f5192d7282bc3.jpg' to 'CNN_Train/C'.
    Moved 'B18_jpg.rf.d81b3f6155fed0909953936a739bfedf.jpg' to 'CNN_Train/B'.
    Moved 'N25_jpg.rf.76a1e35c1de704bee09cbf7dcc6cee7b.jpg' to 'CNN_Train/N'.
    Moved 'N8_jpg.rf.6d28d8486b474c61799e19b62a718168.jpg' to 'CNN_Train/N'.
    Moved 'N5_jpg.rf.f79130004862195db416f6cdcf584a27.jpg' to 'CNN_Train/N'.
    Moved 'X1_jpg.rf.2f5945cb8fc34dfe7291f978713425c8.jpg' to 'CNN_Train/X'.
    Moved 'U20_jpg.rf.84374a19603b78e186f750ead5b2b34e.jpg' to 'CNN_Train/U'.
    Moved 'W14_jpg.rf.85192eabce77e8eaaddaf159095e0f02.jpg' to 'CNN_Train/W'.
    Moved 'Z15_jpg.rf.01dae2ff4bb13d57fb3555e92eeb4778.jpg' to 'CNN_Train/Z'.
    Moved 'S28_jpg.rf.2dcf598761ec42989392fc8bf34d7dad.jpg' to 'CNN_Train/S'.
    Moved 'W6_jpg.rf.6b9326c321d2aee997214bd374e78a6e.jpg' to 'CNN_Train/W'.
    Moved 'A24_jpg.rf.8787463d42728d041d7eb1c6344affa8.jpg' to 'CNN_Train/A'.
    Moved 'R22_jpg.rf.e9175a212cf2a7f78d97c98fdbad8866.jpg' to 'CNN_Train/R'.
    Moved 'Y22_jpg.rf.48c04a6138632a7ffd83462bb5c0bf8d.jpg' to 'CNN_Train/Y'.
    Moved 'D5_jpg.rf.120762cfe888b11fd68ca6e0de2739a7.jpg' to 'CNN_Train/D'.
    Moved 'O9_jpg.rf.24b9e4a13ab9b2daf02722e60c6adc58.jpg' to 'CNN_Train/O'.
    Moved 'G13_jpg.rf.489885afbbdcafca479ea1abf7000047.jpg' to 'CNN_Train/G'.
    Moved 'A8_jpg.rf.991bd77dc48de828da8f0529f36f1d4a.jpg' to 'CNN_Train/A'.
    Moved 'S1_jpg.rf.d57adf7948c0141f1d50fc16c8482679.jpg' to 'CNN_Train/S'.
    Moved 'A19_jpg.rf.ffe6b49b3b0683ef4eb235ec6c7eca9e.jpg' to 'CNN_Train/A'.
    Moved 'A12_jpg.rf.a6af764b7540d62daadf4d88cd39bf67.jpg' to 'CNN_Train/A'.
    Moved 'K8_jpg.rf.c8df4918b176902ee61bd5b252ad9e1a.jpg' to 'CNN_Train/K'.
    Moved 'P5_jpg.rf.fe60919af5b5f73c21122d0cb7cf6092.jpg' to 'CNN_Train/P'.
    Moved 'R4_jpg.rf.52a4a9dde06e8456d6cbdbc797e6a987.jpg' to 'CNN_Train/R'.
    Moved 'L5_jpg.rf.f18fe972023219d86da41ea1eb2b5b91.jpg' to 'CNN_Train/L'.
    Moved 'A11_jpg.rf.bf055dc8a9a5a85bed0cc1f792c56a01.jpg' to 'CNN_Train/A'.
    Moved 'J3_jpg.rf.ff86dc5a870f1eadf471751c7fe11941.jpg' to 'CNN_Train/J'.
    Moved 'X11_jpg.rf.3e4a5ef511b90f3c1ba6479302df1406.jpg' to 'CNN_Train/X'.
    Moved 'E0_jpg.rf.4f0d29badc36513788ee34d8ecadbdf8.jpg' to 'CNN_Train/E'.
    Moved 'Q15_jpg.rf.c1a8ac254417a095a40237f56137162d.jpg' to 'CNN_Train/Q'.
    Moved 'F10_jpg.rf.79272ca3dab510ac7c2c1a239a9e99fb.jpg' to 'CNN_Train/F'.
    Moved 'L20_jpg.rf.3b6c700ee2bb2b8f8ede77ec7ca769f4.jpg' to 'CNN_Train/L'.
    Moved 'W3_jpg.rf.a1ca46c8bfe3ec89ae3a8dac2beb824e.jpg' to 'CNN_Train/W'.
    Moved 'O5_jpg.rf.9478a7071c9594c6c5b80109907a0a5d.jpg' to 'CNN_Train/O'.
    Moved 'U7_jpg.rf.5a8152cb6a3ae8b6b5907ab7e4f65638.jpg' to 'CNN_Train/U'.
    Moved 'D18_jpg.rf.0453a37b304e0dd33a3bd6eaebc34e42.jpg' to 'CNN_Train/D'.
    Moved 'G1_jpg.rf.e2cbd43294786e5e8e5508912a7d2227.jpg' to 'CNN_Train/G'.
    Moved 'X5_jpg.rf.23fa082fad08c6660bf2d2852954a723.jpg' to 'CNN_Train/X'.
    Moved 'Z3_jpg.rf.8baa18d239afd24c9596a2018f396373.jpg' to 'CNN_Train/Z'.
    Moved 'D8_jpg.rf.94d8d1eb9cff84765f81c632d07edc46.jpg' to 'CNN_Train/D'.
    Moved 'G17_jpg.rf.edabbe6ac1a7dcb24cdfef0be0940ef3.jpg' to 'CNN_Train/G'.
    Moved 'I8_jpg.rf.ec3b78b52cbc108e0b6ca480e3b17446.jpg' to 'CNN_Train/I'.
    Moved 'C20_jpg.rf.ab197d4732b19a26955eb697b752c0da.jpg' to 'CNN_Train/C'.
    Moved 'R13_jpg.rf.fb676b39dfddb47b1161a377a1b5c616.jpg' to 'CNN_Train/R'.
    Moved 'I6_jpg.rf.f7298af8bb64633d55d34d30a8956296.jpg' to 'CNN_Train/I'.
    Moved 'D18_jpg.rf.70d46390262abc9a286556c7ba86a8ae.jpg' to 'CNN_Train/D'.
    Moved 'X15_jpg.rf.cbe362b93625ac37cae2947696df45b3.jpg' to 'CNN_Train/X'.
    Moved 'Z13_jpg.rf.df5c48460fe9d23f8fa2597d23efd2d4.jpg' to 'CNN_Train/Z'.
    Moved 'V15_jpg.rf.4c07dca8742697167d9c49a3f68649e2.jpg' to 'CNN_Train/V'.
    Moved 'X18_jpg.rf.99fd8bab19f97743011b1327df33a70d.jpg' to 'CNN_Train/X'.
    Moved 'K17_jpg.rf.54067dfb2c86d9ee494ea3d0a8dd7ccb.jpg' to 'CNN_Train/K'.
    Moved 'U0_jpg.rf.0d819884eca983ec349a1c0985a0c8b8.jpg' to 'CNN_Train/U'.
    Moved 'V5_jpg.rf.c1dbe0a1d603ddc610659d2bf6f84648.jpg' to 'CNN_Train/V'.
    Moved 'R14_jpg.rf.377a4ada331d1cde46c85c20c2e1c666.jpg' to 'CNN_Train/R'.
    Moved 'Z25_jpg.rf.fbf575e280796d678ab8a4027d9a42b9.jpg' to 'CNN_Train/Z'.
    Moved 'F2_jpg.rf.4fdd2417e135e528cb0873738978cad0.jpg' to 'CNN_Train/F'.
    Moved 'G14_jpg.rf.2ffcf532fd38f708a7120fee5dd790f6.jpg' to 'CNN_Train/G'.
    Moved 'X13_jpg.rf.ee9ae50c2625c7bf6c47852d5e93af96.jpg' to 'CNN_Train/X'.
    Moved 'V9_jpg.rf.8dcb670f33e898df3554c09f06dbf0fd.jpg' to 'CNN_Train/V'.
    Moved 'F27_jpg.rf.cb7a3f5801360dca7c5bd957ef86fb34.jpg' to 'CNN_Train/F'.
    Moved 'L15_jpg.rf.13a2da2d1d47bddfa534c26ac89b3caa.jpg' to 'CNN_Train/L'.
    Moved 'A1_jpg.rf.62756f145ef317dbd20ab731cbca01fd.jpg' to 'CNN_Train/A'.
    Moved 'J18_jpg.rf.3c43fb7b7a2491098af538b44f7513b5.jpg' to 'CNN_Train/J'.
    Moved 'M4_jpg.rf.65c764638b87aed72f7273b85d318b11.jpg' to 'CNN_Train/M'.
    Moved 'F15_jpg.rf.8be0ab85c65888d3a24b702ad31e728b.jpg' to 'CNN_Train/F'.
    Moved 'C5_jpg.rf.8c234b487fc6caac3607984cda82f9c3.jpg' to 'CNN_Train/C'.
    Moved 'A25_jpg.rf.1ee291da526c10ede77cf69d4cd2c231.jpg' to 'CNN_Train/A'.
    Moved 'T22_jpg.rf.205c80aa55302bd71fe1c0ac89833f07.jpg' to 'CNN_Train/T'.
    Moved 'L25_jpg.rf.c8fee1c6ab4f596e63ae66be10d42be1.jpg' to 'CNN_Train/L'.
    Moved 'J21_jpg.rf.afdfde9531a67417b4f7f3610694128c.jpg' to 'CNN_Train/J'.
    Moved 'R1_jpg.rf.ebb366aabfcadd3f5687848d1641a68e.jpg' to 'CNN_Train/R'.
    Moved 'S20_jpg.rf.b4495030e6951a2709d860d257ed11a3.jpg' to 'CNN_Train/S'.
    Moved 'L22_jpg.rf.519c99ef5b451159a253af7c640b0e40.jpg' to 'CNN_Train/L'.
    Moved 'C14_jpg.rf.ff63309f35ce9f8a7b30b006a4181045.jpg' to 'CNN_Train/C'.
    Moved 'N24_jpg.rf.b46b55bbe1e9adb6fcf27d979e9db5cb.jpg' to 'CNN_Train/N'.
    Moved 'N7_jpg.rf.98c90c88c6657ad7c30c8aed64d0baad.jpg' to 'CNN_Train/N'.
    Moved 'R24_jpg.rf.549ced8a6f3f03f52259c80798d0b400.jpg' to 'CNN_Train/R'.
    Moved 'Y15_jpg.rf.882102d74ab62a79519bede0ea81995e.jpg' to 'CNN_Train/Y'.
    Moved 'S11_jpg.rf.2109f5802e1544c773f2849d7d5acf7a.jpg' to 'CNN_Train/S'.
    Moved 'X18_jpg.rf.1a8c41e8efd4d9fb973a02374e9ba279.jpg' to 'CNN_Train/X'.
    Moved 'M18_jpg.rf.3fae46ff6a91c58fb10a10e854f3768e.jpg' to 'CNN_Train/M'.
    Moved 'I16_jpg.rf.16c9c8875d3709bdb762d85eeda10636.jpg' to 'CNN_Train/I'.
    Moved 'U16_jpg.rf.2df4b769fdadf2222247b5b6507013b7.jpg' to 'CNN_Train/U'.
    Moved 'D22_jpg.rf.2ec95d01cf28769cc931499e20a1e947.jpg' to 'CNN_Train/D'.
    Moved 'D27_jpg.rf.94df7c0b27b00569a14fe4475e84ec7f.jpg' to 'CNN_Train/D'.
    Moved 'I25_jpg.rf.15abc44d286afed0111817fdad8e2881.jpg' to 'CNN_Train/I'.
    Moved 'V26_jpg.rf.99df437705c6cfc7907f32f66aaecdee.jpg' to 'CNN_Train/V'.
    Moved 'K17_jpg.rf.b8b0d0f71aac008669cc4e280a73b080.jpg' to 'CNN_Train/K'.
    Moved 'M22_jpg.rf.c8d94dabdd8eb27af53e313b95684480.jpg' to 'CNN_Train/M'.
    Moved 'B24_jpg.rf.60571b4a4e55dc4bc9fce2e20acb0658.jpg' to 'CNN_Train/B'.
    Moved 'P0_jpg.rf.2780733313276a8a313ca86fbb89db4e.jpg' to 'CNN_Train/P'.
    Moved 'N23_jpg.rf.276b21f6b1dc28644f2daeb05a56198b.jpg' to 'CNN_Train/N'.
    Moved 'A25_jpg.rf.b634b38aff4d380480afe15240abffaf.jpg' to 'CNN_Train/A'.
    Moved 'I29_jpg.rf.cbcb28f9ec66d1c14621dfbb02850f5f.jpg' to 'CNN_Train/I'.
    Moved 'A7_jpg.rf.5bf80e89a1bbeeefced8bc7be1492987.jpg' to 'CNN_Train/A'.
    Moved 'W8_jpg.rf.5e465a4c3818187343a0eaf0ff6ab69c.jpg' to 'CNN_Train/W'.
    Moved 'T21_jpg.rf.0a29c60282700d02b816c6abad01e527.jpg' to 'CNN_Train/T'.
    Moved 'U10_jpg.rf.a1cf715f7f06a68998f067afef20cb28.jpg' to 'CNN_Train/U'.
    Moved 'I9_jpg.rf.d35b6e917127e0697768724b847347c1.jpg' to 'CNN_Train/I'.
    Moved 'W12_jpg.rf.16f29bc421221e4f2c02c3faa5863d3c.jpg' to 'CNN_Train/W'.
    Moved 'D22_jpg.rf.769f5763e99544f61ad4c8cec41ab18c.jpg' to 'CNN_Train/D'.
    Moved 'N3_jpg.rf.412d6fdc8fa412c3276e1b18fc565376.jpg' to 'CNN_Train/N'.
    Moved 'G26_jpg.rf.531f3dfc61f741a76de68b88e9bd52a1.jpg' to 'CNN_Train/G'.
    Moved 'B20_jpg.rf.d4905ccfc4b87bc74e50bbb0f302f049.jpg' to 'CNN_Train/B'.
    Moved 'P12_jpg.rf.77ea9a7ad9f24a2cdae79b6298b8283e.jpg' to 'CNN_Train/P'.
    Moved 'J17_jpg.rf.c2bfa3c5126db12c100651591ff20cff.jpg' to 'CNN_Train/J'.
    Moved 'K10_jpg.rf.e70a370a726d2e0f1996f321aa25411a.jpg' to 'CNN_Train/K'.
    Moved 'W9_jpg.rf.5cb9add511c7dec710dd30c38471f4b5.jpg' to 'CNN_Train/W'.
    Moved 'U19_jpg.rf.6786d3d84d511278f6b5721fed8648ee.jpg' to 'CNN_Train/U'.
    Moved 'J11_jpg.rf.2757f232e691dd82be0c0b8a6f8fb9fa.jpg' to 'CNN_Train/J'.
    Moved 'Q13_jpg.rf.8062f354cdada372d2f2b2167b6450d2.jpg' to 'CNN_Train/Q'.
    Moved 'C12_jpg.rf.0afac9aaffd201400a334cbbf38a518a.jpg' to 'CNN_Train/C'.
    Moved 'D18_jpg.rf.86ad518fbc07eab04daca71027cbe29e.jpg' to 'CNN_Train/D'.
    Moved 'U0_jpg.rf.d183c3cc0e401c0a7cf4e99d9c59025d.jpg' to 'CNN_Train/U'.
    Moved 'C21_jpg.rf.ad221e5196fb2c747b9b8962de8c48b3.jpg' to 'CNN_Train/C'.
    Moved 'J35_jpg.rf.6a007ec1b9ff32872252c250b01e4b2f.jpg' to 'CNN_Train/J'.
    Moved 'W15_jpg.rf.ae06a83d42ddc720d55c7c26087c5f2d.jpg' to 'CNN_Train/W'.
    Moved 'K21_jpg.rf.e3175a830adc3a54e1dbaa1935eefa54.jpg' to 'CNN_Train/K'.
    Moved 'I25_jpg.rf.9f10bb4baabfd5904f741d5363faf943.jpg' to 'CNN_Train/I'.
    Moved 'R10_jpg.rf.55b9e76ebbeb46d518a63df7c7759312.jpg' to 'CNN_Train/R'.
    Moved 'W3_jpg.rf.8eaecf72e4d1fa80dac7940cf74b0a03.jpg' to 'CNN_Train/W'.
    Moved 'Q23_jpg.rf.be1cf5ba3056c11d82fcc5a5de48de1c.jpg' to 'CNN_Train/Q'.
    Moved 'I22_jpg.rf.5f6b5a80535e761434b472eccaee9290.jpg' to 'CNN_Train/I'.
    Moved 'B20_jpg.rf.3c4ca5b3504725a29e48f74c7b3b92d6.jpg' to 'CNN_Train/B'.
    Moved 'E21_jpg.rf.02bd3a1ec0e99694816e883b8de32942.jpg' to 'CNN_Train/E'.
    Moved 'Z14_jpg.rf.6815934a383c43f127bbdc159c61be14.jpg' to 'CNN_Train/Z'.
    Moved 'V24_jpg.rf.09cf35cd5d3b68da6f3dcc34bccb298c.jpg' to 'CNN_Train/V'.
    Moved 'F27_jpg.rf.a394d28342f96819552cdacded6acfc3.jpg' to 'CNN_Train/F'.
    Moved 'F16_jpg.rf.236fc2c0aae5d6287474e26b4278d9d3.jpg' to 'CNN_Train/F'.
    Moved 'O21_jpg.rf.f1b80c4847c4d4649bf986bfefeb80c7.jpg' to 'CNN_Train/O'.
    Moved 'E24_jpg.rf.41db0e0cc4f0f0041c9d08d0a40b683b.jpg' to 'CNN_Train/E'.
    Moved 'G12_jpg.rf.a773566896b476939729375fa3b5ad4e.jpg' to 'CNN_Train/G'.
    Moved 'C12_jpg.rf.88f0f81906b3567c5f64dfce2ecb850c.jpg' to 'CNN_Train/C'.
    Moved 'V14_jpg.rf.c3fa791d8537ddd98a8330dfe10b6010.jpg' to 'CNN_Train/V'.
    Moved 'D5_jpg.rf.690539382643498e08f43ad16d6a0991.jpg' to 'CNN_Train/D'.
    Moved 'C4_jpg.rf.45d9308b1e63d4ff55615b0d5e3fa96d.jpg' to 'CNN_Train/C'.
    Moved 'S14_jpg.rf.37a7c8deb4442739e207c7b0d9b7c330.jpg' to 'CNN_Train/S'.
    Moved 'V23_jpg.rf.279b03422f2622fbfae5c28d973abb0a.jpg' to 'CNN_Train/V'.
    Moved 'Y14_jpg.rf.0b16d04af40a4ed25e305d03692f4f05.jpg' to 'CNN_Train/Y'.
    Moved 'Y18_jpg.rf.7c5e33e0f98eaa1b200e32027572bad2.jpg' to 'CNN_Train/Y'.
    Moved 'X10_jpg.rf.3b7703995c843a90f795c9be98cf8c31.jpg' to 'CNN_Train/X'.
    Moved 'L15_jpg.rf.1e825d1bdfe88d7122179bc79e358eb1.jpg' to 'CNN_Train/L'.
    Moved 'K17_jpg.rf.29c857c32684e8096d77de2260a071b2.jpg' to 'CNN_Train/K'.
    Moved 'T5_jpg.rf.f36d1d223982eefc24c83f99e00162ec.jpg' to 'CNN_Train/T'.
    Moved 'L10_jpg.rf.2086b2f8eed495c4c134f64ed980a290.jpg' to 'CNN_Train/L'.
    Moved 'G12_jpg.rf.65da5ab9ac1f7c80acee8005820688cb.jpg' to 'CNN_Train/G'.
    Moved 'U14_jpg.rf.80e617d1d5760f5eb3f7fcaa11169355.jpg' to 'CNN_Train/U'.
    Moved 'R14_jpg.rf.bcfdeece1d745a1d3993b05c80bcd370.jpg' to 'CNN_Train/R'.
    Moved 'H7_jpg.rf.de6fef7f8517ede6a67c0f318fc8f3c1.jpg' to 'CNN_Train/H'.
    Moved 'F28_jpg.rf.a347f4e87125121d264118f7b9df44d6.jpg' to 'CNN_Train/F'.
    Moved 'X15_jpg.rf.652e8d7c97087d735b294dd643febd92.jpg' to 'CNN_Train/X'.
    Moved 'G25_jpg.rf.8d4d99d9b753446cea07a0cdf0e82fa1.jpg' to 'CNN_Train/G'.
    Moved 'R22_jpg.rf.0e5e7eb817a828a880b068496d4382e8.jpg' to 'CNN_Train/R'.
    Moved 'P15_jpg.rf.ea8b3b29dcaa786a87990a70a62a2536.jpg' to 'CNN_Train/P'.
    Moved 'M2_jpg.rf.61587c7ec4948584a1c7f58d4fde93f5.jpg' to 'CNN_Train/M'.
    Moved 'Y11_jpg.rf.0d8bfe757d18e06519822aac82c4b755.jpg' to 'CNN_Train/Y'.
    Moved 'S13_jpg.rf.d649c07d2760c406425c9fd60a895c7a.jpg' to 'CNN_Train/S'.
    Moved 'I20_jpg.rf.48cb8523d8325ef59931ca058774bf5e.jpg' to 'CNN_Train/I'.
    Moved 'U22_jpg.rf.a85f084efc438d9259c714b1db820695.jpg' to 'CNN_Train/U'.
    Moved 'C0_jpg.rf.3a02e62f278a8a5df84948f70bbe7869.jpg' to 'CNN_Train/C'.
    Moved 'K3_jpg.rf.544b0d955d1da81bde0a204fd4db9573.jpg' to 'CNN_Train/K'.
    Moved 'T0_jpg.rf.802ab2f9643731a33e5dbdea2569b539.jpg' to 'CNN_Train/T'.
    Moved 'F25_jpg.rf.71a50320caff7a1dceb2ca5543f7e050.jpg' to 'CNN_Train/F'.
    Moved 'L18_jpg.rf.c1682d30473c71c4bba7a94c60a1ed74.jpg' to 'CNN_Train/L'.
    Moved 'P10_jpg.rf.9bc9936fa60df50c060b49c5e53a303d.jpg' to 'CNN_Train/P'.
    Moved 'T5_jpg.rf.235e00d1b43d411056c8b6b723d0cc8b.jpg' to 'CNN_Train/T'.
    Moved 'Z20_jpg.rf.1467ba7953ab97618b21145b3b2a64e3.jpg' to 'CNN_Train/Z'.
    Moved 'U17_jpg.rf.6cbee7905089ec10bd165490798d478e.jpg' to 'CNN_Train/U'.
    Moved 'F18_jpg.rf.b00507954dc206121d607ca80cc70b09.jpg' to 'CNN_Train/F'.
    Moved 'S29_jpg.rf.a11f025e9515834b1078f51b49f74018.jpg' to 'CNN_Train/S'.
    Moved 'E6_jpg.rf.776022b662ddf22f0e3e8e0f59059421.jpg' to 'CNN_Train/E'.
    Moved 'Y15_jpg.rf.800b1b21d2f9e93031d47013fbb30426.jpg' to 'CNN_Train/Y'.
    Moved 'G28_jpg.rf.4a10032944135ba76a28cd983c12ef82.jpg' to 'CNN_Train/G'.
    Moved 'A16_jpg.rf.e7c093d6900f6669ca5b4f16cd01c1e9.jpg' to 'CNN_Train/A'.
    Moved 'T21_jpg.rf.de482df480954e9d1909c2c21ad1f27d.jpg' to 'CNN_Train/T'.
    Moved 'C21_jpg.rf.162ffff1083e8fae45254bb9249bfcbf.jpg' to 'CNN_Train/C'.
    Moved 'K19_jpg.rf.d81925d2d8bbc87064506e368a8fb4ed.jpg' to 'CNN_Train/K'.
    Moved 'N3_jpg.rf.a237e0819785b78fce4c4f21c3d01696.jpg' to 'CNN_Train/N'.
    Moved 'G27_jpg.rf.15efbdf665e48ddb06113e3dd4aeefe1.jpg' to 'CNN_Train/G'.
    Moved 'I21_jpg.rf.57d19c1b96b44e9049c40bda73a4e968.jpg' to 'CNN_Train/I'.
    Moved 'D21_jpg.rf.cf0fc16f82facbf71f6214e64786b816.jpg' to 'CNN_Train/D'.
    Moved 'R4_jpg.rf.11c318efe06da496ef1f0aecc801efe5.jpg' to 'CNN_Train/R'.
    Moved 'E8_jpg.rf.3a37a15d81bddd0e01b36294b3a51016.jpg' to 'CNN_Train/E'.
    Moved 'J0_jpg.rf.caa761a30f7e16c2d745668f9bcc8177.jpg' to 'CNN_Train/J'.
    Moved 'Z1_jpg.rf.65efaf3942003d2e4a4316f2309786f1.jpg' to 'CNN_Train/Z'.
    Moved 'J25_jpg.rf.5a55ede6f176487927501a082f9d76bc.jpg' to 'CNN_Train/J'.
    Moved 'M21_jpg.rf.99bba85cee72f5d90a28094590ecbbbf.jpg' to 'CNN_Train/M'.
    Moved 'P3_jpg.rf.b4cb115ed877d2f02832af4fe993cc67.jpg' to 'CNN_Train/P'.
    Moved 'V7_jpg.rf.660110da9912fceee0e30e2de049b856.jpg' to 'CNN_Train/V'.
    Moved 'M3_jpg.rf.421bf4b4026eefa77eca4eb294ff69ab.jpg' to 'CNN_Train/M'.
    Moved 'D11_jpg.rf.1f53ba2b436994ad36b120c820921bdc.jpg' to 'CNN_Train/D'.
    Moved 'R14_jpg.rf.5a6cdf945acdd3553d8ea7a7b8097eec.jpg' to 'CNN_Train/R'.
    Moved 'O15_jpg.rf.1c5a31d1b029c0c38833e9c961378e5f.jpg' to 'CNN_Train/O'.
    Moved 'N4_jpg.rf.e83e4a424e2ba66e8970c66d9d0f8242.jpg' to 'CNN_Train/N'.
    Moved 'M27_jpg.rf.8d5e421d588ad3f38ffc4520c64c2ef3.jpg' to 'CNN_Train/M'.
    Moved 'M21_jpg.rf.82968e33ada0cfccf99bfe9ede419f82.jpg' to 'CNN_Train/M'.
    Moved 'L13_jpg.rf.05678eea40bbd755e5a00a3f13fe7a6b.jpg' to 'CNN_Train/L'.
    Moved 'Q19_jpg.rf.64daae9ed66320b64ac522120df5297a.jpg' to 'CNN_Train/Q'.
    Moved 'O14_jpg.rf.ebcb10c3ba61902c17b5019969e79fc9.jpg' to 'CNN_Train/O'.
    Moved 'O18_jpg.rf.0ef5218f1ffe8238ef5e89a64313bc4f.jpg' to 'CNN_Train/O'.
    Moved 'M16_jpg.rf.61d886ad907da30dde5b361424eca491.jpg' to 'CNN_Train/M'.
    Moved 'A2_jpg.rf.3aadc5ebc1dc85f9cf01c034e89e427e.jpg' to 'CNN_Train/A'.
    Moved 'J10_jpg.rf.ea2c3ed75b4aa4570df7c84a2c1e1c50.jpg' to 'CNN_Train/J'.
    Moved 'C10_jpg.rf.5cfca3be91140ce90dd5dec8b3883120.jpg' to 'CNN_Train/C'.
    Moved 'M16_jpg.rf.1d5582262ceec69d6a45ac3197842420.jpg' to 'CNN_Train/M'.
    Moved 'A17_jpg.rf.4a8e1a1f1b440d03ba2e262405e72845.jpg' to 'CNN_Train/A'.
    Moved 'X16_jpg.rf.4d4d92171ef29789516fe1cf4fc75847.jpg' to 'CNN_Train/X'.
    Moved 'Z12_jpg.rf.aead6bf7e0fc9e542174f72ace2bea05.jpg' to 'CNN_Train/Z'.
    Moved 'S8_jpg.rf.7d5a62b1d2bb4d9073c652413b1f959a.jpg' to 'CNN_Train/S'.
    Moved 'K26_jpg.rf.311c9f6afc5c1f34b2edced42d532e5e.jpg' to 'CNN_Train/K'.
    Moved 'N5_jpg.rf.5ae0d41f440e990939e5a00c9c78c847.jpg' to 'CNN_Train/N'.
    Moved 'I7_jpg.rf.4ecd2cd7882bbf1c49d3d4cdb836aa69.jpg' to 'CNN_Train/I'.
    Moved 'R12_jpg.rf.44c10c382585b30f761f68712e1417ec.jpg' to 'CNN_Train/R'.
    Moved 'M19_jpg.rf.d3b20ddaf332d899c9148014b1bd2034.jpg' to 'CNN_Train/M'.
    Moved 'R9_jpg.rf.3e82bd75477219f4029463bb7b768829.jpg' to 'CNN_Train/R'.
    Moved 'Q2_jpg.rf.d89282c4d9e377048f24bff9b9149f30.jpg' to 'CNN_Train/Q'.
    Moved 'L24_jpg.rf.e1fd0f2c2677c998fba3c3dccb7e5ff2.jpg' to 'CNN_Train/L'.
    Moved 'V5_jpg.rf.f61b9df02722cf9ac89cd65f582e4069.jpg' to 'CNN_Train/V'.
    Moved 'C2_jpg.rf.03a70718529b1e03561c20c91c2ce616.jpg' to 'CNN_Train/C'.
    Moved 'L17_jpg.rf.9ef44d0df7cbb689066651161a70d960.jpg' to 'CNN_Train/L'.
    Moved 'U11_jpg.rf.e711f70267991dec1389168f42a25c49.jpg' to 'CNN_Train/U'.
    Moved 'T14_jpg.rf.d7e177eb44888c247b2349500de103a6.jpg' to 'CNN_Train/T'.
    Moved 'I12_jpg.rf.12ae9b70a48e552fe1c108efbfed59fa.jpg' to 'CNN_Train/I'.
    Moved 'Y3_jpg.rf.1765e0d5bba76bdd3dae44666e1c214a.jpg' to 'CNN_Train/Y'.
    Moved 'J35_jpg.rf.1ed39e38a0ee03a335348b9103c6121e.jpg' to 'CNN_Train/J'.
    Moved 'R1_jpg.rf.a257cbb8565c637a1ab4285726338f9a.jpg' to 'CNN_Train/R'.
    Moved 'S17_jpg.rf.145203481479c369b4d6e3cac9099ffa.jpg' to 'CNN_Train/S'.
    Moved 'Z15_jpg.rf.a26f0ba92e8ae15a6bec6598f867b061.jpg' to 'CNN_Train/Z'.
    Moved 'Q3_jpg.rf.27f364cf93f8a66e0f5b509cd1dbb1ae.jpg' to 'CNN_Train/Q'.
    Moved 'I10_jpg.rf.031d497a63d112e07bdbe603fe3d1c1a.jpg' to 'CNN_Train/I'.
    Moved 'V4_jpg.rf.1975ced8246afc56ca0b20a1d70e2d6d.jpg' to 'CNN_Train/V'.
    Moved 'F14_jpg.rf.c244800f96c233271e27fd60c37fb34b.jpg' to 'CNN_Train/F'.
    Moved 'P16_jpg.rf.4403a1f4444c99219aaed32e4cfaa733.jpg' to 'CNN_Train/P'.
    Moved 'N7_jpg.rf.eb8cf7b1cdad55ee2ce79528957fb77b.jpg' to 'CNN_Train/N'.
    Moved 'E11_jpg.rf.36d9fe2054ede595e2900c038368c6a9.jpg' to 'CNN_Train/E'.
    Moved 'P21_jpg.rf.35fa0cf3644b08c3d77646ae4efcac5f.jpg' to 'CNN_Train/P'.
    Moved 'B13_jpg.rf.db3097a593b6edec7e499852925cb854.jpg' to 'CNN_Train/B'.
    Moved 'F21_jpg.rf.df6a6428305d0e14e98369fae4813b15.jpg' to 'CNN_Train/F'.
    Moved 'A7_jpg.rf.c87a086625b7c5db62e61655f42e0ae4.jpg' to 'CNN_Train/A'.
    Moved 'I18_jpg.rf.dd91753b3b6b7e6e32df2d15968adf29.jpg' to 'CNN_Train/I'.
    Moved 'T10_jpg.rf.c9184e97594b53eb030920418cd52c69.jpg' to 'CNN_Train/T'.
    Moved 'N12_jpg.rf.9a4c9fb411ede751dc657bba35021044.jpg' to 'CNN_Train/N'.
    Moved 'B17_jpg.rf.5177d683638aaeb5b00b07bd2be26624.jpg' to 'CNN_Train/B'.
    Moved 'W21_jpg.rf.6f567fbe6f43e8ad9b965d0d3eecb0ab.jpg' to 'CNN_Train/W'.
    Moved 'I12_jpg.rf.4c8263600f0c310868b55e13ee2bb2f8.jpg' to 'CNN_Train/I'.
    Moved 'K10_jpg.rf.4ef455ac2f3f58e1d30adb86c07543b2.jpg' to 'CNN_Train/K'.
    Moved 'Q16_jpg.rf.7ee7bec8ce9f912402d0885adcbef1f9.jpg' to 'CNN_Train/Q'.
    Moved 'J22_jpg.rf.dd1e7d9beea336be8960e64202f4d41e.jpg' to 'CNN_Train/J'.
    Moved 'E3_jpg.rf.531173dbb28813a479a0490af2f7a95d.jpg' to 'CNN_Train/E'.
    Moved 'G1_jpg.rf.34e80fdfa0b2e1bf7f225d99c2b92029.jpg' to 'CNN_Train/G'.
    Moved 'N0_jpg.rf.180e4b19d6df6fc5e3e7d86dbe1ddc51.jpg' to 'CNN_Train/N'.
    Moved 'W5_jpg.rf.beadb3bbea6c3e9d2601c2cb8e567312.jpg' to 'CNN_Train/W'.
    Moved 'P15_jpg.rf.df7aa0e3024b57122c185e55dafc2c33.jpg' to 'CNN_Train/P'.
    Moved 'G6_jpg.rf.4b96ecae283c576a63e4e27c3ae16263.jpg' to 'CNN_Train/G'.
    Moved 'A27_jpg.rf.43d15c227b557017a01eec793a1a73f8.jpg' to 'CNN_Train/A'.
    Moved 'I15_jpg.rf.5aecf78632ef4f7104b2fbfaa04327cc.jpg' to 'CNN_Train/I'.
    Moved 'Y19_jpg.rf.57e8d39c7574c6d5e607cdf7f490492f.jpg' to 'CNN_Train/Y'.
    Moved 'T7_jpg.rf.3273d36d776a1f2acbd2475bcd72c564.jpg' to 'CNN_Train/T'.
    Moved 'U1_jpg.rf.7cd9bff5e8bce8381cde46cf1179cb85.jpg' to 'CNN_Train/U'.
    Moved 'U22_jpg.rf.39fad8c864b033c16fc603832210f558.jpg' to 'CNN_Train/U'.
    Moved 'L18_jpg.rf.0d823185815d28fad4f2572f392482c3.jpg' to 'CNN_Train/L'.
    Moved 'I23_jpg.rf.a8c38824ead79c16249bb349ad48cc45.jpg' to 'CNN_Train/I'.
    Moved 'S21_jpg.rf.23bd506ca957f7b9e14dc9a9aacb953c.jpg' to 'CNN_Train/S'.
    Moved 'M8_jpg.rf.d6181106122c9f1273f057bafe2d9ce6.jpg' to 'CNN_Train/M'.
    Moved 'L20_jpg.rf.5f68d14427b676a7efc70bb1e037fd4e.jpg' to 'CNN_Train/L'.
    Moved 'X18_jpg.rf.b790831778f3f3e395b653852c67066a.jpg' to 'CNN_Train/X'.
    Moved 'W21_jpg.rf.1f44eeeee36fee8197435b1a93acbb73.jpg' to 'CNN_Train/W'.
    Moved 'V13_jpg.rf.f68f9656a23c6a9fa4402d1e01f2696c.jpg' to 'CNN_Train/V'.
    Moved 'R10_jpg.rf.eb16ecf260bd3853600d7ce4965692d4.jpg' to 'CNN_Train/R'.
    Moved 'E14_jpg.rf.099b7c532a31aed9e59b72301ea13303.jpg' to 'CNN_Train/E'.
    Moved 'N14_jpg.rf.d711d4a495f0f5b865d419467c561f59.jpg' to 'CNN_Train/N'.
    Moved 'M2_jpg.rf.c375b1a1f866fcac4b80b8de12fdf925.jpg' to 'CNN_Train/M'.
    Moved 'V19_jpg.rf.e529f796070e58b433a85123b2dea8b7.jpg' to 'CNN_Train/V'.
    Moved 'O23_jpg.rf.e432b5245f739c6b4779336803484d13.jpg' to 'CNN_Train/O'.
    Moved 'N10_jpg.rf.1e1d01dfd5fb83b817aa27f717ffef77.jpg' to 'CNN_Train/N'.
    Moved 'C4_jpg.rf.282bb2916760b438bbb9b4802ca6d51c.jpg' to 'CNN_Train/C'.
    Moved 'G22_jpg.rf.91e0c4dc22d572aa3bd666a0fd8f0cf1.jpg' to 'CNN_Train/G'.
    Moved 'A28_jpg.rf.e2214cbcfdad5a30778bc0fccf2fcdf0.jpg' to 'CNN_Train/A'.
    Moved 'K25_jpg.rf.132166e150d2509b3134d70b93a4b8d1.jpg' to 'CNN_Train/K'.
    Moved 'C2_jpg.rf.1cd7aca8a93b74b211c9fbcb18b96519.jpg' to 'CNN_Train/C'.
    Moved 'K15_jpg.rf.5505ad8fdd2f515291b18f3392caa1df.jpg' to 'CNN_Train/K'.
    Moved 'P14_jpg.rf.ec59751e7e28ab19928e00096ca47183.jpg' to 'CNN_Train/P'.
    Moved 'N23_jpg.rf.01428a442131e7dcbdb4453df83877e0.jpg' to 'CNN_Train/N'.
    Moved 'V16_jpg.rf.e0776ae9aa018eced61702fba2c39d78.jpg' to 'CNN_Train/V'.
    Moved 'G2_jpg.rf.5ef944bbec904e80e1835209a42ae700.jpg' to 'CNN_Train/G'.
    Moved 'H11_jpg.rf.96ded92601b8986b834c0fcf926dfa40.jpg' to 'CNN_Train/H'.
    Moved 'M0_jpg.rf.6b591dfe6ceae47f02587b0d55835a81.jpg' to 'CNN_Train/M'.
    Moved 'G0_jpg.rf.fadb849a3fc1908fbf78c40baae2c61f.jpg' to 'CNN_Train/G'.
    Moved 'N21_jpg.rf.0ce2674890bec944af10484666907f3a.jpg' to 'CNN_Train/N'.
    Moved 'Q14_jpg.rf.fcec5d4c1c36df5e8f3de38d4f7fdcb5.jpg' to 'CNN_Train/Q'.
    Moved 'J7_jpg.rf.89b97ef4c2c2a3e60227a1ad5f0f463a.jpg' to 'CNN_Train/J'.
    Moved 'Z7_jpg.rf.7ea521620bed1c0fb655c4ef5730a8af.jpg' to 'CNN_Train/Z'.
    Moved 'J32_jpg.rf.dc0f95718362bb9b173267a2c1efe7dc.jpg' to 'CNN_Train/J'.
    Moved 'J21_jpg.rf.0c71cb8778aaf14f83d639c92d8c9c11.jpg' to 'CNN_Train/J'.
    Moved 'O15_jpg.rf.db2897d07d4dd56509113e0766611142.jpg' to 'CNN_Train/O'.
    Moved 'I15_jpg.rf.cb9b7683012629418f85098df2812742.jpg' to 'CNN_Train/I'.
    Moved 'A5_jpg.rf.11920540d5a68fdeed4b584fb24cd063.jpg' to 'CNN_Train/A'.
    Moved 'S1_jpg.rf.c8b15b31501e39d1e2d6ddfa4211043c.jpg' to 'CNN_Train/S'.
    Moved 'P21_jpg.rf.05b6ba0dcac40daddf8d8f206c85e20f.jpg' to 'CNN_Train/P'.
    Moved 'T5_jpg.rf.27e7b3b0325343fcf5dfc41430a7cc20.jpg' to 'CNN_Train/T'.
    Moved 'S21_jpg.rf.e4224fa6abed5e1fc19fd8fa64c1cca9.jpg' to 'CNN_Train/S'.
    Moved 'W4_jpg.rf.17f140aa6d52da488b75601911d650a0.jpg' to 'CNN_Train/W'.
    Moved 'S15_jpg.rf.a51829cfdd4a697cdb43c85122f50d2b.jpg' to 'CNN_Train/S'.
    Moved 'K15_jpg.rf.afcb8205efd3f2c7f74179d4eac59ebc.jpg' to 'CNN_Train/K'.
    Moved 'B22_jpg.rf.8905ab6c344c024819318532f76caccd.jpg' to 'CNN_Train/B'.
    Moved 'R4_jpg.rf.1e39e76f2b8933561c30caebc8b12fab.jpg' to 'CNN_Train/R'.
    Moved 'Y16_jpg.rf.0d5c938b766f9ae674a35d9c7c296d54.jpg' to 'CNN_Train/Y'.
    Moved 'A23_jpg.rf.e51d3bcb559b35e4d5ba896de298c380.jpg' to 'CNN_Train/A'.
    Moved 'V4_jpg.rf.82eae9d66afc6dee50e487351f2c1b57.jpg' to 'CNN_Train/V'.
    Moved 'I5_jpg.rf.22dd90990e4bbe2a01731f2ceed03d0e.jpg' to 'CNN_Train/I'.
    Moved 'Z0_jpg.rf.67eb05a396fbaabaad870ba7a2264707.jpg' to 'CNN_Train/Z'.
    Moved 'E17_jpg.rf.d020e3a8d2f6ef381cbebed2609d1551.jpg' to 'CNN_Train/E'.
    Moved 'M23_jpg.rf.3e9d7973153921e680fa40d75687c927.jpg' to 'CNN_Train/M'.
    Moved 'I11_jpg.rf.6e2295c3fbc52d99e8f18010c836f1c0.jpg' to 'CNN_Train/I'.
    Moved 'U17_jpg.rf.27ec0390a94f6b8517bd0757bf09761d.jpg' to 'CNN_Train/U'.
    Moved 'I3_jpg.rf.13d13da81962b86db3705de1b79f984a.jpg' to 'CNN_Train/I'.
    Moved 'O23_jpg.rf.210f1aaa191497f03d00676460842a64.jpg' to 'CNN_Train/O'.
    Moved 'R13_jpg.rf.a613d28c9af1a4ca905464c74468f0cb.jpg' to 'CNN_Train/R'.
    Moved 'A5_jpg.rf.7509038ff9765a183ca15e82b511d200.jpg' to 'CNN_Train/A'.
    Moved 'P10_jpg.rf.14ca35ae7502f010c44b1951745b8ae6.jpg' to 'CNN_Train/P'.
    Moved 'O27_jpg.rf.5026ba77625aca8f5f531540ab99c881.jpg' to 'CNN_Train/O'.
    Moved 'D27_jpg.rf.d48548afd89a90c6c4f665d8461aab47.jpg' to 'CNN_Train/D'.
    Moved 'A26_jpg.rf.f6ef3e5bd61b99724a5bd52a8bd71a9f.jpg' to 'CNN_Train/A'.
    Moved 'F23_jpg.rf.7885d9deccd14a4f1cca3a3d063da071.jpg' to 'CNN_Train/F'.
    Moved 'Q25_jpg.rf.c121126193f206cde238ae6311c5b88b.jpg' to 'CNN_Train/Q'.
    Moved 'X23_jpg.rf.7761f3c810024196159dad8e5dc79a84.jpg' to 'CNN_Train/X'.
    Moved 'L25_jpg.rf.87c984e7c3672d7cfc5b699bf34ac536.jpg' to 'CNN_Train/L'.
    Moved 'O2_jpg.rf.3fd2151e4d7981b8547c2889f9ed7cd7.jpg' to 'CNN_Train/O'.
    Moved 'A4_jpg.rf.6b68517bcc691a09eae8e2567d110cf0.jpg' to 'CNN_Train/A'.
    Moved 'Q24_jpg.rf.27036337a85fbfe7eb30e1b7e75953ce.jpg' to 'CNN_Train/Q'.
    Moved 'M8_jpg.rf.e3f072f2cc57e60aad0cb5ffe5cd01b4.jpg' to 'CNN_Train/M'.
    Moved 'P15_jpg.rf.159a541ad56feffc9391156c5520088f.jpg' to 'CNN_Train/P'.
    Moved 'I27_jpg.rf.eb6611451393847924a21d41e1f7e7d2.jpg' to 'CNN_Train/I'.
    Moved 'F16_jpg.rf.46171e20f1d7705061ed245059d607b6.jpg' to 'CNN_Train/F'.
    Moved 'P11_jpg.rf.a133cd006493e4185057697a4fcb8cb1.jpg' to 'CNN_Train/P'.
    Moved 'V1_jpg.rf.bbe1ec117abf8949bb4f59b58eb211f9.jpg' to 'CNN_Train/V'.
    Moved 'L12_jpg.rf.2b89d0a30826c4f162b184d7cefc6829.jpg' to 'CNN_Train/L'.
    Moved 'O5_jpg.rf.994a7d09ff71b63cadabe29701ad4dc3.jpg' to 'CNN_Train/O'.
    Moved 'L18_jpg.rf.6f057ffbef34e2b0b5049c635abc87f7.jpg' to 'CNN_Train/L'.
    Moved 'R11_jpg.rf.f207241a5b48f9f4f8e1dd0c31c4eac2.jpg' to 'CNN_Train/R'.
    Moved 'P22_jpg.rf.258b8bb07325ba9658a42dc1a58a0c54.jpg' to 'CNN_Train/P'.
    Moved 'E22_jpg.rf.bbc329c64df9596f31c5454da8aecec0.jpg' to 'CNN_Train/E'.
    Moved 'U22_jpg.rf.23b0f88fbc9d62876bd891370285253d.jpg' to 'CNN_Train/U'.
    Moved 'J0_jpg.rf.a2e7e5aed5673e411fd1baca0cc34a4a.jpg' to 'CNN_Train/J'.
    Moved 'C13_jpg.rf.54931a3fe5f245f52f99288e352b7d07.jpg' to 'CNN_Train/C'.
    Moved 'X17_jpg.rf.d4248502efb4c440f19daf1af0dbe5ca.jpg' to 'CNN_Train/X'.
    Moved 'A0_jpg.rf.a79ace20ea42b8f94360cef8aaec4030.jpg' to 'CNN_Train/A'.
    Moved 'N21_jpg.rf.e20c6d0f82c672b6f869f1a4fd7a0f67.jpg' to 'CNN_Train/N'.
    Moved 'X6_jpg.rf.7018afadc8bea75cd58c9fd04f754dc7.jpg' to 'CNN_Train/X'.
    Moved 'L2_jpg.rf.e54933c64e575060a989478ceb9a7ea0.jpg' to 'CNN_Train/L'.
    Moved 'C11_jpg.rf.487d3d40a9e7629351ce425e42a28f03.jpg' to 'CNN_Train/C'.
    Moved 'O9_jpg.rf.055425e3503991ffaf8f801a61986924.jpg' to 'CNN_Train/O'.
    Moved 'T6_jpg.rf.780ac7665c045cb032fdc659abb5f06b.jpg' to 'CNN_Train/T'.
    Moved 'M3_jpg.rf.c5fe2f7df1fdce631b69c90c4fa0970e.jpg' to 'CNN_Train/M'.
    Moved 'K18_jpg.rf.931a8b10f845a697fa3052ac8de6fa08.jpg' to 'CNN_Train/K'.
    Moved 'Q15_jpg.rf.738b99a91e16113998c2f42f069c3e59.jpg' to 'CNN_Train/Q'.
    Moved 'V7_jpg.rf.695d77c9f5f717ca1b048563c888dc9d.jpg' to 'CNN_Train/V'.
    Moved 'J1_jpg.rf.89010181214a77e2b462a7c2d1102327.jpg' to 'CNN_Train/J'.
    Moved 'V1_jpg.rf.281cc4bf3c98b5af94727d4b55f3ab25.jpg' to 'CNN_Train/V'.
    Moved 'B3_jpg.rf.e2f090f60390a00e77a564c1f18bcff7.jpg' to 'CNN_Train/B'.
    Moved 'D23_jpg.rf.0180ca2b1fbc4ac99d39ff957e9666ea.jpg' to 'CNN_Train/D'.
    Moved 'J0_jpg.rf.c5c8fc0404323b2dd17ccbd17ecacd88.jpg' to 'CNN_Train/J'.
    Moved 'L1_jpg.rf.758061deebf588e6a891a2060a266497.jpg' to 'CNN_Train/L'.
    Moved 'I20_jpg.rf.3cfb476851528323ae997257eadcd806.jpg' to 'CNN_Train/I'.
    Moved 'Q2_jpg.rf.849cd7ad3d27934374c677f431e3a1a5.jpg' to 'CNN_Train/Q'.
    Moved 'L6_jpg.rf.9e25afbd57f6148c26d0b0e666b95008.jpg' to 'CNN_Train/L'.
    Moved 'I4_jpg.rf.228ced783f921fdbbd7d491752b4fdf2.jpg' to 'CNN_Train/I'.
    Moved 'L9_jpg.rf.6f71c56b50f7023e5a43aa5764383b03.jpg' to 'CNN_Train/L'.
    Moved 'N10_jpg.rf.e4d39b46e9141319333f11815b14261f.jpg' to 'CNN_Train/N'.
    Moved 'C8_jpg.rf.f52ac54661d0cc965570c6581f768ffb.jpg' to 'CNN_Train/C'.
    Moved 'K22_jpg.rf.469ede252b621a64443d4da70d3fb7f6.jpg' to 'CNN_Train/K'.
    Moved 'D23_jpg.rf.140903c8c5f194371c7424003505399c.jpg' to 'CNN_Train/D'.
    Moved 'U11_jpg.rf.42a7d9d39bc5a04e527a806bf5d11e70.jpg' to 'CNN_Train/U'.
    Moved 'N24_jpg.rf.288d32f81bd2ac5ae72b996e63f5590a.jpg' to 'CNN_Train/N'.
    Moved 'A24_jpg.rf.fab8f98ae5634a08834a054ca706efec.jpg' to 'CNN_Train/A'.
    Moved 'F23_jpg.rf.a1c93723f021414543d098dcb7c70e3b.jpg' to 'CNN_Train/F'.
    Moved 'K14_jpg.rf.b455bea6fe1dc61f1b5b49d6ff88526d.jpg' to 'CNN_Train/K'.
    Moved 'L23_jpg.rf.a48055b8cf4629cc186c97cba9bbc47a.jpg' to 'CNN_Train/L'.
    Moved 'I22_jpg.rf.5a03e74c8ac6e76e9a1253936288bd11.jpg' to 'CNN_Train/I'.
    Moved 'P10_jpg.rf.dcd556b0e34e1ccafe32b7e4c650f42c.jpg' to 'CNN_Train/P'.
    Moved 'Y16_jpg.rf.f33ea43f62ea4f245d460b80c85d4bd9.jpg' to 'CNN_Train/Y'.
    Moved 'M13_jpg.rf.e2daf639a286394c9b602c21480815c8.jpg' to 'CNN_Train/M'.
    Moved 'Q23_jpg.rf.7c22e13c63bf9935a876dadc7572710d.jpg' to 'CNN_Train/Q'.
    Moved 'K8_jpg.rf.470f8eb6fafc48ca3332fcf6dee06c59.jpg' to 'CNN_Train/K'.
    Moved 'L0_jpg.rf.1ab48686ce6dc960e0c2eb596cb0e589.jpg' to 'CNN_Train/L'.
    Moved 'Y1_jpg.rf.8b70bdb98d870dc6c60ed99bbc279223.jpg' to 'CNN_Train/Y'.
    Moved 'S18_jpg.rf.77497bf145059f4112fa3ab70993ca6e.jpg' to 'CNN_Train/S'.
    Moved 'Z5_jpg.rf.544842f2941835d4960bd18e6ef49bca.jpg' to 'CNN_Train/Z'.
    Moved 'M23_jpg.rf.2e9dcb0d37abe04cf9f23fe2ee9b2217.jpg' to 'CNN_Train/M'.
    Moved 'O26_jpg.rf.1108b61327599ed4ae57a0e3f9638bdb.jpg' to 'CNN_Train/O'.
    Moved 'R2_jpg.rf.9c38ff01621dce6f68830b717e916f64.jpg' to 'CNN_Train/R'.
    Moved 'N19_jpg.rf.3cb994dcc8167de968fd41655a85a72b.jpg' to 'CNN_Train/N'.
    Moved 'U11_jpg.rf.2b6d6081a62c1243369c5bb8a3b145c5.jpg' to 'CNN_Train/U'.
    Moved 'X0_jpg.rf.b45be700e01659be6f0d1338eb4e5ea9.jpg' to 'CNN_Train/X'.
    Moved 'W21_jpg.rf.bec49089dbcba05353785dfb3d6e9407.jpg' to 'CNN_Train/W'.
    Moved 'H16_jpg.rf.60ec6583e22a3844b995a60db8777bc5.jpg' to 'CNN_Train/H'.
    Moved 'H4_jpg.rf.5c319b485275c3943342a08ab8bac532.jpg' to 'CNN_Train/H'.
    Moved 'X7_jpg.rf.f79c34a6387cb1234b2ef435f6970752.jpg' to 'CNN_Train/X'.
    Moved 'F27_jpg.rf.8ae9c1ddd9227c712ba093adbc09273b.jpg' to 'CNN_Train/F'.
    Moved 'L19_jpg.rf.780a8f4e548149a1e6b25dd196fbac5a.jpg' to 'CNN_Train/L'.
    Moved 'U19_jpg.rf.7509f6e7de716a5dce4e067512cbf66d.jpg' to 'CNN_Train/U'.
    Moved 'W11_jpg.rf.dcc540d2df5fba25bc9b89a4606cc9bb.jpg' to 'CNN_Train/W'.
    Moved 'X19_jpg.rf.91e89c93d776792601943f769cb30d37.jpg' to 'CNN_Train/X'.
    Moved 'H24_jpg.rf.365026af59e4a379bdc21ebf4053dcb8.jpg' to 'CNN_Train/H'.
    Moved 'I7_jpg.rf.b248f2a4378edf37cb0ea8b03f378442.jpg' to 'CNN_Train/I'.
    Moved 'Y12_jpg.rf.ca9035302ddb139a3304395c13269571.jpg' to 'CNN_Train/Y'.
    Moved 'O10_jpg.rf.9efa4d007801ab69abc49336b48359a7.jpg' to 'CNN_Train/O'.
    Moved 'N13_jpg.rf.5651d6cf59b38d4bfa691a9e73ca1c05.jpg' to 'CNN_Train/N'.
    Moved 'C3_jpg.rf.571f4682ead9e6b96d6f2417a0c542a1.jpg' to 'CNN_Train/C'.
    Moved 'Z14_jpg.rf.6bed4c2de295f57f0da7f7ad1affd060.jpg' to 'CNN_Train/Z'.
    Moved 'I2_jpg.rf.e759ab4a541159a2b65b89e1d92ea0da.jpg' to 'CNN_Train/I'.
    Moved 'V16_jpg.rf.3f12546ed0295eb779ba0b2d763327ad.jpg' to 'CNN_Train/V'.
    Moved 'J10_jpg.rf.c8d4e597413b65fd6363d0a0577d8f45.jpg' to 'CNN_Train/J'.
    Moved 'V16_jpg.rf.2885c17c3b1617053a09501090dbb45e.jpg' to 'CNN_Train/V'.
    Moved 'P13_jpg.rf.ee4814384faa813e78b704b27732f630.jpg' to 'CNN_Train/P'.
    Moved 'O2_jpg.rf.b4a66881c43730dfa8d477ff66f7b26f.jpg' to 'CNN_Train/O'.
    Moved 'A2_jpg.rf.4dc4b7c0d6e8d3e1d8bf35ada540b366.jpg' to 'CNN_Train/A'.
    Moved 'W2_jpg.rf.f08d597503f973cb58b18280d75ea84d.jpg' to 'CNN_Train/W'.
    Moved 'F10_jpg.rf.9d3c47f2b612c602d7d0a36385a152ba.jpg' to 'CNN_Train/F'.
    Moved 'P4_jpg.rf.90c5d227eef7d4787eb8506bb7cd3853.jpg' to 'CNN_Train/P'.
    Moved 'I18_jpg.rf.779d6952fc15d26726ad7121bea54296.jpg' to 'CNN_Train/I'.
    Moved 'O16_jpg.rf.5d70dcd1f259f4a80654b898d50653b0.jpg' to 'CNN_Train/O'.
    Moved 'B22_jpg.rf.50d8ba3dbd3a5c10b161cadadbcc5b41.jpg' to 'CNN_Train/B'.
    Moved 'V18_jpg.rf.4a33fccff210f6d4a58eabee436761dd.jpg' to 'CNN_Train/V'.
    Moved 'T10_jpg.rf.7441b40b26c6708b78fd1a9c0b20789b.jpg' to 'CNN_Train/T'.
    Moved 'J32_jpg.rf.753bdd7415dbf63bae9f98b259982a05.jpg' to 'CNN_Train/J'.
    Moved 'Q24_jpg.rf.6b761eafd611da4e06fe835d295dc9a7.jpg' to 'CNN_Train/Q'.
    Moved 'P13_jpg.rf.656b4793b735672344b19517592b268e.jpg' to 'CNN_Train/P'.
    Moved 'E17_jpg.rf.2141c09792f184b420512093b737496a.jpg' to 'CNN_Train/E'.
    Moved 'M13_jpg.rf.129d6cdd44f46213e760274b71a7035e.jpg' to 'CNN_Train/M'.
    Moved 'K25_jpg.rf.b7430b01444b7b3dda9f5b5eff5ab5c6.jpg' to 'CNN_Train/K'.
    Moved 'D11_jpg.rf.0e1fe6f1474bb8372d381b458576bece.jpg' to 'CNN_Train/D'.
    Moved 'G15_jpg.rf.574694ebc6ae05a0a5c37c11afe73aec.jpg' to 'CNN_Train/G'.
    Moved 'A16_jpg.rf.a7ba528015bff1d5f076ebc2510082e1.jpg' to 'CNN_Train/A'.
    Moved 'T7_jpg.rf.616213606335914d5d246b2579920503.jpg' to 'CNN_Train/T'.
    Moved 'P20_jpg.rf.90e73eaab2e6dca06cd704d2f7d70c9b.jpg' to 'CNN_Train/P'.
    Moved 'W0_jpg.rf.85b9a735331281ee1298ddb62e6d310d.jpg' to 'CNN_Train/W'.
    Moved 'V4_jpg.rf.18cdecbaa29fef28b7cb519e11e9fd84.jpg' to 'CNN_Train/V'.
    Moved 'E1_jpg.rf.5e4aa7d8bb694ce6e44a2dee30b1128e.jpg' to 'CNN_Train/E'.
    Moved 'B7_jpg.rf.0616aa49d62abc241f6c54b00bcbd9f7.jpg' to 'CNN_Train/B'.
    Moved 'W3_jpg.rf.89810e57cd68a4727a34b59c8c57d2dd.jpg' to 'CNN_Train/W'.
    Moved 'E12_jpg.rf.ba97ee9afb51c731e7d870ad8146b885.jpg' to 'CNN_Train/E'.
    Moved 'C20_jpg.rf.5f53a37a7de4c46ee072fdf44e4054f3.jpg' to 'CNN_Train/C'.
    Moved 'M0_jpg.rf.70755ca20acf9d12f01564b1cda38e15.jpg' to 'CNN_Train/M'.
    Moved 'P19_jpg.rf.b48e3b69b3e9b863075c2462a5e4dd9c.jpg' to 'CNN_Train/P'.
    Moved 'G28_jpg.rf.d4b5241bf85bc1dba0a34bda286fec0f.jpg' to 'CNN_Train/G'.
    Moved 'R12_jpg.rf.6bd167f266c932dc016d4c39328d773c.jpg' to 'CNN_Train/R'.
    Moved 'J33_jpg.rf.560b70f3511771d3a993eeca560bcb9e.jpg' to 'CNN_Train/J'.
    Moved 'I0_jpg.rf.21bbe6c53fdee3de18552752ab116502.jpg' to 'CNN_Train/I'.
    Moved 'G24_jpg.rf.c9ed63fb8ea3dd9d8b2ad866f8b5aa16.jpg' to 'CNN_Train/G'.
    Moved 'S17_jpg.rf.fff4096dcee5716f16ea8e65ee5ef85d.jpg' to 'CNN_Train/S'.
    Moved 'B24_jpg.rf.a0824d973cf96253c3d7371996bb4af7.jpg' to 'CNN_Train/B'.
    Moved 'L22_jpg.rf.312f5a5d43310b114155a05de49cd369.jpg' to 'CNN_Train/L'.
    Moved 'H22_jpg.rf.b82be36228ab41a2c439b5eb658b4360.jpg' to 'CNN_Train/H'.
    Moved 'N17_jpg.rf.55dba65da797782cfc04964acc7c80a6.jpg' to 'CNN_Train/N'.
    Moved 'Y19_jpg.rf.4a8478c4a1261c876ab38626c779470f.jpg' to 'CNN_Train/Y'.
    Moved 'K7_jpg.rf.71e354164bcf1240f22093e024a08d34.jpg' to 'CNN_Train/K'.
    Moved 'I16_jpg.rf.73d93bee08f11aafa34f97e134dfbb5b.jpg' to 'CNN_Train/I'.
    Moved 'L3_jpg.rf.334868fc379e7e393fc06c3abcc8a86f.jpg' to 'CNN_Train/L'.
    Moved 'H17_jpg.rf.e601ae2622fd3a0ba2e4b58d88a694ff.jpg' to 'CNN_Train/H'.
    Moved 'X17_jpg.rf.dfbad9ddf9119c472713fbf573765906.jpg' to 'CNN_Train/X'.
    Moved 'G22_jpg.rf.e16c951ceabe8353d7a62b62540fdb6c.jpg' to 'CNN_Train/G'.
    Moved 'Z26_jpg.rf.259ff45a4422de7a713213187a672883.jpg' to 'CNN_Train/Z'.
    Moved 'M16_jpg.rf.9472476df679c9235f44231b371ef525.jpg' to 'CNN_Train/M'.
    Moved 'E6_jpg.rf.56aa1e8bdcb1e91cb8b7855a90f1f452.jpg' to 'CNN_Train/E'.
    Moved 'I26_jpg.rf.87ee1fb34abc9a9aca81529cc3fbccfb.jpg' to 'CNN_Train/I'.
    Moved 'J32_jpg.rf.baf7a1382ae392410f44cc25a037364b.jpg' to 'CNN_Train/J'.
    Moved 'G24_jpg.rf.ed9c5f116f14affcaccedfd52fd5c63c.jpg' to 'CNN_Train/G'.
    Moved 'X25_jpg.rf.daef5bb87f877f1dccc668f071a03846.jpg' to 'CNN_Train/X'.
    Moved 'R23_jpg.rf.489dad0a6127c2526aaf8c63c1af49ea.jpg' to 'CNN_Train/R'.
    Moved 'J18_jpg.rf.201af44ab450a6ba36f92c10a3ce36a2.jpg' to 'CNN_Train/J'.
    Moved 'H17_jpg.rf.1baace1a86461a7849d54050d41b980e.jpg' to 'CNN_Train/H'.
    Moved 'P6_jpg.rf.e3b8420d28d0df75beea3e89f2569c67.jpg' to 'CNN_Train/P'.
    Moved 'M22_jpg.rf.2cf0b07c63b1ef20e78df60f6a7b067f.jpg' to 'CNN_Train/M'.
    Moved 'H23_jpg.rf.b5691f8786672d48e042c29990fdcc0b.jpg' to 'CNN_Train/H'.
    Moved 'A6_jpg.rf.cc599760fd37ea163dcda60c01837b12.jpg' to 'CNN_Train/A'.
    Moved 'A8_jpg.rf.cf020fb91cb152037beac09205c22057.jpg' to 'CNN_Train/A'.
    Moved 'W8_jpg.rf.e76a494b4d06dc7026944cb29c967ef7.jpg' to 'CNN_Train/W'.
    Moved 'Q21_jpg.rf.256b0a53ddc72bcf4cf825ced2bdcf44.jpg' to 'CNN_Train/Q'.
    Moved 'R22_jpg.rf.83015251e51ab253cf59cad62b59384d.jpg' to 'CNN_Train/R'.
    Moved 'I24_jpg.rf.bc61f2e8907a28a5d95c0258dfe13bdb.jpg' to 'CNN_Train/I'.
    Moved 'P3_jpg.rf.4ced067aa5a9f506b6fda92e212a0f18.jpg' to 'CNN_Train/P'.
    Moved 'V7_jpg.rf.9359e19f0e3decf6697e15aeb3ab6267.jpg' to 'CNN_Train/V'.
    Moved 'E24_jpg.rf.85152fe67dd065365015fe2828d2ea85.jpg' to 'CNN_Train/E'.
    Moved 'J25_jpg.rf.c3184bc0e1245d145144468b9a0150ce.jpg' to 'CNN_Train/J'.
    Moved 'V23_jpg.rf.7e70db109d1f99a9ac2ff79c22061433.jpg' to 'CNN_Train/V'.
    Moved 'Z25_jpg.rf.cede51688571bb8a931ff6731ad8c90e.jpg' to 'CNN_Train/Z'.
    Moved 'X25_jpg.rf.6b245e6951c33e04bd4e9b0cd203e8e5.jpg' to 'CNN_Train/X'.
    Moved 'Q17_jpg.rf.8ae77931fc5bdbaba881697010fb63cd.jpg' to 'CNN_Train/Q'.
    Moved 'G6_jpg.rf.dabb8e9cdfe6ceb4d5483744b30c3e12.jpg' to 'CNN_Train/G'.
    Moved 'Z17_jpg.rf.3566bf3ec99ced310d9ae61e1193b4cd.jpg' to 'CNN_Train/Z'.
    Moved 'D21_jpg.rf.36bbb4bd98a5d22d51fa73171a78a56e.jpg' to 'CNN_Train/D'.
    Moved 'D19_jpg.rf.5d9717c58ca187d979972e7de9894d85.jpg' to 'CNN_Train/D'.
    Moved 'T20_jpg.rf.0812ead96147e8fa4ba6470912a81874.jpg' to 'CNN_Train/T'.
    Moved 'G0_jpg.rf.8f70b7b8329097881c61e1d535ca3e05.jpg' to 'CNN_Train/G'.
    Moved 'V20_jpg.rf.6fcac88e662687d530f439f9bb7352cf.jpg' to 'CNN_Train/V'.
    Moved 'S23_jpg.rf.201127639209565a23c897e6eb6a998b.jpg' to 'CNN_Train/S'.
    Moved 'L16_jpg.rf.15ecddb8d30f840c07b2c1bf16649857.jpg' to 'CNN_Train/L'.
    Moved 'W20_jpg.rf.fffe2d54b2d00bbad942f6a406503d87.jpg' to 'CNN_Train/W'.
    Moved 'D2_jpg.rf.a183e05bb9e6b5d2bc1c293d4326502b.jpg' to 'CNN_Train/D'.
    Moved 'Y3_jpg.rf.6d6ed02eb1111c3fb9ce6898574fdcc5.jpg' to 'CNN_Train/Y'.
    Moved 'S21_jpg.rf.5c209196fff85afc1848fd94a98dfbc7.jpg' to 'CNN_Train/S'.
    Moved 'G8_jpg.rf.ee0ae6c8e88c31bea22f9fbf6578ef39.jpg' to 'CNN_Train/G'.
    Moved 'O25_jpg.rf.c771f572ff41e1c7e2a5fe97387c2787.jpg' to 'CNN_Train/O'.
    Moved 'J37_jpg.rf.2bc8910528e862ba4d9d6d9587ce4914.jpg' to 'CNN_Train/J'.
    Moved 'X13_jpg.rf.015a5271f775ab06dd3af7cb59264404.jpg' to 'CNN_Train/X'.
    Moved 'B8_jpg.rf.c35c7270b4beba7e31bbb9dae22d5c82.jpg' to 'CNN_Train/B'.
    Moved 'Q23_jpg.rf.96911677117648a2119e5c297f51e1d9.jpg' to 'CNN_Train/Q'.
    Moved 'K21_jpg.rf.7121e10074271243aa0ec75982915234.jpg' to 'CNN_Train/K'.
    Moved 'Y22_jpg.rf.a9561ce5b6e31fb2382eaacd2604b753.jpg' to 'CNN_Train/Y'.
    Moved 'H10_jpg.rf.02fd419c4bf7c570ee19d8813124842d.jpg' to 'CNN_Train/H'.
    Moved 'J19_jpg.rf.dc3141184f8fe69b24a32e004fc6b971.jpg' to 'CNN_Train/J'.
    Moved 'B3_jpg.rf.64e0c9ae2fdb09151ec26fa10d8493ba.jpg' to 'CNN_Train/B'.
    Moved 'L22_jpg.rf.645981561f0e94c01dd7675886c5e65e.jpg' to 'CNN_Train/L'.
    Moved 'X11_jpg.rf.24c39eda049a60a81ea1b483feb25c7c.jpg' to 'CNN_Train/X'.
    Moved 'T3_jpg.rf.ea6e58654e6f68de2e0b7b12ac1d9dec.jpg' to 'CNN_Train/T'.
    Moved 'P0_jpg.rf.658af5b3795355cdda3503198e1a9c34.jpg' to 'CNN_Train/P'.
    Moved 'L10_jpg.rf.a80228ff3aa6cef6b7dd02efeeb89c6a.jpg' to 'CNN_Train/L'.
    Moved 'Q18_jpg.rf.38cf1d50ecb618d4edd52cae1514c242.jpg' to 'CNN_Train/Q'.
    Moved 'Z24_jpg.rf.531c717ba4cc78d0baa3344f00867728.jpg' to 'CNN_Train/Z'.
    Moved 'H22_jpg.rf.2163ca101bfb1359678f68d144f52cae.jpg' to 'CNN_Train/H'.
    Moved 'I11_jpg.rf.15287860f4e8a699384284c2b39a6584.jpg' to 'CNN_Train/I'.
    Moved 'W17_jpg.rf.1975003e49350c2dca16bfcc3dc2c342.jpg' to 'CNN_Train/W'.
    Moved 'I5_jpg.rf.0df75ef36732423de39cd0066501a596.jpg' to 'CNN_Train/I'.
    Moved 'K25_jpg.rf.aa60dd14efaef3670884f83f5e8e0416.jpg' to 'CNN_Train/K'.
    Moved 'C6_jpg.rf.9f80dbbfd3bd0b4b9ec4a5d40adbc9bb.jpg' to 'CNN_Train/C'.
    Moved 'J19_jpg.rf.67079eada2061b781f593069eff8ad59.jpg' to 'CNN_Train/J'.
    Moved 'J2_jpg.rf.f6e5626116ae40d6e0ec2e85e6971646.jpg' to 'CNN_Train/J'.
    Moved 'Z24_jpg.rf.07aefac43745876d1f4e260afc706b3e.jpg' to 'CNN_Train/Z'.
    Moved 'K4_jpg.rf.00821732715c9137b8060360770ea1d8.jpg' to 'CNN_Train/K'.
    Moved 'L4_jpg.rf.27d10f4c9a216e757bface0540f1d998.jpg' to 'CNN_Train/L'.
    Moved 'O14_jpg.rf.df7a8fabf8dfbcc45a9a4fee5636225f.jpg' to 'CNN_Train/O'.
    Moved 'U16_jpg.rf.4b122d169e259f162f3b5597922ea988.jpg' to 'CNN_Train/U'.
    Moved 'W13_jpg.rf.be6ea4834bef8c63552e85d5c12546ab.jpg' to 'CNN_Train/W'.
    Moved 'B11_jpg.rf.ab157a1ed10cef51d66cfd6da805a581.jpg' to 'CNN_Train/B'.
    Moved 'U14_jpg.rf.55178b98f2d7bc5769f44f3ab306f58f.jpg' to 'CNN_Train/U'.
    Moved 'L13_jpg.rf.b8cd7bbf8ddcd5fdb126a597cfe7d311.jpg' to 'CNN_Train/L'.
    Moved 'H12_jpg.rf.23a256df86644a4451a2c1d4ca56002d.jpg' to 'CNN_Train/H'.
    Moved 'Z14_jpg.rf.b200298397492aa1e9e1b58440d8edbf.jpg' to 'CNN_Train/Z'.
    Moved 'Q12_jpg.rf.8d5336d82241c58fbaea7ee00b13341c.jpg' to 'CNN_Train/Q'.
    Moved 'G10_jpg.rf.d7ca319a75dcd674389b1c744a6d7032.jpg' to 'CNN_Train/G'.
    Moved 'J13_jpg.rf.a755c49bc5a3dbeb6a3793227851aa53.jpg' to 'CNN_Train/J'.
    Moved 'Y18_jpg.rf.1895434cacd913e7fa4929e3c64afb53.jpg' to 'CNN_Train/Y'.
    Moved 'G2_jpg.rf.72578111ac5b7f7ba7e87a424664ee5e.jpg' to 'CNN_Train/G'.
    Moved 'D2_jpg.rf.ef68fafadb9c0afc220b4ed677771c12.jpg' to 'CNN_Train/D'.
    Moved 'E23_jpg.rf.3d39a3ef37b87db044db05ad192afa77.jpg' to 'CNN_Train/E'.
    Moved 'I8_jpg.rf.74e4b289a4a3025955d4ccd2a8e4bac7.jpg' to 'CNN_Train/I'.
    Moved 'A13_jpg.rf.ae43f794ac52ed83c47f4df799a3504e.jpg' to 'CNN_Train/A'.
    Moved 'Q16_jpg.rf.25db6c9097b7706463db61747264488f.jpg' to 'CNN_Train/Q'.
    Moved 'A21_jpg.rf.882e1a6a98ba26a8f7bc2c046f8b9d38.jpg' to 'CNN_Train/A'.
    Moved 'P12_jpg.rf.0046c1c30abbbccd31716c5b2ad835b9.jpg' to 'CNN_Train/P'.
    Moved 'M8_jpg.rf.9f82d2c7577d0af15c22bca5cd2f1add.jpg' to 'CNN_Train/M'.
    Moved 'N23_jpg.rf.49cada42ec712325879dc9f2e7596c4a.jpg' to 'CNN_Train/N'.
    Moved 'S5_jpg.rf.7391e9787825c7fa0c6df841ecb21db8.jpg' to 'CNN_Train/S'.
    Moved 'A23_jpg.rf.97a11ab11034ee600679a123a8b8cb20.jpg' to 'CNN_Train/A'.
    Moved 'Q18_jpg.rf.92d4673df9911bd2611bd020acd70d04.jpg' to 'CNN_Train/Q'.
    Moved 'Y9_jpg.rf.a65336fbc22d605d63c15b1b1f316f6d.jpg' to 'CNN_Train/Y'.
    Moved 'C14_jpg.rf.6ff8a8c481016a9920f334954c7f0130.jpg' to 'CNN_Train/C'.
    Moved 'X0_jpg.rf.9128422a7789b7b340d34431cba43035.jpg' to 'CNN_Train/X'.
    Moved 'Q21_jpg.rf.2122e8c1b9581342635d4aa7d0ec4799.jpg' to 'CNN_Train/Q'.
    Moved 'I22_jpg.rf.ae3bdc351d37b68b1b8bff8b8bdbc52a.jpg' to 'CNN_Train/I'.
    Moved 'U8_jpg.rf.604374bda2bd03039aa170c2b97a4241.jpg' to 'CNN_Train/U'.
    Moved 'I10_jpg.rf.3fb784cb3821c584a4a97ea0bec750d0.jpg' to 'CNN_Train/I'.
    Moved 'X4_jpg.rf.a611bac9f5f77d76cdadf436fdebbd91.jpg' to 'CNN_Train/X'.
    Moved 'F1_jpg.rf.45e58e9dc2196990d17131271f112f66.jpg' to 'CNN_Train/F'.
    Moved 'C18_jpg.rf.1f4779c94ba51a17eb060430bfdefe84.jpg' to 'CNN_Train/C'.
    Moved 'I26_jpg.rf.63e2457881e1d6a3c30efd146db8b644.jpg' to 'CNN_Train/I'.
    Moved 'E9_jpg.rf.efdc0472937b01578d7a9f3216c2333c.jpg' to 'CNN_Train/E'.
    Moved 'E8_jpg.rf.a863c77bc0b3b7d0bc0f225e7aba08bf.jpg' to 'CNN_Train/E'.
    Moved 'M19_jpg.rf.d0680b7370c2a2c20e9491b008d82d03.jpg' to 'CNN_Train/M'.
    Moved 'T19_jpg.rf.f20ea052912fba08fade29734b945871.jpg' to 'CNN_Train/T'.
    Moved 'A18_jpg.rf.cdfec85406c77cb02c76566b4abb99a0.jpg' to 'CNN_Train/A'.
    Moved 'F14_jpg.rf.6d3c6163a285eafd8b0e996cee8ebcd4.jpg' to 'CNN_Train/F'.
    Moved 'F25_jpg.rf.e43aa5b3641463b191ce8d9bbf96086e.jpg' to 'CNN_Train/F'.
    Moved 'F24_jpg.rf.34619c0aba15b011b6da4db4f6b99b2f.jpg' to 'CNN_Train/F'.
    Moved 'S13_jpg.rf.8b10a365a12c411efc3eaed20d331fc4.jpg' to 'CNN_Train/S'.
    Moved 'L19_jpg.rf.832c5fcb38723e855707daeed86c3e9a.jpg' to 'CNN_Train/L'.
    Moved 'J20_jpg.rf.0a223d52fa082ab48c2bdf23aad0ff4d.jpg' to 'CNN_Train/J'.
    Moved 'J33_jpg.rf.58226b55090430d0220502a0f38d36e5.jpg' to 'CNN_Train/J'.
    Moved 'B18_jpg.rf.8cb122d333bb54ab4b1d92bc349d14c4.jpg' to 'CNN_Train/B'.
    Moved 'A21_jpg.rf.25989adc250642785d76ad99c56867a8.jpg' to 'CNN_Train/A'.
    Moved 'D10_jpg.rf.cce8ddcd70c8169d500b162a907842a8.jpg' to 'CNN_Train/D'.
    Moved 'B20_jpg.rf.ba7e2416ab8d1497ca22cc56956367b1.jpg' to 'CNN_Train/B'.
    Moved 'N20_jpg.rf.a2dbbc81a60a85d3c83aad148850fd45.jpg' to 'CNN_Train/N'.
    Moved 'B2_jpg.rf.eb77904436b69b3fa5a875b5d018a2c7.jpg' to 'CNN_Train/B'.
    Moved 'X6_jpg.rf.cba76a8396d82d53bfc43e218372df27.jpg' to 'CNN_Train/X'.
    Moved 'Z28_jpg.rf.61c88a1a338094c8780576206a29548e.jpg' to 'CNN_Train/Z'.
    Moved 'V9_jpg.rf.6a272dd6d342fef3d02b04f418ee9fa9.jpg' to 'CNN_Train/V'.
    Moved 'X2_jpg.rf.69b718ce040a23218a95c8cc852b5ca4.jpg' to 'CNN_Train/X'.
    Moved 'R13_jpg.rf.9af923a6168e4773123713d92b2833ab.jpg' to 'CNN_Train/R'.
    Moved 'L9_jpg.rf.7ae0279411ee9abb78e05f61993bb8de.jpg' to 'CNN_Train/L'.
    Moved 'C8_jpg.rf.ff0486d68a896bb9b648d42f6beef136.jpg' to 'CNN_Train/C'.
    Moved 'Q25_jpg.rf.63504e3540182fc45d609b400f730768.jpg' to 'CNN_Train/Q'.
    Moved 'J36_jpg.rf.8e09f1449219d3c7a6c44723a4df12e5.jpg' to 'CNN_Train/J'.
    Moved 'V17_jpg.rf.78e7ba590934b81ba324e211a223f70a.jpg' to 'CNN_Train/V'.
    Moved 'K2_jpg.rf.293e6f972bf9ad34f687d8d97a545ec9.jpg' to 'CNN_Train/K'.
    Moved 'L17_jpg.rf.8d425d11b595d8b3bec0b5172c5a82c4.jpg' to 'CNN_Train/L'.
    Moved 'I23_jpg.rf.55ba20132de172c54dfc3e951bb86616.jpg' to 'CNN_Train/I'.
    Moved 'B17_jpg.rf.47684bd82b6f784ab02cf17155f9fbd3.jpg' to 'CNN_Train/B'.
    Moved 'W11_jpg.rf.7ee0dbfc087573e240decfefea681112.jpg' to 'CNN_Train/W'.
    Moved 'S25_jpg.rf.8c93d05f0c69ad72f0c2c5e791968366.jpg' to 'CNN_Train/S'.
    Moved 'Q16_jpg.rf.4bb45d54bcc5cf59b646870e86ade0b7.jpg' to 'CNN_Train/Q'.
    Moved 'Z23_jpg.rf.ea4b293399e15c6372b7441d268ba696.jpg' to 'CNN_Train/Z'.
    Moved 'J34_jpg.rf.991a81aa9464b44233f285206b74c5f8.jpg' to 'CNN_Train/J'.
    Moved 'K16_jpg.rf.654ed1a5caeef48c3e5836adbe6f4023.jpg' to 'CNN_Train/K'.
    Moved 'T19_jpg.rf.e061682b688026bd207e1a1419ea9e81.jpg' to 'CNN_Train/T'.
    Moved 'J7_jpg.rf.6ee8599a36d18240149dd36c1b163c99.jpg' to 'CNN_Train/J'.
    Moved 'W0_jpg.rf.321e159ee0a16a055a567993d50722bb.jpg' to 'CNN_Train/W'.
    Moved 'I23_jpg.rf.d5a4451e540c455574d6d707830cdc62.jpg' to 'CNN_Train/I'.
    Moved 'R3_jpg.rf.1dfe76b0988c13fc7c8cc19bd87ac667.jpg' to 'CNN_Train/R'.
    Moved 'E9_jpg.rf.15357b0c33510b84dc822870ed1275a3.jpg' to 'CNN_Train/E'.
    Moved 'J22_jpg.rf.7329cb4fee2b6670cf2cdd3dd5f6af74.jpg' to 'CNN_Train/J'.
    Moved 'P7_jpg.rf.cecb008bfe853ebaa4979b3f97013171.jpg' to 'CNN_Train/P'.
    Moved 'Z23_jpg.rf.704b2da7d23019957181835f96e42cf3.jpg' to 'CNN_Train/Z'.
    Moved 'I24_jpg.rf.963a1383f81d7225ad074f4928a3a6e1.jpg' to 'CNN_Train/I'.
    Moved 'N21_jpg.rf.2f2b683c4b9ca5fa2ed3ab67c220c407.jpg' to 'CNN_Train/N'.
    Moved 'O1_jpg.rf.01eb8369467a4e02535411288eef34f7.jpg' to 'CNN_Train/O'.
    Moved 'U10_jpg.rf.acb9242e5cbc57a2b47ff6993460b365.jpg' to 'CNN_Train/U'.
    Moved 'V14_jpg.rf.8d8bd83ba75df87ffc409b021d544c1a.jpg' to 'CNN_Train/V'.
    Moved 'P22_jpg.rf.67d9823ec6302d86005f97a04e4a611c.jpg' to 'CNN_Train/P'.
    Moved 'A15_jpg.rf.ff648f0ba648df1d2782e75ddea0f9ba.jpg' to 'CNN_Train/A'.
    Moved 'D26_jpg.rf.9b4bc57e8bf4b35e22b74d136b8fbadc.jpg' to 'CNN_Train/D'.
    Moved 'Q3_jpg.rf.6f37d6bc8296259ebc13369a9daa11b2.jpg' to 'CNN_Train/Q'.
    Moved 'M15_jpg.rf.4385f93af3c86d7db4299de00749d8df.jpg' to 'CNN_Train/M'.
    Moved 'Z26_jpg.rf.4a1805ac52f6fe66a120b9b20b10f944.jpg' to 'CNN_Train/Z'.
    Moved 'P22_jpg.rf.c244245dab3f440d5e3e77d1487bdde7.jpg' to 'CNN_Train/P'.
    Moved 'F7_jpg.rf.f6f792e8e4e72cb236acbef4fa94fe76.jpg' to 'CNN_Train/F'.
    Moved 'O25_jpg.rf.957001b8f1a79a52c5cafdad4cd6ed4f.jpg' to 'CNN_Train/O'.
    Moved 'D3_jpg.rf.321ad8bad5a67b3e9a026bde0a51f3cf.jpg' to 'CNN_Train/D'.
    Moved 'V8_jpg.rf.13a92e73a072998c0ca9494cc74fc1de.jpg' to 'CNN_Train/V'.
    Moved 'E1_jpg.rf.c7db718583051dfb4ea52b76d165176e.jpg' to 'CNN_Train/E'.
    Moved 'O24_jpg.rf.f3415587f4f07b20350d11f64cf93303.jpg' to 'CNN_Train/O'.
    Moved 'E12_jpg.rf.569e076c619b027c9d3258a6a85ae3c5.jpg' to 'CNN_Train/E'.
    Moved 'J19_jpg.rf.e48b6808342f54aa56d3d776cf0065bf.jpg' to 'CNN_Train/J'.
    Moved 'X2_jpg.rf.6bf9668a90c77d52fc8cb7b5f3a1ca6e.jpg' to 'CNN_Train/X'.
    Moved 'Z29_jpg.rf.64a16f3aec369f9abc15186097a1a1a5.jpg' to 'CNN_Train/Z'.
    Moved 'L1_jpg.rf.e44e002dbcfce26ca84d1b8c3be4a99f.jpg' to 'CNN_Train/L'.
    Moved 'P21_jpg.rf.2f03494f57e3a11e365494e9e2bfbbf5.jpg' to 'CNN_Train/P'.
    Moved 'D19_jpg.rf.199140d37ba69d88a7e923bb895fcd4b.jpg' to 'CNN_Train/D'.
    Moved 'Z26_jpg.rf.3c87af0145dabb4105f09c8715829d3f.jpg' to 'CNN_Train/Z'.
    Moved 'H26_jpg.rf.5e4006cd44bacf869a9d6b115eaa23ac.jpg' to 'CNN_Train/H'.
    Moved 'F9_jpg.rf.49530fa808c83a35dc0e2520760a29dd.jpg' to 'CNN_Train/F'.
    Moved 'B22_jpg.rf.6f7022546e944e83aef466d6a63b5f8c.jpg' to 'CNN_Train/B'.
    Moved 'A27_jpg.rf.a01fe29d02057b7c0d876bf8ccacd255.jpg' to 'CNN_Train/A'.
    Moved 'T9_jpg.rf.d545de7c5f90949ea31fd50b990afc52.jpg' to 'CNN_Train/T'.
    Moved 'E10_jpg.rf.563d7d9228bc5e4eacc9272ba7a4c4b2.jpg' to 'CNN_Train/E'.
    Moved 'A1_jpg.rf.c4ccc21338f79e0f68d89dfc817ddd1f.jpg' to 'CNN_Train/A'.
    Moved 'I11_jpg.rf.8b38bd4cb8ee06f67ff561a61bf44f66.jpg' to 'CNN_Train/I'.
    Moved 'N17_jpg.rf.852a86e64b757de1cef45750896659de.jpg' to 'CNN_Train/N'.
    Moved 'G19_jpg.rf.5d30b29d9e6ea44956e9fa7bfe5e6624.jpg' to 'CNN_Train/G'.
    Moved 'V14_jpg.rf.d46a757a1bb011fb58ec9bb7196d562d.jpg' to 'CNN_Train/V'.
    Moved 'N4_jpg.rf.47f777d2f2a24ae7e8468e137e6abdaa.jpg' to 'CNN_Train/N'.
    Moved 'P20_jpg.rf.cca700a498c46a597c5416076cb383e2.jpg' to 'CNN_Train/P'.
    Moved 'K3_jpg.rf.63e9984b36cf41a5adccc8c273db9e09.jpg' to 'CNN_Train/K'.
    Moved 'Y2_jpg.rf.a349391ff1e9b4ce7f779065b7b2e6a9.jpg' to 'CNN_Train/Y'.
    Moved 'F26_jpg.rf.04b690cb8e2f6349e6e2091dc246230b.jpg' to 'CNN_Train/F'.
    Moved 'B7_jpg.rf.e45ff70ea02654e6a765edba2603a9d8.jpg' to 'CNN_Train/B'.
    Moved 'C24_jpg.rf.ed5cf959b467cda4318fe300fcbf2573.jpg' to 'CNN_Train/C'.
    Moved 'B3_jpg.rf.64dc52ffe5ef2168c1108afc30503111.jpg' to 'CNN_Train/B'.
    Moved 'N26_jpg.rf.aaad75a3f8ee527d151e908e01d069d9.jpg' to 'CNN_Train/N'.
    Moved 'E15_jpg.rf.e12cbd0e7be4630ebebdd6250cd76b9d.jpg' to 'CNN_Train/E'.
    Moved 'L8_jpg.rf.d62f465a90d226d7bd0b8e03fca6b8bb.jpg' to 'CNN_Train/L'.
    Moved 'Q13_jpg.rf.8cbfbd3699e8252108bcb98059a9b0eb.jpg' to 'CNN_Train/Q'.
    Moved 'E0_jpg.rf.926e842cd69d98b54aec8c371d61bf8d.jpg' to 'CNN_Train/E'.
    Moved 'Y8_jpg.rf.ccd5d9ebf920f108455ff8c15910c6d6.jpg' to 'CNN_Train/Y'.
    Moved 'N0_jpg.rf.42b5818c7451bff8f1a419d0517bd766.jpg' to 'CNN_Train/N'.
    Moved 'Q15_jpg.rf.f6ff52e539d0c927bc358d9fdd844857.jpg' to 'CNN_Train/Q'.
    Moved 'H8_jpg.rf.32c990f95933e9fadc758fab16dd9652.jpg' to 'CNN_Train/H'.
    Moved 'G16_jpg.rf.514f0da5f5350ee94c4e1937b2076fdd.jpg' to 'CNN_Train/G'.
    Moved 'H16_jpg.rf.5bcd358fdb7532d0df55fb0daf7f571a.jpg' to 'CNN_Train/H'.
    Moved 'H26_jpg.rf.858f0da66c30d7d93fc3dd58dbf677df.jpg' to 'CNN_Train/H'.
    Moved 'E20_jpg.rf.17cd74f7da2ebe2651533a7c29bf40e9.jpg' to 'CNN_Train/E'.
    Moved 'G16_jpg.rf.20bbfcc529e2547722dfaf6913421a1c.jpg' to 'CNN_Train/G'.
    Moved 'W0_jpg.rf.56cbf53c6656f23683d8e61c3f5fd6ee.jpg' to 'CNN_Train/W'.
    Moved 'M4_jpg.rf.1e94cac19b236e16f867f4292775a7a3.jpg' to 'CNN_Train/M'.
    Moved 'A17_jpg.rf.e59e6baab9d6c91b09c3bca65404aed1.jpg' to 'CNN_Train/A'.
    Moved 'D2_jpg.rf.9949b39905135d4b5f7832b1d4d78f94.jpg' to 'CNN_Train/D'.
    Moved 'D8_jpg.rf.0fd7ece4e33af067b8ff64cf9b8c07ca.jpg' to 'CNN_Train/D'.
    Moved 'Y15_jpg.rf.aca2466b3c911a5e1c8a4064d0047c4e.jpg' to 'CNN_Train/Y'.
    Moved 'X7_jpg.rf.396a799d9e21c4fe1477d646dccdb4e3.jpg' to 'CNN_Train/X'.
    Moved 'K7_jpg.rf.bd3cc7f03559a5257494f42f90f787cd.jpg' to 'CNN_Train/K'.
    Moved 'P11_jpg.rf.9b26d13b93934be87017b9e91689e462.jpg' to 'CNN_Train/P'.
    Moved 'M11_jpg.rf.e2b25556138d77f4f4623470a5ed7530.jpg' to 'CNN_Train/M'.
    Moved 'F6_jpg.rf.efb81ddedf7b398685af898a95d22a33.jpg' to 'CNN_Train/F'.
    Moved 'C14_jpg.rf.4990e1d25f4caabefcdfcdc245853913.jpg' to 'CNN_Train/C'.
    Moved 'I21_jpg.rf.328043e6a4cb647415a0d701e169bcab.jpg' to 'CNN_Train/I'.
    Moved 'W10_jpg.rf.ee44bd6478acedaca641bc728337e83b.jpg' to 'CNN_Train/W'.
    Moved 'Y8_jpg.rf.471a4b651ce3aba784805e5373e7994c.jpg' to 'CNN_Train/Y'.
    Moved 'L5_jpg.rf.db3cc2c72459df50ac1b7a41ea20a670.jpg' to 'CNN_Train/L'.
    Moved 'Y9_jpg.rf.82c8cb326bd0bf2242bfc4a57633a0e1.jpg' to 'CNN_Train/Y'.
    Moved 'W13_jpg.rf.ece3446a78337a829bcbd8d480609364.jpg' to 'CNN_Train/W'.
    Moved 'R12_jpg.rf.e3dbb27c01cf6077dca09d5434cc7a54.jpg' to 'CNN_Train/R'.
    Moved 'B13_jpg.rf.c13a25ad892a1fdcb79ee99acfa698a8.jpg' to 'CNN_Train/B'.
    Moved 'J23_jpg.rf.7d4060f073e849a7d7980866f41c4a1f.jpg' to 'CNN_Train/J'.
    Moved 'W6_jpg.rf.4e05a2411c56630c05b276ee7b2eee7c.jpg' to 'CNN_Train/W'.
    Moved 'B4_jpg.rf.b39ad92d94c21068eb73c14768c29eef.jpg' to 'CNN_Train/B'.
    Moved 'S7_jpg.rf.f03a27fd08acb4e13ca8cb1108ab9ec4.jpg' to 'CNN_Train/S'.
    Moved 'F12_jpg.rf.086aa13ff5236066ec979fbb5b90e0a5.jpg' to 'CNN_Train/F'.
    Moved 'G15_jpg.rf.ff09e2ae46cb50c329c7be9075b01879.jpg' to 'CNN_Train/G'.
    Moved 'N2_jpg.rf.6dbb1a476cf95ed2297387a6499250bb.jpg' to 'CNN_Train/N'.
    Moved 'C3_jpg.rf.656ce5ccdfdd18b77ad33c0ece7ae8fe.jpg' to 'CNN_Train/C'.
    Moved 'D24_jpg.rf.cb3cf7b04b5f557f7b11b3a97f83aab4.jpg' to 'CNN_Train/D'.
    Moved 'I0_jpg.rf.9dc9f090b7475a65889b24265858d240.jpg' to 'CNN_Train/I'.
    Moved 'E9_jpg.rf.6c965b36d65ab495d177aca9d53190f7.jpg' to 'CNN_Train/E'.
    Moved 'P19_jpg.rf.38628e1b6f02c0eaf1c7b29e042ce7d1.jpg' to 'CNN_Train/P'.
    Moved 'S24_jpg.rf.31da2525e9bbb5925bc84dd5c33db55e.jpg' to 'CNN_Train/S'.
    Moved 'N2_jpg.rf.c85460f1ff7455fbef19573cfd3c21db.jpg' to 'CNN_Train/N'.
    Moved 'T6_jpg.rf.02bb707b9ac0fb76c97517ccf4f47ab4.jpg' to 'CNN_Train/T'.
    Moved 'Q5_jpg.rf.ece1b371bd3b9865b13a6c3436632cb7.jpg' to 'CNN_Train/Q'.
    Moved 'E11_jpg.rf.8914cabd0f7d2ddb5cc828bd56abba3c.jpg' to 'CNN_Train/E'.
    Moved 'L6_jpg.rf.5592edce54a5b213eba0bd1d7412ed3b.jpg' to 'CNN_Train/L'.
    Moved 'U4_jpg.rf.a7ac80850fc36d2f3d5e947c2f92ab8b.jpg' to 'CNN_Train/U'.
    Moved 'N8_jpg.rf.2af37147b97d513636abfa807c617864.jpg' to 'CNN_Train/N'.
    Moved 'A26_jpg.rf.1fc964f5ed03b450b754a5427b66ecce.jpg' to 'CNN_Train/A'.
    Moved 'M22_jpg.rf.999b428265334fcfe5fd0988bfaa8daf.jpg' to 'CNN_Train/M'.
    Moved 'U14_jpg.rf.1a8882998b37b6b8fcc46b6683e1f66e.jpg' to 'CNN_Train/U'.
    Moved 'J20_jpg.rf.b968be6b0d236660bf244a78711e968b.jpg' to 'CNN_Train/J'.
    Moved 'A18_jpg.rf.961cde89dba6fa66758fcf505cd4560e.jpg' to 'CNN_Train/A'.
    Moved 'W4_jpg.rf.407981a1c9711a18ec27088861ce5ed8.jpg' to 'CNN_Train/W'.
    Moved 'C24_jpg.rf.71696292097ccc75c635401c514e235e.jpg' to 'CNN_Train/C'.
    Moved 'J25_jpg.rf.a8a578110702c2fc4f57ee916eb7af75.jpg' to 'CNN_Train/J'.
    Moved 'F9_jpg.rf.8df49ef73dcb1a370e0cfd721e2029f9.jpg' to 'CNN_Train/F'.
    Moved 'F28_jpg.rf.12d1870b462239f7d1f87630418e3f06.jpg' to 'CNN_Train/F'.
    Moved 'T14_jpg.rf.ccbe1ccadd5a7b8eace3e06c1815c727.jpg' to 'CNN_Train/T'.
    Moved 'O1_jpg.rf.8adca4e6198e64065b9e858c2fd92dc8.jpg' to 'CNN_Train/O'.
    Moved 'A6_jpg.rf.37c4f4c6b45868e088a8ac2bc517952a.jpg' to 'CNN_Train/A'.
    Moved 'J13_jpg.rf.a9f44e6c303c295651a24c1ec0f200d9.jpg' to 'CNN_Train/J'.
    Moved 'J30_jpg.rf.1830920374b6aec82ee84443edda5734.jpg' to 'CNN_Train/J'.
    Moved 'Z6_jpg.rf.a8c0988bf9701e6d6f72761fde6dfb38.jpg' to 'CNN_Train/Z'.
    Moved 'F7_jpg.rf.dc42a40c0acd5cc2f309d179b0679f2a.jpg' to 'CNN_Train/F'.
    Moved 'M1_jpg.rf.411bd85388ef9cb634f3d11439466266.jpg' to 'CNN_Train/M'.
    Moved 'W15_jpg.rf.12b50d1527e1a50debd5df1f5982ced0.jpg' to 'CNN_Train/W'.
    Moved 'X21_jpg.rf.99547d367f8baf8b52fd74468d6df5da.jpg' to 'CNN_Train/X'.
    Moved 'O19_jpg.rf.ebc8aaf616665a1f6017f8837dfe59c8.jpg' to 'CNN_Train/O'.
    Moved 'Z29_jpg.rf.6f544d1ec011d28eb0783d266b0d7096.jpg' to 'CNN_Train/Z'.
    Moved 'V19_jpg.rf.77360f0e81105cf1800e43e703786c43.jpg' to 'CNN_Train/V'.
    Moved 'X5_jpg.rf.694d75a9915efefe09b6e158eb529504.jpg' to 'CNN_Train/X'.
    Moved 'G26_jpg.rf.581ec377b69d4df5d5edced7c61cdce9.jpg' to 'CNN_Train/G'.
    Moved 'J18_jpg.rf.06e1abf3eae85a7bb86f4bfb7322d055.jpg' to 'CNN_Train/J'.
    Moved 'D14_jpg.rf.db2f3d25f95c44309de719ef46cdeba3.jpg' to 'CNN_Train/D'.
    Moved 'O24_jpg.rf.5c37f7d4bda24adaa54f1b57790bf204.jpg' to 'CNN_Train/O'.
    Moved 'H4_jpg.rf.1090c3e2c1edc37d7b2ecd5b9eb6f06e.jpg' to 'CNN_Train/H'.
    Moved 'F22_jpg.rf.f2b2608ddda4278402d321a0c6de8841.jpg' to 'CNN_Train/F'.
    Moved 'N20_jpg.rf.4cca7e9378f0fed1b5ff0c3ac2f57369.jpg' to 'CNN_Train/N'.
    Moved 'V6_jpg.rf.abe8dcc914d6553a39478c1979b4f1cf.jpg' to 'CNN_Train/V'.
    Moved 'O16_jpg.rf.ef26fc3ff420bdd1238bfd720cc673d1.jpg' to 'CNN_Train/O'.
    Moved 'E12_jpg.rf.de4c70ed7b79826667ab5de4c839e50b.jpg' to 'CNN_Train/E'.
    Moved 'J1_jpg.rf.d0108d67d35575d9198dc5bcb47d49ba.jpg' to 'CNN_Train/J'.
    Moved 'M1_jpg.rf.e8baa638b9f67b9365573d264feeb63b.jpg' to 'CNN_Train/M'.
    Moved 'C4_jpg.rf.c3db9ad78a50fe5d749e3ab1e9f33742.jpg' to 'CNN_Train/C'.
    Moved 'O27_jpg.rf.23cd5788be9d6c160dfbd00b44e89cfe.jpg' to 'CNN_Train/O'.
    Moved 'S5_jpg.rf.bad1cedd24fd7abf7f775734ff57a3b1.jpg' to 'CNN_Train/S'.
    Moved 'L4_jpg.rf.8870ba7a738f38929002c310cb4a6c8c.jpg' to 'CNN_Train/L'.
    Moved 'J29_jpg.rf.9106ad50958f8c23a3716a7d36cff164.jpg' to 'CNN_Train/J'.
    Moved 'Z5_jpg.rf.b6f759aa37696436dbfadbb167230f40.jpg' to 'CNN_Train/Z'.
    Moved 'H24_jpg.rf.3f2729855fa8123d3a43e178b59f4f73.jpg' to 'CNN_Train/H'.
    Moved 'M3_jpg.rf.963dfc5d19252a7898d550e0bee13982.jpg' to 'CNN_Train/M'.
    Moved 'J21_jpg.rf.c1da1d3b649009d9c33048d5f4aeea7c.jpg' to 'CNN_Train/J'.
    Moved 'W2_jpg.rf.1dc97a95e879879b319ae82d95766ea2.jpg' to 'CNN_Train/W'.
    Moved 'L7_jpg.rf.69f54c5378bc15c973f5c4c412b1dc9e.jpg' to 'CNN_Train/L'.
    Moved 'A16_jpg.rf.4792e25fdaf24e4180ae1a9c1513a39a.jpg' to 'CNN_Train/A'.
    Moved 'N8_jpg.rf.dee7f7937525aab7172c55d4d7ae6d10.jpg' to 'CNN_Train/N'.
    Moved 'Y11_jpg.rf.9f541a43d08e04e61b96a6d4c0038cc0.jpg' to 'CNN_Train/Y'.
    Moved 'L24_jpg.rf.4d41dc21185fc2668a72c3f2eb477179.jpg' to 'CNN_Train/L'.
    Moved 'G27_jpg.rf.5175c016a4ba62b4c4c74d69bb681103.jpg' to 'CNN_Train/G'.
    Moved 'S18_jpg.rf.867c634edf5e80364ed863a3b4fd6828.jpg' to 'CNN_Train/S'.
    Moved 'R11_jpg.rf.9c744e0fefcb9d26e4d4c1c0d90b3fa6.jpg' to 'CNN_Train/R'.
    Moved 'U12_jpg.rf.caab030d17c3d09fd2aa7a6f251fdf58.jpg' to 'CNN_Train/U'.
    Moved 'L25_jpg.rf.602c7855b9282cca41a1303b8d8ce973.jpg' to 'CNN_Train/L'.
    Moved 'Q21_jpg.rf.efb3bf4cfd8f291bc60fb2e50628468c.jpg' to 'CNN_Train/Q'.
    Moved 'O6_jpg.rf.22dbe941aaf50be0bab0feb763fa1344.jpg' to 'CNN_Train/O'.
    Moved 'M4_jpg.rf.cf07293744b055d2b1f0972ef342207a.jpg' to 'CNN_Train/M'.
    Moved 'Q12_jpg.rf.50e64595d65da5b53e0694b1596f55c2.jpg' to 'CNN_Train/Q'.
    Moved 'X10_jpg.rf.b3a5b7e5bc428750c647f9bbe18f2099.jpg' to 'CNN_Train/X'.
    Moved 'J15_jpg.rf.b5d6738e225226c47a4a74f4218a325b.jpg' to 'CNN_Train/J'.
    Moved 'Q25_jpg.rf.ade8cb837424aad88ac8c9de8fa67da9.jpg' to 'CNN_Train/Q'.
    Moved 'K2_jpg.rf.44d827e0289600627e1fcc43197301cb.jpg' to 'CNN_Train/K'.
    Moved 'E14_jpg.rf.7c6faed376e1936c99234c1ff76e4fa2.jpg' to 'CNN_Train/E'.
    Moved 'H28_jpg.rf.d5317b701de30d4fcab0607a552a30d3.jpg' to 'CNN_Train/H'.
    Moved 'T15_jpg.rf.0d977919477c9d5c4da3856cf9cc849c.jpg' to 'CNN_Train/T'.
    Moved 'V18_jpg.rf.6e602adf4f2b566b81d60cd4ba06f211.jpg' to 'CNN_Train/V'.
    Moved 'Q11_jpg.rf.47af03900b486f8e43485cae66983972.jpg' to 'CNN_Train/Q'.
    Moved 'H28_jpg.rf.03600eb345a61fbd4c2af1f068f8be57.jpg' to 'CNN_Train/H'.
    Moved 'K3_jpg.rf.66651e2fd83f4622815c2635819be065.jpg' to 'CNN_Train/K'.
    Moved 'V26_jpg.rf.e4683f0dbcfa9c9611e09e8cfd02c2bc.jpg' to 'CNN_Train/V'.
    Moved 'U8_jpg.rf.d2d85d0e1ae472a7e16e73cfb4be73c6.jpg' to 'CNN_Train/U'.
    Moved 'V22_jpg.rf.619405fdf139eb6e993866f1dd47ad3e.jpg' to 'CNN_Train/V'.
    Moved 'S3_jpg.rf.90a5981f827b33d7360e82abc16acbcc.jpg' to 'CNN_Train/S'.
    Moved 'E10_jpg.rf.210b2fb96ddccadc6ccfa75a7b66b4a2.jpg' to 'CNN_Train/E'.
    Moved 'W5_jpg.rf.c556b617af0eb952b41fca679e8f0358.jpg' to 'CNN_Train/W'.
    Moved 'J29_jpg.rf.f41e0665f17e42f072701c019565bb7f.jpg' to 'CNN_Train/J'.
    Moved 'I9_jpg.rf.dde8e9981e0775c74c4c65ec2970f5fd.jpg' to 'CNN_Train/I'.
    Moved 'H24_jpg.rf.7b186d18aee436d69a559e3b7b03236f.jpg' to 'CNN_Train/H'.
    Moved 'N5_jpg.rf.ed9076ae20a2d10f60d27928005b0aea.jpg' to 'CNN_Train/N'.
    Moved 'I14_jpg.rf.98857edef78e71b90a23338374952c53.jpg' to 'CNN_Train/I'.
    Moved 'X6_jpg.rf.dbff8080be9bdb7f24e716eda2cb601d.jpg' to 'CNN_Train/X'.
    Moved 'Y24_jpg.rf.2fc348b87e7f265e285ccf133587287b.jpg' to 'CNN_Train/Y'.
    Moved 'J7_jpg.rf.72b76afb25ab19cedb77cb46f392e28c.jpg' to 'CNN_Train/J'.
    Moved 'S8_jpg.rf.dd0d9ac79f83c65651da27d96c3c0988.jpg' to 'CNN_Train/S'.
    Moved 'C10_jpg.rf.5bcf569d31edc542fb1d103907414379.jpg' to 'CNN_Train/C'.
    Moved 'X22_jpg.rf.561d1dfcf38c9f341910d1a8bfebcf3e.jpg' to 'CNN_Train/X'.
    Moved 'Q0_jpg.rf.788e5476de2964ef2f88d5d8bc871f2e.jpg' to 'CNN_Train/Q'.
    Moved 'Y1_jpg.rf.9ef2d22e8f554cc0671075c5a3ed2483.jpg' to 'CNN_Train/Y'.
    Moved 'T3_jpg.rf.1d01912a9c4bd4e068c4e379f11c03a9.jpg' to 'CNN_Train/T'.
    Moved 'I2_jpg.rf.47b23dfae90e651bc47ec0c850c74145.jpg' to 'CNN_Train/I'.
    Moved 'C11_jpg.rf.d73e10eef3b31268cf707d132323700a.jpg' to 'CNN_Train/C'.
    Moved 'W1_jpg.rf.34eb56825318b1dbbe657280dafbdd11.jpg' to 'CNN_Train/W'.
    Moved 'C8_jpg.rf.afc31b2e728dfe9eb0a92bc66ed0ecbc.jpg' to 'CNN_Train/C'.
    Moved 'D4_jpg.rf.f4ef8d3c0ff588c50ce095f206d20b99.jpg' to 'CNN_Train/D'.
    Moved 'Z17_jpg.rf.ab719b2b3051cfceb985af9c5d91c7c0.jpg' to 'CNN_Train/Z'.
    Moved 'L0_jpg.rf.e78fbab52fe3d227d0c70b025db90b5f.jpg' to 'CNN_Train/L'.
    Moved 'S14_jpg.rf.717b5283ad7bff53fd289794838c3993.jpg' to 'CNN_Train/S'.
    Moved 'J36_jpg.rf.d09b435b559455b2e8f6dd1a461482e6.jpg' to 'CNN_Train/J'.
    Moved 'Z21_jpg.rf.499ec8f386dc9e8e7e4ec234383f1d6c.jpg' to 'CNN_Train/Z'.
    Moved 'Y4_jpg.rf.c3a98732c8ac8a605fb18df4ba90857a.jpg' to 'CNN_Train/Y'.
    Moved 'N11_jpg.rf.3fa5777283528ad4f276dc62a95a7bbc.jpg' to 'CNN_Train/N'.
    Moved 'U12_jpg.rf.9209058cc137e37c7d39e098db4aef51.jpg' to 'CNN_Train/U'.
    Moved 'Z0_jpg.rf.175f325d6ed400b486b3b60a374a8477.jpg' to 'CNN_Train/Z'.
    Moved 'W14_jpg.rf.755b789c31b08e83cafa0bd7ddf27dff.jpg' to 'CNN_Train/W'.
    Moved 'F15_jpg.rf.4135894f44c4f8f5c8f0667b89a8fd65.jpg' to 'CNN_Train/F'.
    Moved 'C16_jpg.rf.8490bab18e5123726098ecde271f5372.jpg' to 'CNN_Train/C'.
    Moved 'K26_jpg.rf.41c72b8c830faee9c21ffbf48a87ec63.jpg' to 'CNN_Train/K'.
    Moved 'K7_jpg.rf.390eec4dd3547ab21bf095c43c6bc63f.jpg' to 'CNN_Train/K'.
    Moved 'D6_jpg.rf.01867634b70d3f9ea5adbb09d9643830.jpg' to 'CNN_Train/D'.
    Moved 'N26_jpg.rf.90951fa02c664e3174befe8cd8d1f552.jpg' to 'CNN_Train/N'.
    Moved 'A4_jpg.rf.9369f1aa5b6108a0759d030730700afa.jpg' to 'CNN_Train/A'.
    Moved 'I26_jpg.rf.a7b63373edbf3399e8056ed085912cbc.jpg' to 'CNN_Train/I'.
    Moved 'D5_jpg.rf.48b54c057f7fd6feec177dbc7c467b97.jpg' to 'CNN_Train/D'.
    Moved 'C6_jpg.rf.05217144d8c28d1ff7f060bf3210ed2d.jpg' to 'CNN_Train/C'.
    Moved 'E5_jpg.rf.8f5d058da940c376e94246c9fc7e46f0.jpg' to 'CNN_Train/E'.
    Moved 'V13_jpg.rf.9e2ffa9422f53406035f9c6488a66ecc.jpg' to 'CNN_Train/V'.
    Moved 'R11_jpg.rf.cc06205ba531fa647be4c96bc06f1f34.jpg' to 'CNN_Train/R'.
    Moved 'Z29_jpg.rf.87099a6379e8d844b814b016e199758c.jpg' to 'CNN_Train/Z'.
    Moved 'J11_jpg.rf.986b8fcff226ac7eb5c45c4a5c9aac1b.jpg' to 'CNN_Train/J'.
    Moved 'A15_jpg.rf.3654aa7d6bfc342c9ad99f500fd2aaf9.jpg' to 'CNN_Train/A'.
    Moved 'K8_jpg.rf.5436c330dfe8c046ff3bf1a1c2b2f1f4.jpg' to 'CNN_Train/K'.
    Moved 'S23_jpg.rf.820f70663892576a36438ec1e13f0eac.jpg' to 'CNN_Train/S'.
    Moved 'Z12_jpg.rf.563bc9989c617dafd753094b52a0d876.jpg' to 'CNN_Train/Z'.
    Moved 'L15_jpg.rf.30a926e11a9d57d1e1ecdbc45103a4f2.jpg' to 'CNN_Train/L'.
    Moved 'V8_jpg.rf.0b600ef127e6e4b6569dbbb8123ad3a8.jpg' to 'CNN_Train/V'.
    Moved 'M0_jpg.rf.864c0ee6368daf1d579baa9e87805ca5.jpg' to 'CNN_Train/M'.
    Moved 'K15_jpg.rf.2f6c96e13c958989d68f37166811f556.jpg' to 'CNN_Train/K'.
    Moved 'V13_jpg.rf.be5f81d0c35981669424b42a610ad935.jpg' to 'CNN_Train/V'.
    Moved 'J23_jpg.rf.4a88d3146ebfb16329f569a79c15aa53.jpg' to 'CNN_Train/J'.
    Moved 'S24_jpg.rf.45ab42883d54a69d1c7c2ec0c45a92c1.jpg' to 'CNN_Train/S'.
    Moved 'O23_jpg.rf.0d113740e458f322420dfb75d5dede48.jpg' to 'CNN_Train/O'.
    Moved 'U16_jpg.rf.2445444f56d04f5268155d271bea301a.jpg' to 'CNN_Train/U'.
    Moved 'Z13_jpg.rf.c209126c15018459b246a0e73379bbf9.jpg' to 'CNN_Train/Z'.
    Moved 'W14_jpg.rf.d1a3891ebf45f4d394d5ef3ad1dc78d8.jpg' to 'CNN_Train/W'.
    Moved 'X16_jpg.rf.c9abfedb94accdad99aff6ef822edb39.jpg' to 'CNN_Train/X'.
    Moved 'P7_jpg.rf.674a58fb29705a3ed5fb41f1ebea7cfe.jpg' to 'CNN_Train/P'.
    Moved 'Q14_jpg.rf.664d7a70451a8655827f624b0db4b548.jpg' to 'CNN_Train/Q'.
    Moved 'P7_jpg.rf.dfc3b27d3a7eebe7571dd73673de9307.jpg' to 'CNN_Train/P'.
    Moved 'Q2_jpg.rf.dc693ce9450893538e07b0f575e34a03.jpg' to 'CNN_Train/Q'.
    Moved 'H6_jpg.rf.e634c942e506cb86e77c067f43c7f692.jpg' to 'CNN_Train/H'.
    Moved 'E20_jpg.rf.18f9c75a3a3244f17baa72a083b7b604.jpg' to 'CNN_Train/E'.
    Moved 'Z21_jpg.rf.84fbe761068c40007e205f3287c3f5a7.jpg' to 'CNN_Train/Z'.
    Moved 'L0_jpg.rf.8cadc74362dc0e3baf3c3c62f21b11b5.jpg' to 'CNN_Train/L'.
    Moved 'Z10_jpg.rf.8d515a44b7041028299df663502388dc.jpg' to 'CNN_Train/Z'.
    Moved 'G6_jpg.rf.9e320312161415318d61e5e289238474.jpg' to 'CNN_Train/G'.
    Moved 'W18_jpg.rf.4fa52e28d07065f0d17decb356fe85ec.jpg' to 'CNN_Train/W'.
    Moved 'Z8_jpg.rf.81357aeb1a89b914fc16d5a0418db9ff.jpg' to 'CNN_Train/Z'.
    Moved 'G13_jpg.rf.649e1899c2d6950c74d72a07e00038a4.jpg' to 'CNN_Train/G'.
    Moved 'E15_jpg.rf.0424ab069f07383610fa481f78102605.jpg' to 'CNN_Train/E'.
    Moved 'Q6_jpg.rf.2990cf0353bee3233551a85b199b2aa4.jpg' to 'CNN_Train/Q'.
    Moved 'Q4_jpg.rf.c14d3d8e9158488f4d00e6996bbd09b9.jpg' to 'CNN_Train/Q'.
    Moved 'U13_jpg.rf.589f6536f29bad94a86050bc23e5c795.jpg' to 'CNN_Train/U'.
    Moved 'Q6_jpg.rf.b9e3040b7bdf8fca156aff1fa376141e.jpg' to 'CNN_Train/Q'.
    Moved 'Y18_jpg.rf.84fd8f3d4922255eb54c3345bc458e5b.jpg' to 'CNN_Train/Y'.
    Moved 'O25_jpg.rf.5a99d7ede796b9c82cafb4eb3ab28916.jpg' to 'CNN_Train/O'.
    Moved 'W11_jpg.rf.8f55a307005dc0662c339508a859e4be.jpg' to 'CNN_Train/W'.
    Moved 'I24_jpg.rf.abeadd94c8631921b7e4019101a42673.jpg' to 'CNN_Train/I'.
    Moved 'B2_jpg.rf.75d0fd9f5abd7f4bdf5f27fdc57c3d54.jpg' to 'CNN_Train/B'.
    Moved 'O15_jpg.rf.b9b016b36ec2750c26f5f83ae9ab7b83.jpg' to 'CNN_Train/O'.
    Moved 'H6_jpg.rf.e84df6080c3f89ec6c7c30f3bcbe4507.jpg' to 'CNN_Train/H'.
    Moved 'Z1_jpg.rf.d9d061beae87c9a13f3e776076220a8b.jpg' to 'CNN_Train/Z'.
    Moved 'E19_jpg.rf.a15da0c7e1f6dc1c89b23b9bc8b6c4a5.jpg' to 'CNN_Train/E'.
    Moved 'I7_jpg.rf.41fd04225de381ec22718cfa19e1d838.jpg' to 'CNN_Train/I'.
    Moved 'J30_jpg.rf.e36d6e55f9f0ae19dd65172bfaa9115c.jpg' to 'CNN_Train/J'.
    Moved 'X19_jpg.rf.a5ef3027c45cbc08a482bd80e800cb2c.jpg' to 'CNN_Train/X'.
    Moved 'C20_jpg.rf.205170f82acd823e1977ac5fa1102737.jpg' to 'CNN_Train/C'.
    Moved 'F24_jpg.rf.b439c3fcb01186c832c07b105383ea93.jpg' to 'CNN_Train/F'.
    Moved 'F1_jpg.rf.3a7320cc94f5c1c0635c025044208abf.jpg' to 'CNN_Train/F'.
    Moved 'H9_jpg.rf.e34c52c0bd2d2f54a9d2cee4b3b478d6.jpg' to 'CNN_Train/H'.
    Moved 'J17_jpg.rf.adc900700eb788c020757cd78fddfb46.jpg' to 'CNN_Train/J'.
    Moved 'X15_jpg.rf.b0f452c30c74f81141324ccf7bbb07b1.jpg' to 'CNN_Train/X'.
    Moved 'B24_jpg.rf.4dafd9d56b7695644224f57e47c8abfd.jpg' to 'CNN_Train/B'.
    Moved 'O21_jpg.rf.4a7d57ea5c92d11c03075179913b7ac5.jpg' to 'CNN_Train/O'.
    Moved 'J35_jpg.rf.1fc609cff6e57371109b7dd08186c23d.jpg' to 'CNN_Train/J'.
    Moved 'Q3_jpg.rf.cef2c93817228d882dadd8e06ce87eac.jpg' to 'CNN_Train/Q'.
    Moved 'M27_jpg.rf.8e4104d3a68dbc84340ceb7244e5e52c.jpg' to 'CNN_Train/M'.
    Moved 'X22_jpg.rf.9c8c031f3c4c6b513cbedecb01fefa31.jpg' to 'CNN_Train/X'.
    Moved 'L19_jpg.rf.c98a14f51f1df6eb54182831a12fc2c0.jpg' to 'CNN_Train/L'.
    Moved 'W6_jpg.rf.00d19bc3a49f6469e2afa3aa92f14ff4.jpg' to 'CNN_Train/W'.
    Moved 'P5_jpg.rf.046a96e022a22cdaf46af39f9b5ddcee.jpg' to 'CNN_Train/P'.
    Moved 'Y19_jpg.rf.9e9bd45a855af44597a6b7a9b5bd6f6a.jpg' to 'CNN_Train/Y'.
    Moved 'R16_jpg.rf.e1a0971599d4e160dacb7a71c39521ac.jpg' to 'CNN_Train/R'.
    Moved 'K16_jpg.rf.1fa3778fbb42bbcbcd79c5aa6f301c81.jpg' to 'CNN_Train/K'.
    Moved 'S11_jpg.rf.32acbe34c48eef8becffe27ff157f8c9.jpg' to 'CNN_Train/S'.
    Moved 'N12_jpg.rf.07b2230fdf996de3c8428f58a8d22a3e.jpg' to 'CNN_Train/N'.
    Moved 'S19_jpg.rf.6efc512cdb20635f2f91b5e949af7bee.jpg' to 'CNN_Train/S'.
    Moved 'C0_jpg.rf.973b3521410ae5c7e32b54a120f1a4f7.jpg' to 'CNN_Train/C'.
    Moved 'R9_jpg.rf.4bd4b9f469f4f87c6b6e0608fa8c39e1.jpg' to 'CNN_Train/R'.
    Moved 'O27_jpg.rf.e84d99f05be54ffebde2adf50fdae9a0.jpg' to 'CNN_Train/O'.
    Moved 'N11_jpg.rf.5e57c05bc09126545c50edcef455fa38.jpg' to 'CNN_Train/N'.
    Moved 'G15_jpg.rf.1fdc3b53e6e18e7daceaaf0f134a8f2d.jpg' to 'CNN_Train/G'.
    Moved 'S12_jpg.rf.bcf2423eb22a200724c5fb0b9811c08a.jpg' to 'CNN_Train/S'.
    Moved 'S5_jpg.rf.854d341353eb54971d0078dbed0b8dec.jpg' to 'CNN_Train/S'.
    Moved 'Y12_jpg.rf.38fe9e5980a2feab18e7aba1f019ee5c.jpg' to 'CNN_Train/Y'.
    Moved 'G14_jpg.rf.c42c617051036591c7d8b47eb3bad429.jpg' to 'CNN_Train/G'.
    Moved 'Z0_jpg.rf.3a019ac06f74cb1935de466f8c861403.jpg' to 'CNN_Train/Z'.
    Moved 'D4_jpg.rf.de8433ac510b064e782f4816978e3e97.jpg' to 'CNN_Train/D'.
    Moved 'M17_jpg.rf.557d68355e6d2ec6d1c5a384368803c5.jpg' to 'CNN_Train/M'.
    Moved 'N19_jpg.rf.323481105ccbc19f972588550729931e.jpg' to 'CNN_Train/N'.
    Moved 'J37_jpg.rf.986b52e1c6583269608afd529220337a.jpg' to 'CNN_Train/J'.
    Moved 'R23_jpg.rf.90c5db8dcf15ca50ace090a4e1a1cabf.jpg' to 'CNN_Train/R'.
    Moved 'G16_jpg.rf.ebbff71a268d4571309abb3e635a093d.jpg' to 'CNN_Train/G'.
    Moved 'U7_jpg.rf.2abf77c1a2f2e49cbceff5a3880470f7.jpg' to 'CNN_Train/U'.
    Moved 'X8_jpg.rf.c3ac568db728957abb6dde800623da02.jpg' to 'CNN_Train/X'.
    Moved 'F20_jpg.rf.4be18d34047cecc606ca606bb967f0f3.jpg' to 'CNN_Train/F'.
    Moved 'H20_jpg.rf.7a6d151089f099699173076d69dbe636.jpg' to 'CNN_Train/H'.
    Moved 'R23_jpg.rf.c891c4e93e1bf86632e011691ecbe679.jpg' to 'CNN_Train/R'.
    Moved 'I9_jpg.rf.955dbc82105ffc5062cf4317e1ecd95e.jpg' to 'CNN_Train/I'.
    Moved 'E22_jpg.rf.06b172de18720018813b70f96e127dfa.jpg' to 'CNN_Train/E'.
    Moved 'L21_jpg.rf.8c73a6da61edec7f4e4b30691e66ef4b.jpg' to 'CNN_Train/L'.
    Moved 'F2_jpg.rf.3195e385b2d7b76bdf43f3cfb991fcca.jpg' to 'CNN_Train/F'.
    Moved 'I1_jpg.rf.f8b45bd33f418a6f850b27a292db93be.jpg' to 'CNN_Train/I'.
    Moved 'A28_jpg.rf.6d36fa4cb06007c23a30414814b24507.jpg' to 'CNN_Train/A'.
    Moved 'D9_jpg.rf.a31596dced1ed4fb0ae2e5759189e39e.jpg' to 'CNN_Train/D'.
    Moved 'K10_jpg.rf.84ac7b2316c2254df21a81de673b6a16.jpg' to 'CNN_Train/K'.
    Moved 'Y8_jpg.rf.65bc9b18a01418ff5c91942f9baa51be.jpg' to 'CNN_Train/Y'.
    Moved 'U23_jpg.rf.4486f88ed4e3d7916dccce56abb42da5.jpg' to 'CNN_Train/U'.
    Moved 'O1_jpg.rf.d34de0834203ec84df5a6f16981312a8.jpg' to 'CNN_Train/O'.
    Moved 'U19_jpg.rf.a7caaca00b9f765d06ce2b4d249231b7.jpg' to 'CNN_Train/U'.
    Moved 'E5_jpg.rf.111a1b031fe5df1b3fb24f23019a55b7.jpg' to 'CNN_Train/E'.
    Moved 'O7_jpg.rf.581e1f714baa39c534d2d9e4ccbfc12e.jpg' to 'CNN_Train/O'.
    Moved 'K16_jpg.rf.3a0bead42b023526f5b53ddef20a7a3b.jpg' to 'CNN_Train/K'.
    Moved 'K4_jpg.rf.d6c7fd0d2a1c01f54c78e9c1109ef5ca.jpg' to 'CNN_Train/K'.
    Moved 'J15_jpg.rf.b64d42e4323a19c0295cd11d64adea44.jpg' to 'CNN_Train/J'.
    Moved 'C16_jpg.rf.24a70472f7f95f05c947926af1f92427.jpg' to 'CNN_Train/C'.
    Moved 'B2_jpg.rf.0df296fe9e10529c01484b12c6575458.jpg' to 'CNN_Train/B'.
    Moved 'T21_jpg.rf.ee24705127585fa1fadd75adeb68e007.jpg' to 'CNN_Train/T'.
    Moved 'V17_jpg.rf.dcedd7b0782bcc3c1df65a4eec61d4f2.jpg' to 'CNN_Train/V'.
    Moved 'W12_jpg.rf.06c9bdac7028db273c39d69e1fa89531.jpg' to 'CNN_Train/W'.
    Moved 'S10_jpg.rf.32f769670a7251b82f5b8187a8274414.jpg' to 'CNN_Train/S'.
    Moved 'V24_jpg.rf.abd8ffef81dc9198852b35505e6f5bf2.jpg' to 'CNN_Train/V'.
    Moved 'I15_jpg.rf.ad23ee3b1bc3d007e1b2ada25163ed30.jpg' to 'CNN_Train/I'.
    Moved 'L7_jpg.rf.44e7cef3ea780884ef5bd22c313cf34e.jpg' to 'CNN_Train/L'.
    Moved 'K26_jpg.rf.a4a32b22fe4847f7f1276f3b311f7b8c.jpg' to 'CNN_Train/K'.
    Moved 'R3_jpg.rf.430c822f14483f56ac3bcdd51038f71f.jpg' to 'CNN_Train/R'.
    Moved 'A7_jpg.rf.dbc8c7c30210fbba54002c603f443b5f.jpg' to 'CNN_Train/A'.
    Moved 'B4_jpg.rf.340e2abfd4dec3e8b7833183326edb6e.jpg' to 'CNN_Train/B'.
    Moved 'H7_jpg.rf.9b69638689d70ee5a5c3fbc9396e6a2e.jpg' to 'CNN_Train/H'.
    Moved 'A17_jpg.rf.1d8db324964e2d09835b90e5ae59b179.jpg' to 'CNN_Train/A'.
    Moved 'D23_jpg.rf.27b0f27ac69ac1a2f0f72578d1c60bc7.jpg' to 'CNN_Train/D'.
    Moved 'Z10_jpg.rf.c75958a9334a954c10692d61c2c04f64.jpg' to 'CNN_Train/Z'.
    Moved 'R1_jpg.rf.f5b2b46a4d7a0e7923cd62987edf07ae.jpg' to 'CNN_Train/R'.
    Moved 'X3_jpg.rf.f8023702c81872d8f76d408e989d4ba8.jpg' to 'CNN_Train/X'.
    Moved 'E17_jpg.rf.5785a6c34d1091b28c58dc087e4daae3.jpg' to 'CNN_Train/E'.
    Moved 'Q11_jpg.rf.769cb73acf62f133cec01666f6a1cac6.jpg' to 'CNN_Train/Q'.
    Moved 'S19_jpg.rf.bf143598f540be11f9dca8888070eb63.jpg' to 'CNN_Train/S'.
    Moved 'I0_jpg.rf.f54362266f706b4aed27504c6581b8e0.jpg' to 'CNN_Train/I'.
    Moved 'Q1_jpg.rf.42312e1e9361c3250d3a36fa95dc870f.jpg' to 'CNN_Train/Q'.
    Moved 'T7_jpg.rf.72032e82815b428438cd19eb49492308.jpg' to 'CNN_Train/T'.
    Moved 'P16_jpg.rf.78e1dc06dd496f43b5e25f84d4a8b036.jpg' to 'CNN_Train/P'.
    Moved 'N13_jpg.rf.13c8d7c9fa997fd79a3a1ed4392b079a.jpg' to 'CNN_Train/N'.
    Moved 'Q11_jpg.rf.ea72d5275ae79b4508c8219275943142.jpg' to 'CNN_Train/Q'.
    Moved 'X5_jpg.rf.7edb4daac65b4c5303b7451ba8c451b0.jpg' to 'CNN_Train/X'.
    Moved 'Z6_jpg.rf.d0ce8725d2b74f7c6922eea3cf1619ac.jpg' to 'CNN_Train/Z'.
    Moved 'E21_jpg.rf.be0b3ea585a5452196d7f15dc455d762.jpg' to 'CNN_Train/E'.
    Moved 'L13_jpg.rf.8b9f6016c464208b7e9a256b0af470b2.jpg' to 'CNN_Train/L'.
    Moved 'I1_jpg.rf.ccc50fb6e3430bf8ef09b29f52cd0cd0.jpg' to 'CNN_Train/I'.
    Moved 'W1_jpg.rf.f58dabb4bfc08190ea08b63bd72e6849.jpg' to 'CNN_Train/W'.
    Moved 'F20_jpg.rf.8982ee6b10f663fdbb8adf25df0a72d5.jpg' to 'CNN_Train/F'.
    Moved 'L8_jpg.rf.db2cce4fc915c2d1fd3102e43e2a929d.jpg' to 'CNN_Train/L'.
    Moved 'C12_jpg.rf.bd7ede8f60e096a0fefff3d00d69757a.jpg' to 'CNN_Train/C'.
    Moved 'L20_jpg.rf.75e8533a95c965196672103d0673e74f.jpg' to 'CNN_Train/L'.
    Moved 'E20_jpg.rf.9a03a1e0fe69e835ad860277ad754f5e.jpg' to 'CNN_Train/E'.
    Moved 'F14_jpg.rf.ced78c6e757a100c9f8dbf2edd767e1b.jpg' to 'CNN_Train/F'.
    Moved 'Q12_jpg.rf.195c56598e517fd7419f41e1dd50f630.jpg' to 'CNN_Train/Q'.
    Moved 'R3_jpg.rf.724d36a377db414976fd67a568cdb63d.jpg' to 'CNN_Train/R'.
    Moved 'V19_jpg.rf.c218fb5d7c9486d768d8366e6920baa9.jpg' to 'CNN_Train/V'.
    Moved 'D6_jpg.rf.310928f6aff2a1759ea1f35fe4e23829.jpg' to 'CNN_Train/D'.
    Moved 'L3_jpg.rf.89ae62d6e96177f6b2effa3d7099f724.jpg' to 'CNN_Train/L'.
    Moved 'Z3_jpg.rf.56694b0cb356d57b9da4914993042958.jpg' to 'CNN_Train/Z'.
    Moved 'D4_jpg.rf.f1801b699355f9a84f26724621746d71.jpg' to 'CNN_Train/D'.
    Moved 'I27_jpg.rf.d55af66cb9a6ee52b1c9299a6f99826a.jpg' to 'CNN_Train/I'.
    Moved 'C18_jpg.rf.3f6c5a43677a27ecbe3a5796b44f8ddf.jpg' to 'CNN_Train/C'.
    Moved 'T22_jpg.rf.02e1fc73db34427a44a8888dc77003c6.jpg' to 'CNN_Train/T'.
    Moved 'J37_jpg.rf.35f55f1d34f5a23d72ca9ed40b1017d8.jpg' to 'CNN_Train/J'.
    Moved 'I14_jpg.rf.54d6be466239ebe87c66ee9673404f40.jpg' to 'CNN_Train/I'.
    Moved 'S12_jpg.rf.fe460cc814b0f47b9700993518b9130b.jpg' to 'CNN_Train/S'.
    Moved 'F7_jpg.rf.09c9ccc1226c5afeb66e2243ad08abc1.jpg' to 'CNN_Train/F'.
    Moved 'X4_jpg.rf.e2f2c6b235e95f166ea949b04f801d00.jpg' to 'CNN_Train/X'.
    Moved 'B8_jpg.rf.ad0c398b1d9d6a140366dec45163688a.jpg' to 'CNN_Train/B'.
    Moved 'F25_jpg.rf.5783053c7a9046e380cc6abd732ee315.jpg' to 'CNN_Train/F'.
    Moved 'P20_jpg.rf.ac18a648f041ea35d7b08f241c5ef2a4.jpg' to 'CNN_Train/P'.
    Moved 'V26_jpg.rf.33197408e4f957f8bf2918b6ab9e5785.jpg' to 'CNN_Train/V'.
    Moved 'E2_jpg.rf.869925976f2698aa0b2558bb10d8c865.jpg' to 'CNN_Train/E'.
    Moved 'A12_jpg.rf.84c6afc718de92ea268db5d3902ca2ba.jpg' to 'CNN_Train/A'.
    Moved 'H9_jpg.rf.d9b58c3ffad4b10e18e5a289baa6b85c.jpg' to 'CNN_Train/H'.
    Moved 'D9_jpg.rf.e9772d74d5e53e232a89fcda7408a639.jpg' to 'CNN_Train/D'.
    Moved 'A19_jpg.rf.dd7e736410be65dec70415c3b00500a2.jpg' to 'CNN_Train/A'.
    Moved 'W13_jpg.rf.a13316604ffd0e8924f349398996492b.jpg' to 'CNN_Train/W'.
    Moved 'V8_jpg.rf.faeb9cac446597cb90d3597b3ed53ae8.jpg' to 'CNN_Train/V'.
    Moved 'R24_jpg.rf.a04d37ea0dce95e7537dad9fbb3ada14.jpg' to 'CNN_Train/R'.
    Moved 'N20_jpg.rf.5cb26ffeb850e2c2b61fe1be4d127340.jpg' to 'CNN_Train/N'.
    Moved 'Q0_jpg.rf.53c81488ddd43440ae54c42ec77a987a.jpg' to 'CNN_Train/Q'.
    Moved 'L2_jpg.rf.16da50ef8d9eef2c611941967b78a451.jpg' to 'CNN_Train/L'.
    Moved 'H10_jpg.rf.1dfa83e4fb441b6e63a1479f00cc2ada.jpg' to 'CNN_Train/H'.
    Moved 'E19_jpg.rf.f9ccc5ec73209f6eecaca429420f30c3.jpg' to 'CNN_Train/E'.
    Moved 'F6_jpg.rf.5ff3922de89f68c164ed7459c634919c.jpg' to 'CNN_Train/F'.
    Moved 'X1_jpg.rf.75fa4a2cec8c5c91b5436756022a9449.jpg' to 'CNN_Train/X'.
    Moved 'I16_jpg.rf.788433321164c435001c88f30e1e4053.jpg' to 'CNN_Train/I'.
    Moved 'X2_jpg.rf.fcd66bb5c1443f31ad2b56e44725a9bd.jpg' to 'CNN_Train/X'.
    Moved 'E8_jpg.rf.51233f58587227a47ddcad11950d4672.jpg' to 'CNN_Train/E'.
    Moved 'J29_jpg.rf.885f23a6e9ead8f175c148f3f848e876.jpg' to 'CNN_Train/J'.
    Moved 'Q5_jpg.rf.133ce97542d60c224a802c17ccf189ef.jpg' to 'CNN_Train/Q'.
    Moved 'L5_jpg.rf.c83eab64405668a23a11eccc6988ca8f.jpg' to 'CNN_Train/L'.
    Moved 'O14_jpg.rf.4e1fbfdcef04125a6f64eb03e394d184.jpg' to 'CNN_Train/O'.
    Moved 'T3_jpg.rf.b57ea6b3cb3d635d879b669047a5ae0b.jpg' to 'CNN_Train/T'.
    Moved 'W4_jpg.rf.27f188bfcc161a9bfb8d9e497ec708e1.jpg' to 'CNN_Train/W'.
    Moved 'J2_jpg.rf.01f65b3db913fe28c20d99cf89124c9f.jpg' to 'CNN_Train/J'.
    Moved 'Q4_jpg.rf.9abd9807e7761c1b3a8110a5b0542a29.jpg' to 'CNN_Train/Q'.
    Moved 'T23_jpg.rf.83a11fc2daa046abd4a6017570f7dc43.jpg' to 'CNN_Train/T'.
    Created directory: CNN_Test/C
    Moved 'C22_jpg.rf.e54cbbfdd4ea0670eb4e1c507de4a8a2.jpg' to 'CNN_Test/C'.
    Created directory: CNN_Test/X
    Moved 'X24_jpg.rf.ed6474bd56983fbdb13576b2c3e9c0b7.jpg' to 'CNN_Test/X'.
    Created directory: CNN_Test/B
    Moved 'B15_jpg.rf.0f0628552139144fc67c453e1f1b7b15.jpg' to 'CNN_Test/B'.
    Created directory: CNN_Test/J
    Moved 'J6_jpg.rf.6db6cb7829752f430ec8344bc7605444.jpg' to 'CNN_Test/J'.
    Created directory: CNN_Test/F
    Moved 'F3_jpg.rf.c854e14a7108c9294c226a392026e73b.jpg' to 'CNN_Test/F'.
    Created directory: CNN_Test/S
    Moved 'S6_jpg.rf.0b6e42445a56998369cdd3759c2cf3d4.jpg' to 'CNN_Test/S'.
    Created directory: CNN_Test/Q
    Moved 'Q7_jpg.rf.07fdf6c096cd2a9be72b4de4a627935d.jpg' to 'CNN_Test/Q'.
    Created directory: CNN_Test/Y
    Moved 'Y5_jpg.rf.86682b1ddac4546cc626ba99a61f42fc.jpg' to 'CNN_Test/Y'.
    Created directory: CNN_Test/V
    Moved 'V27_jpg.rf.c316e3cfcddb7fe8d6ed9e06290b3b1c.jpg' to 'CNN_Test/V'.
    Created directory: CNN_Test/W
    Moved 'W16_jpg.rf.5771e4967321c7e827758319e697bed6.jpg' to 'CNN_Test/W'.
    Created directory: CNN_Test/O
    Moved 'O20_jpg.rf.517237686eca6346d6d72cbd96b79cb3.jpg' to 'CNN_Test/O'.
    Created directory: CNN_Test/G
    Moved 'G7_jpg.rf.04faf434dd590a7bd02818b2b57a704f.jpg' to 'CNN_Test/G'.
    Created directory: CNN_Test/Z
    Moved 'Z9_jpg.rf.fd5bb2f80d391b73a85bbbd5bc5accc1.jpg' to 'CNN_Test/Z'.
    Created directory: CNN_Test/U
    Moved 'U5_jpg.rf.2be92300b664a1946dde8902dc50adbb.jpg' to 'CNN_Test/U'.
    Created directory: CNN_Test/H
    Moved 'H19_jpg.rf.4957c34731ee5c867288825f5ca9f170.jpg' to 'CNN_Test/H'.
    Created directory: CNN_Test/T
    Moved 'T17_jpg.rf.7fecdf5c5e4e4574de71a65611579e0f.jpg' to 'CNN_Test/T'.
    Moved 'C23_jpg.rf.cff2647e71600ac354da45cb87eca667.jpg' to 'CNN_Test/C'.
    Moved 'T18_jpg.rf.334025dd29760be4f8918fd6d6c3f01c.jpg' to 'CNN_Test/T'.
    Created directory: CNN_Test/N
    Moved 'N6_jpg.rf.3899dd6cc1da66139de57126a250c175.jpg' to 'CNN_Test/N'.
    Moved 'T1_jpg.rf.877948f560962d1e267a72617d9e1ed4.jpg' to 'CNN_Test/T'.
    Moved 'O4_jpg.rf.82c403d496488192d134b233a080d258.jpg' to 'CNN_Test/O'.
    Created directory: CNN_Test/M
    Moved 'M14_jpg.rf.f7da6c9c9d9d3f5c6db4689846f722cc.jpg' to 'CNN_Test/M'.
    Moved 'W23_jpg.rf.caecf7140a005d779f0950cc7c6a7616.jpg' to 'CNN_Test/W'.
    Moved 'W19_jpg.rf.62d8144cb69396b18abeb70e34191b2a.jpg' to 'CNN_Test/W'.
    Moved 'S16_jpg.rf.138a4aa81180adcc24323c1634ed507e.jpg' to 'CNN_Test/S'.
    Moved 'U6_jpg.rf.5a219aee1c9d41d5fdeabd66f78d0f68.jpg' to 'CNN_Test/U'.
    Moved 'G20_jpg.rf.e0c7b5abdee0fb589e576002c76f4ace.jpg' to 'CNN_Test/G'.
    Moved 'Q10_jpg.rf.87a66659eb5791bf51f56ff1e1883273.jpg' to 'CNN_Test/Q'.
    Moved 'W24_jpg.rf.1bc37c6fc4770b284edc6f9027eb6cf2.jpg' to 'CNN_Test/W'.
    Moved 'T24_jpg.rf.068e7b2424eac996c86bb6d9c38e083d.jpg' to 'CNN_Test/T'.
    Moved 'G11_jpg.rf.cc02dc447a7959e73869f4f45b0ef29a.jpg' to 'CNN_Test/G'.
    Created directory: CNN_Test/A
    Moved 'A22_jpg.rf.f02ad8558ce1c88213b4f83c0bc66bc8.jpg' to 'CNN_Test/A'.
    Created directory: CNN_Test/P
    Moved 'P24_jpg.rf.67b98ae281f9a130f5e6f70ebb1e574f.jpg' to 'CNN_Test/P'.
    Moved 'Y25_jpg.rf.a8796b77dd8c6370577ceacd3852b4b9.jpg' to 'CNN_Test/Y'.
    Created directory: CNN_Test/R
    Moved 'R18_jpg.rf.362d9bbd88ac7b5122cf730d25b36517.jpg' to 'CNN_Test/R'.
    Moved 'J27_jpg.rf.d8b9ca4ab3abf8436b2faab339881496.jpg' to 'CNN_Test/J'.
    Moved 'J28_jpg.rf.e25320de48d1b6037555bcdb95d28f0d.jpg' to 'CNN_Test/J'.
    Moved 'N9_jpg.rf.b92e9f54839f076f92f54388320fb7a3.jpg' to 'CNN_Test/N'.
    Moved 'H5_jpg.rf.f7077ae3eb67ac9f01bd2914625a05b9.jpg' to 'CNN_Test/H'.
    Moved 'V2_jpg.rf.f887a9d681a64f8a2efe8375245ab4bb.jpg' to 'CNN_Test/V'.
    Created directory: CNN_Test/K
    Moved 'K6_jpg.rf.5f1f357165ba30376b667035f60fc6ce.jpg' to 'CNN_Test/K'.
    Moved 'C19_jpg.rf.577ce02a223c65e89dc4a4eacd130040.jpg' to 'CNN_Test/C'.
    Moved 'M24_jpg.rf.f5f17e72ed1a7213e2a01f60f8afc158.jpg' to 'CNN_Test/M'.
    Moved 'V10_jpg.rf.18af9b37cbe013f9a0640294fb71f0d6.jpg' to 'CNN_Test/V'.
    Moved 'N22_jpg.rf.ac8a6d5cd21bd7e4fd93128e6eb24329.jpg' to 'CNN_Test/N'.
    Created directory: CNN_Test/I
    Moved 'I28_jpg.rf.74efc17a40df4bbd0bc63625be836201.jpg' to 'CNN_Test/I'.
    Moved 'Z16_jpg.rf.309328aaeb31736f8a93a570d6d4f140.jpg' to 'CNN_Test/Z'.
    Moved 'S0_jpg.rf.4466ad3687a4cfac9f6e4474d89e121e.jpg' to 'CNN_Test/S'.
    Moved 'O12_jpg.rf.9103647cd190af96ac2a83f7bd1d0ae2.jpg' to 'CNN_Test/O'.
    Moved 'T13_jpg.rf.bf67ceb39727be048066c0de76801971.jpg' to 'CNN_Test/T'.
    Moved 'V12_jpg.rf.0e68ec7ee88bd6f0f70fe5496e893068.jpg' to 'CNN_Test/V'.
    Moved 'H25_jpg.rf.dce08bcb4d091593dda19db8b0d2b155.jpg' to 'CNN_Test/H'.
    Moved 'R5_jpg.rf.1e94c77f430ee342744dc9fce202c449.jpg' to 'CNN_Test/R'.
    Moved 'K13_jpg.rf.d544147ca4794793e996cbe309fbcf28.jpg' to 'CNN_Test/K'.
    Moved 'Z27_jpg.rf.0a3e757898215b17678047cb5485c82c.jpg' to 'CNN_Test/Z'.
    Moved 'F17_jpg.rf.6097db79e0385af55b85ad5fa03cdc55.jpg' to 'CNN_Test/F'.
    Moved 'M20_jpg.rf.aa9f2799d2cbe8f51363ec2862b427a6.jpg' to 'CNN_Test/M'.
    Moved 'C17_jpg.rf.ceb81f8ae3c3673bd060ebe71848eca8.jpg' to 'CNN_Test/C'.
    Moved 'K12_jpg.rf.1bd849de853e33f6262b6643555e098f.jpg' to 'CNN_Test/K'.
    Moved 'X9_jpg.rf.28187742b082579d85eda81cf98bf5bb.jpg' to 'CNN_Test/X'.
    Moved 'G4_jpg.rf.d55500c4fc04c89c78d42e2283860275.jpg' to 'CNN_Test/G'.
    Moved 'W7_jpg.rf.c80a52e6a95797bd8cf3a03ec4701d99.jpg' to 'CNN_Test/W'.
    Moved 'B14_jpg.rf.ed5ba6d44f55ab03e62d2baeac4aa1aa.jpg' to 'CNN_Test/B'.
    Moved 'I17_jpg.rf.8f1ed619e93147f7f9754a4eddbb90de.jpg' to 'CNN_Test/I'.
    Moved 'B19_jpg.rf.69527cc1f34d694cc04e55db80ed9b1a.jpg' to 'CNN_Test/B'.
    Moved 'X14_jpg.rf.3c3c69ed80d0ce1688d1dde4b21f19f9.jpg' to 'CNN_Test/X'.
    Moved 'K24_jpg.rf.f1a48e0e3bf4bcae3540590c972d57f3.jpg' to 'CNN_Test/K'.
    Moved 'J9_jpg.rf.213a9e356777a13d336e4988c33a93e1.jpg' to 'CNN_Test/J'.
    Moved 'X20_jpg.rf.2a36699005b7e1881e5faa278c506b86.jpg' to 'CNN_Test/X'.
    Moved 'Z18_jpg.rf.2cffbd9beaeb50a7d03751c3ce738e81.jpg' to 'CNN_Test/Z'.
    Moved 'G3_jpg.rf.e723dcdc277f3432e4eb7003b6e5a587.jpg' to 'CNN_Test/G'.
    Created directory: CNN_Test/D
    Moved 'D1_jpg.rf.89a5f6f41bf8bc795db94105f709dd34.jpg' to 'CNN_Test/D'.



```python
# now we are going to read in the dataset
# source - https://www.tensorflow.org/tutorials/load_data/images
training_dataset = tf.keras.preprocessing.image_dataset_from_directory(
    'CNN_Train',
    image_size = (374,374), # the image size
    batch_size = 1512, # the number of images
)

testing_dataset = tf.keras.preprocessing.image_dataset_from_directory(
    'CNN_Test',
    image_size = (374,374), # the image size
    batch_size = 72, # the number of images
)
train_class_names = training_dataset.class_names
print(train_class_names) # okay perfect we see that the there are class names and even better they correspond to each letter
test_class_names = testing_dataset.class_names
print(test_class_names)
```

    Found 1512 files belonging to 26 classes.
    Found 72 files belonging to 24 classes.
    ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    ['A', 'B', 'C', 'D', 'F', 'G', 'H', 'I', 'J', 'K', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']


    2024-11-20 11:17:30.843309: E external/local_xla/xla/stream_executor/cuda/cuda_driver.cc:152] failed call to cuInit: INTERNAL: CUDA error: Failed call to cuInit: CUDA_ERROR_NO_DEVICE: no CUDA-capable device is detected



```python
# going to attempt to print an image from each of the classes along with its image


def display_sample_images(class_folders, num_samples_per_class=1):
    """
    Display a few images from each class folder with their proper class labels.
    :param class_folders: List of class folders
    :param num_samples_per_class: Number of images to display from each class
    """
    plt.figure(figsize=(30, 30))  # Set the size of the grid for plotting
    num_images = 0
    total_images_to_show = num_samples_per_class * len(class_folders)

    # Loop over each class folder
    for class_folder in class_folders:
        class_label = os.path.basename(class_folder)  # Extract the class label (e.g., 'A', 'B', etc.)
        
        # Get a list of image filenames in the current class folder
        image_files = [f for f in os.listdir(class_folder) if f.endswith('.jpg')]
        
        # Randomly sample a few image files from this folder
        selected_images = random.sample(image_files, min(num_samples_per_class, len(image_files)))

        for image_file in selected_images:
            image_path = os.path.join(class_folder, image_file)
            
            # Open the image
            img = Image.open(image_path)
            
            # Plot the image
            plt.subplot(len(class_folders), num_samples_per_class, num_images + 1)
            plt.imshow(img)
            plt.title(f"Class {class_label}")
            plt.axis('off')  # Hide axes
            
            num_images += 1
            if num_images >= total_images_to_show:
                break
    
    # Show all the images in the grid
    plt.tight_layout()
    plt.show()

# Call the function to display sample images
display_sample_images(train_class_folders)
```


    
![png](output_3_0.png)
    



```python
#attempting to do images that are not chatgpt based
# come back and keep working on this code so that:
# no letters repeat
# they are the same size 
# aranged by 6 rows and 6 columns
plt.figure(figsize=(15, 15))
rows = 6
cols = 6
for images, labels in training_dataset.take(1):
  for i in range(26):
    ax = plt.subplot(rows, cols, i + 1)
    plt.imshow(images[i].numpy().astype("uint8"))
    plt.title(class_names[labels[i]])
    plt.axis("off")
    plt.tight_layout()
    plt.show()
    
```


    
![png](output_4_0.png)
    



    
![png](output_4_1.png)
    



    
![png](output_4_2.png)
    



    
![png](output_4_3.png)
    



    
![png](output_4_4.png)
    



    
![png](output_4_5.png)
    



    
![png](output_4_6.png)
    



    
![png](output_4_7.png)
    



    
![png](output_4_8.png)
    



    
![png](output_4_9.png)
    



    
![png](output_4_10.png)
    



    
![png](output_4_11.png)
    



    
![png](output_4_12.png)
    



    
![png](output_4_13.png)
    



    
![png](output_4_14.png)
    



    
![png](output_4_15.png)
    



    
![png](output_4_16.png)
    



    
![png](output_4_17.png)
    



    
![png](output_4_18.png)
    



    
![png](output_4_19.png)
    



    
![png](output_4_20.png)
    



    
![png](output_4_21.png)
    



    
![png](output_4_22.png)
    



    
![png](output_4_23.png)
    



    
![png](output_4_24.png)
    



    
![png](output_4_25.png)
    


    2024-11-19 15:34:59.856186: I tensorflow/core/framework/local_rendezvous.cc:405] Local rendezvous is aborting with status: OUT_OF_RANGE: End of sequence



```python
# moving forward with the model

# Number of classes (26 letters of ASL)
number_of_classes = 26

# Load the pre-trained ResNet50 model without the top layer
base_model = ResNet50(weights='imagenet', include_top=False)

# Add custom layers on top of the base model
x = base_model.output
x = GlobalAveragePooling2D()(x)  # This reduces the spatial dimensions to a single vector
x = Dense(1024, activation='relu')(x)  # A dense layer with 1024 units
predictions = Dense(number_of_classes, activation='softmax')(x)  # 26 output units for ASL letters

# Create the final model
model = Model(inputs=base_model.input, outputs=predictions)

# Freeze the layers of ResNet50 so that only the custom layers are trained
for layer in base_model.layers:
    layer.trainable = False

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Print the model summary to check the architecture
model.summary()

# Train the model with your dataset
model.fit(training_dataset, train_class_names, epochs=10, testing_data=(testing_dataset, test_class_names))
```


<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold">Model: "functional"</span>
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace">┏━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┓
┃<span style="font-weight: bold"> Layer (type)        </span>┃<span style="font-weight: bold"> Output Shape      </span>┃<span style="font-weight: bold">    Param # </span>┃<span style="font-weight: bold"> Connected to      </span>┃
┡━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━┩
│ input_layer         │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ -                 │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">InputLayer</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">3</span>)          │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv1_pad           │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ input_layer[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>] │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">ZeroPadding2D</span>)     │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">3</span>)          │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv1_conv (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>) │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">9,472</span> │ conv1_pad[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]   │
│                     │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv1_bn            │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv1_conv[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]  │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv1_relu          │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv1_bn[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]    │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ pool1_pad           │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv1_relu[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]  │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">ZeroPadding2D</span>)     │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ pool1_pool          │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ pool1_pad[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]   │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">MaxPooling2D</span>)      │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,160</span> │ pool1_pool[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]  │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv2_block1_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block1_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │ conv2_block1_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv2_block1_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block1_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_0_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">16,640</span> │ pool1_pool[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]  │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">16,640</span> │ conv2_block1_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_0_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv2_block1_0_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv2_block1_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block1_0_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │ conv2_block1_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block1_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block1_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">16,448</span> │ conv2_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv2_block2_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block2_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │ conv2_block2_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv2_block2_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block2_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">16,640</span> │ conv2_block2_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv2_block2_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │ conv2_block2_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block2_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block2_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">16,448</span> │ conv2_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv2_block3_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block3_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">36,928</span> │ conv2_block3_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">256</span> │ conv2_block3_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block3_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">64</span>)         │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">16,640</span> │ conv2_block3_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv2_block3_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │ conv2_block3_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv2_block3_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv2_block3_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">32,896</span> │ conv2_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block1_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block1_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">147,584</span> │ conv3_block1_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block1_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block1_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_0_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">131,584</span> │ conv2_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">66,048</span> │ conv3_block1_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_0_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv3_block1_0_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv3_block1_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block1_0_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │ conv3_block1_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block1_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block1_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">65,664</span> │ conv3_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block2_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block2_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">147,584</span> │ conv3_block2_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block2_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block2_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">66,048</span> │ conv3_block2_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv3_block2_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │ conv3_block2_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block2_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block2_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">65,664</span> │ conv3_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block3_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block3_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">147,584</span> │ conv3_block3_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block3_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block3_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">66,048</span> │ conv3_block3_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv3_block3_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │ conv3_block3_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block3_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block3_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">65,664</span> │ conv3_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block4_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block4_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">147,584</span> │ conv3_block4_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │        <span style="color: #00af00; text-decoration-color: #00af00">512</span> │ conv3_block4_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block4_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">128</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │     <span style="color: #00af00; text-decoration-color: #00af00">66,048</span> │ conv3_block4_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv3_block4_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │ conv3_block4_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv3_block4_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv3_block4_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">131,328</span> │ conv3_block4_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block1_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block1_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │ conv4_block1_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block1_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block1_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_0_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">525,312</span> │ conv3_block4_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">263,168</span> │ conv4_block1_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_0_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block1_0_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block1_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block1_0_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │ conv4_block1_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block1_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block1_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">262,400</span> │ conv4_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block2_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block2_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │ conv4_block2_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block2_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block2_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">263,168</span> │ conv4_block2_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block2_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │ conv4_block2_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block2_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block2_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">262,400</span> │ conv4_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block3_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block3_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │ conv4_block3_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block3_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block3_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">263,168</span> │ conv4_block3_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block3_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │ conv4_block3_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block3_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block3_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">262,400</span> │ conv4_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block4_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block4_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │ conv4_block4_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block4_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block4_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">263,168</span> │ conv4_block4_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block4_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │ conv4_block4_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block4_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block4_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">262,400</span> │ conv4_block4_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block5_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block5_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │ conv4_block5_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block5_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block5_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">263,168</span> │ conv4_block5_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block5_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block4_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │ conv4_block5_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block5_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block5_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">262,400</span> │ conv4_block5_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block6_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block6_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">590,080</span> │ conv4_block6_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │ conv4_block6_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block6_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">263,168</span> │ conv4_block6_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │ conv4_block6_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block5_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │ conv4_block6_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv4_block6_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv4_block6_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │    <span style="color: #00af00; text-decoration-color: #00af00">524,800</span> │ conv4_block6_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv5_block1_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block1_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">2,359,808</span> │ conv5_block1_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv5_block1_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block1_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_0_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">2,099,200</span> │ conv4_block6_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">1,050,624</span> │ conv5_block1_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_0_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">8,192</span> │ conv5_block1_0_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">8,192</span> │ conv5_block1_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block1_0_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │ conv5_block1_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block1_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block1_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">1,049,088</span> │ conv5_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv5_block2_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block2_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">2,359,808</span> │ conv5_block2_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv5_block2_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block2_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">1,050,624</span> │ conv5_block2_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">8,192</span> │ conv5_block2_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block1_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │ conv5_block2_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block2_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block2_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_1_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">1,049,088</span> │ conv5_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_1_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv5_block3_1_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_1_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block3_1_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_2_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">2,359,808</span> │ conv5_block3_1_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_2_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │ conv5_block3_2_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_2_relu │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block3_2_b… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)        │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_3_conv │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │  <span style="color: #00af00; text-decoration-color: #00af00">1,050,624</span> │ conv5_block3_2_r… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Conv2D</span>)            │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_3_bn   │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │      <span style="color: #00af00; text-decoration-color: #00af00">8,192</span> │ conv5_block3_3_c… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalizatio…</span> │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_add    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block2_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Add</span>)               │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │ conv5_block3_3_b… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ conv5_block3_out    │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>,      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block3_add… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">Activation</span>)        │ <span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)       │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ global_average_poo… │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">2048</span>)      │          <span style="color: #00af00; text-decoration-color: #00af00">0</span> │ conv5_block3_out… │
│ (<span style="color: #0087ff; text-decoration-color: #0087ff">GlobalAveragePool…</span> │                   │            │                   │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ dense (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)       │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)      │  <span style="color: #00af00; text-decoration-color: #00af00">2,098,176</span> │ global_average_p… │
├─────────────────────┼───────────────────┼────────────┼───────────────────┤
│ dense_1 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)     │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">26</span>)        │     <span style="color: #00af00; text-decoration-color: #00af00">26,650</span> │ dense[<span style="color: #00af00; text-decoration-color: #00af00">0</span>][<span style="color: #00af00; text-decoration-color: #00af00">0</span>]       │
└─────────────────────┴───────────────────┴────────────┴───────────────────┘
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Total params: </span><span style="color: #00af00; text-decoration-color: #00af00">25,712,538</span> (98.09 MB)
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">2,124,826</span> (8.11 MB)
</pre>




<pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Non-trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">23,587,712</span> (89.98 MB)
</pre>



    Unexpected exception formatting exception. Falling back to standard exception


    Traceback (most recent call last):
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 3505, in run_code
        exec(code_obj, self.user_global_ns, self.user_ns)
      File "/tmp/ipykernel_74166/855413357.py", line 29, in <module>
        model.fit(training_dataset, train_class_names, epochs=10, testing_data=(testing_dataset, test_class_names))
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/keras/src/utils/traceback_utils.py", line 122, in error_handler
        raise e.with_traceback(filtered_tb) from None
      File "/home/ybf3jw/.local/lib/python3.11/site-packages/keras/src/utils/traceback_utils.py", line 119, in error_handler
        filtered_tb = _process_traceback_frames(e.__traceback__)
                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    TypeError: TensorFlowTrainer.fit() got an unexpected keyword argument 'testing_data'
    
    During handling of the above exception, another exception occurred:
    
    Traceback (most recent call last):
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/interactiveshell.py", line 2102, in showtraceback
        stb = self.InteractiveTB.structured_traceback(
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/ultratb.py", line 1310, in structured_traceback
        return FormattedTB.structured_traceback(
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/ultratb.py", line 1199, in structured_traceback
        return VerboseTB.structured_traceback(
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/ultratb.py", line 1052, in structured_traceback
        formatted_exception = self.format_exception_as_a_whole(etype, evalue, etb, number_of_lines_of_context,
                              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/ultratb.py", line 953, in format_exception_as_a_whole
        self.get_records(etb, number_of_lines_of_context, tb_offset) if etb else []
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/IPython/core/ultratb.py", line 1039, in get_records
        res = list(stack_data.FrameInfo.stack_data(etb, options=options))[tb_offset:]
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/stack_data/core.py", line 597, in stack_data
        yield from collapse_repeated(
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/stack_data/utils.py", line 83, in collapse_repeated
        yield from map(mapper, original_group)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/stack_data/core.py", line 587, in mapper
        return cls(f, options)
               ^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/stack_data/core.py", line 551, in __init__
        self.executing = Source.executing(frame_or_tb)
                         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/executing/executing.py", line 378, in executing
        assert_(new_stmts <= stmts)
      File "/apps/software/standard/core/jupyterlab/3.6.3-py3.11/lib/python3.11/site-packages/executing/executing.py", line 154, in assert_
        raise AssertionError(str(message))
    AssertionError



```python

```
